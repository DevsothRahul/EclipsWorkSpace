package com.ioc.SpringDemo.Clasess;

import java.util.List;
import java.util.Set;

public class Square {
	List<point> list;
	List<Integer> No;
	Set<Integer> set;
	List<String> names;
	
	public List<point> getList() {
		return list;
	}

	public List<String> getNames() {
		return names;
	}

	public void setNames(List<String> names) {
		this.names = names;
	}

	public void setList(List<point> list) {
		this.list = list;
	}

	public List<Integer> getNo() {
		return No;
	}

	public void setNo(List<Integer> no) {
		No = no;
	}

	public Set<Integer> getSet() {
		return set;
	}

	public void setSet(Set<Integer> set) {
		this.set = set;
	}

	public Square(List<point> list, List<Integer> no, Set<Integer> set, List<String> names) {
		super();
		this.list = list;
		No = no;
		this.set = set;
		this.names = names;
	}


	
}
