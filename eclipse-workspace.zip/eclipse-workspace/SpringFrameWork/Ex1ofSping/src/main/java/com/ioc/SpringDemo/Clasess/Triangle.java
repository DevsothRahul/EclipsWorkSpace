package com.ioc.SpringDemo.Clasess;

public class Triangle {
	private int base;
	private int ht;
	
	public Triangle(int base, int ht) {
		super();
		this.base = base;
		this.ht = ht;
	}
	public Triangle(int V) {
		super();
		this.base = V;
		this.ht = V;
	}

	public Triangle( ) {

		this.base = 10;
		this.ht = 20;
	}	

	public void Draw() {
		System.out.println("Triangle Drawn");
	}
	public void setBase(int base) {
		this.base = base;
	}
	public void setHt(int ht) {
		this.ht = ht;
	}
	public void print()
	{
	System.out.println("Base: "+base);
	System.out.println("Height: "+ht);

	
	}
}
