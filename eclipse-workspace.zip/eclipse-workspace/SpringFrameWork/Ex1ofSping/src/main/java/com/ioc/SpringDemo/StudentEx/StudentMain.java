package com.ioc.SpringDemo.StudentEx;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ioc.SpringDemo.StudentEx.Pojo.Student;

public class StudentMain {
	public static void main(String[] args) {
		ApplicationContext fact = new ClassPathXmlApplicationContext("com/ioc/SpringDemo/StudentEx/student.xml");
		Student s = (Student) fact.getBean("S");
		System.out.println(s.toString());
	}
}
