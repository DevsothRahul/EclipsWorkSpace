package com.ioc.SpringDemo.Clasess;

public class Circle {
	public void Draw() {
		System.out.println("Circle Drawn");
	}
}
