package com.ioc.SpringDemo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ioc.SpringDemo.Clasess.Rectangle;
import com.ioc.SpringDemo.Clasess.Triangle;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
//    	Triangle T=new Triangle();
//    	T.Draw();
		//BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/ioc/SpringDemo/spring.xml"));
		ApplicationContext factory=new ClassPathXmlApplicationContext("com/ioc/SpringDemo/spring.xml");

		//ApplicationContext factory=new ClassPathXmlApplicationContext("com/ioc/SpringDemo/spring.xml");
//		Triangle t = (Triangle) factory.getBean("T");
//		t.Draw();
//		t.print();
//		Triangle t1 = (Triangle) factory.getBean("T1");
//		t1.print();
//		Triangle t2 = (Triangle) factory.getBean("T2");
//		t2.print();
//		Circle C=(Circle) factory.getBean("C");
//		C.Draw();
		
	Triangle tr4=(Triangle) factory.getBean("Ts1");
		tr4.print();
		
		Rectangle R=(Rectangle) factory.getBean("R");
		System.out.println("Point A: "+R.getPointA().getX()+ " "+ R.getPointA().getY());
		System.out.println("Point B: "+R.getPointB().getX()+ " "+ R.getPointB().getY());
		System.out.println("Point C: "+R.getPointC().getX()+ "  "+ R.getPointC().getY());
		System.out.println("Point D: "+R.getPointD().getX()+ " "+ R.getPointD().getY());
		
	}
}
