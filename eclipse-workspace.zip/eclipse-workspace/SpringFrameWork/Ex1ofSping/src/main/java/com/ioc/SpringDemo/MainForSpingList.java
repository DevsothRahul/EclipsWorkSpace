package com.ioc.SpringDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ioc.SpringDemo.Clasess.Rectangle;
import com.ioc.SpringDemo.Clasess.Square;
import com.ioc.SpringDemo.Clasess.point;

public class MainForSpingList {
	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("com/ioc/SpringDemo/spingList.xml");
		Square S = (Square) factory.getBean("S");
		for (point p : S.getList()) {
			System.out.println(p.getX() + " " + p.getY());
		}
		System.out.println("Through List");
		for (Integer p1 : S.getNo()) {
			System.out.println(p1);
		}
		System.out.println(" Through Set ");
		for (Integer p2 : S.getSet()) {
			System.out.println(p2);
		}
		System.out.println("Through list Names: ");
		for (String p3 : S.getNames()) {
			System.out.println(p3);
		}
	}

}
