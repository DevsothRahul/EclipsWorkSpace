package com.ioc.SpringDemo.StudentEx.Pojo;

public class Student {
	private int stId;
	private String stName;
	private String sdGender;
	private String stBranch;
	private String stFavSub;
	public Student(int stId, String stName, String sdGender, String stBranch, String stFavSub) {
		super();
		this.stId = stId;
		this.stName = stName;
		this.sdGender = sdGender;
		this.stBranch = stBranch;
		this.stFavSub = stFavSub;
	}
	public int getStId() {
		return stId;
	}
	public void setStId(int stId) {
		this.stId = stId;
	}
	public String getStName() {
		return stName;
	}
	public void setStName(String stName) {
		this.stName = stName;
	}
	public String getSdGender() {
		return sdGender;
	}
	public void setSdGender(String sdGender) {
		this.sdGender = sdGender;
	}
	public String getStBranch() {
		return stBranch;
	}
	public void setStBranch(String stBranch) {
		this.stBranch = stBranch;
	}
	public String getStFavSub() {
		return stFavSub;
	}
	public void setStFavSub(String stFavSub) {
		this.stFavSub = stFavSub;
	}
	@Override
	public String toString() {
		return "    stId=" + stId + "\n stName=" + stName + "\n sdGender=" + sdGender + "\n stBranch=" + stBranch
				+ "\n stFavSub=" + stFavSub;
	}
	
}
