package com.aop.Aspects;


import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LogginAspect {
	@Before("execution(public * get*()) ")
	public void Validate() {
		System.out.println("Validate method_3 is Called");
	}
	@Before("execution(public * get*()) ")
	public void CheckLogin1(JoinPoint j)
	{
		System.out.println("Check Loggin Method_1 is called"+j.toString());
	}
	@Before("execution(public * get*()) ")
	public void CheckLogin2( )
	{
		System.out.println("Check_Loggin_Method_2 is called");
	}

}
