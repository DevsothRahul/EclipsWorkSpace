package com.aop.model;

import java.util.List;

public class DBoperations {
	public String insertEmpployee(Employee E) {
		System.out.println("Data inserted");
		return "1 row inserted";
	}

	public String UpdateEmpployee(Employee E, int empno) {
		System.out.println("Data Updated");
		return "1 row Updated";
	}

	public String deleteEmpployee(int empno) {
		System.out.println("Data deleted");
		return "1 row deleted";
	}

	public List<Employee> getEmpployee() {
		System.out.println("Get Employee method Called");
		return null;
	}
}
