package com.aop.model;

import java.util.List;

public class Dept {
	public int dno;
	private String dname;

	public int getDno() {
		return dno;
	}

	public void setDno(int dno) {
		this.dno = dno;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String AddDept() {
		return "1 dept added";
	}
	public List<Dept> getAll() {
		return null;
	}
}
