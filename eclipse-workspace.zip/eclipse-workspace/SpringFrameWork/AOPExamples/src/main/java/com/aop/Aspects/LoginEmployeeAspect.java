package com.aop.Aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import com.aop.model.Employee;

@Aspect
public class LoginEmployeeAspect {
//	@Before("AllMethod()")
//	public void AutheriseAdvice() {
//		System.out.println("Check the Autherization");
//	}
//
//	@Before("AllMethod()")
//	public void AuthenticateAdvice() {
//		System.out.println("Check the Athenticate for Updating");
//	}
//
//	@Pointcut("execution (public * *Empployee(..))")
//	public void AllMethod() {
//
//	}

	@AfterThrowing(value="execution (public String getDname())",throwing="ex") // Calling all the methods of Dept
	public void ThrowExceptionAdvice(JoinPoint joinPoint, Exception ex) {
		System.out.println("After Throwing exception in method:"+joinPoint.getSignature());  
	 System.out.println("Exception is:"+ex.getMessage());
	}
//
//	@AfterReturning(pointcut = "execution(* com.aop.model.Dept.getDname(..))", returning = "retVal")
//	public void logAfterReturningGetEmployee(Object retVal) throws Throwable {
//		System.out.println("LoggingAspect.logAfterReturningGetEmployee() ");
//		System.out.println(((Employee) retVal).getName());
//	}
}
