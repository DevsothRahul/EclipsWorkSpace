package com.aop.Aspects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class StudentAspect {
	@Before("execution(public String getName(..)) ")
	public void Validate(JoinPoint join) {
		System.out.println("Student profile setup completed " + join.toString());
	}
	@After("execution(public String getName(..)) ")
	public void Validate1(JoinPoint join) {
		System.out.println("Student profile setup  completed After " + join.toString());
	}
	@Pointcut(value = "execution(public String withdrawMoney(..))")
	private void logAfterWithdraw() {
	}

	@AfterThrowing(value = "logAfterWithdraw()", throwing = "exception")
	public void afterThrowingAdvice(JoinPoint jp, Throwable exception) {
		System.out.println("Inside afterThrowingAdvice() method....= " + jp.toString());
		System.out.println("Exception= " + exception);
	}

	@AfterReturning(value = "execution (public String ReturnSomething())", returning = "retVal")
	public void afterReturningAdvice(JoinPoint jp, String retVal) {
		System.out.println("Inside AfterReturning() method..." + jp.toString());
		System.out.println("Method returned value is : " + retVal);
	}

}
