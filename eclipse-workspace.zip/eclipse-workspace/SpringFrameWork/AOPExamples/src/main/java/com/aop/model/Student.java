package com.aop.model;

public class Student {
	private Integer age;
	private String name;

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String withdrawMoney(String accNum) throws Exception {
		String status = "";
		if (accNum.equals("12345")) {
			System.out.println("You have successfully withdrawn money from your account.");
			status = "Success";
		} else {
			status = "Exception Raised and Failure";
			throw new Exception(status);
		}
		return status;
	}
	public String ReturnSomething()
	{
		return "Rahul";
		
	}
}
