package AOPEx.AOPExamples;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aop.model.Circle;
import com.aop.model.DBoperations;
import com.aop.model.Dept;
import com.aop.model.Employee;
import com.aop.model.Shape;
import com.aop.model.Student;
import com.aop.model.Triangle;

public class App {
	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("AOPEx/AOPExamples/springaop.xml");
//	Triangle T = (Triangle) factory.getBean("trianle");
//	System.out.println(T.getName());
//		Circle C=(Circle) factory.getBean("circle");
//		System.out.println(C.getName());
//		Shape S=(Shape) factory.getBean("S");
//		System.out.println(S.getCircle().getName());
		
//		
//		DBoperations DB=(DBoperations) factory.getBean("dbop");
//		Employee E=new Employee();
//		System.out.println(DB.insertEmpployee(E));
//		System.out.println(DB.UpdateEmpployee(E,10));
//		System.out.println(DB.deleteEmpployee(10));
//		System.out.println(DB.getEmpployee());
		Dept D= (Dept) factory.getBean("D1");
		System.out.println(D.AddDept());
//		System.out.println(D.getDno()+"   "+D.getDname());


	}
}
