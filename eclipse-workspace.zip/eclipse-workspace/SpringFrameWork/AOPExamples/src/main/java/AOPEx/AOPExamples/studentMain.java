package AOPEx.AOPExamples;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.aop.model.Student;

public class studentMain {
	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("student.xml");
		Student student = (Student) factory.getBean("S");
		System.out.println(student.getName());
		String accnumber = "1234";
		try {
			System.out.println(student.withdrawMoney(accnumber));
		} catch (Exception e) {
			System.out.println("Catched Exception in main");
		}
		student.ReturnSomething();
	
	}
}
