package com.Example.Tw.demorestClient.Model.Dao;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.Example.Tw.demorestClient.Model.Pojo.Book;

public class BookServiceImpl {
	@Autowired
	RestTemplate restTemplate;
	public String url = "http://localhost:8082/api/";

	public List<Book> GetBooks() {
		Book books[] = restTemplate.getForObject(url + "getAll", Book[].class);
		return Arrays.asList(books);

	}

	public Book GetBooksById(int id) {
		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("bookId", id);
		System.out.println(params);
		Book books = restTemplate.getForObject(url + "getbyId/" + id, Book.class, params);
		System.out.println(books);
		return books;
	}

	public String InsertBook(Book B) {
		return restTemplate.postForObject(url + "insertbook", B, String.class);

	}

	public String Update(Book B) {
		restTemplate.put(url + "update", B);
		return "1 Row updatd";

	}

	public String DeleteById(int id) {
		restTemplate.delete(url+"deletebook/"+id, String.class);	
		return "1 Row Deletd";
	}

}
