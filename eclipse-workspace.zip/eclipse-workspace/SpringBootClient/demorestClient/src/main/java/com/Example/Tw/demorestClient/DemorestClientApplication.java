package com.Example.Tw.demorestClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.Example.Tw.demorestClient.Model.Dao.BookServiceImpl;

@SpringBootApplication
public class DemorestClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemorestClientApplication.class, args);
		System.out.println("Rest Client");
	}
	@Bean
	public RestTemplate getRestteRestTemplate() {
		return new RestTemplate();

	}
	@Bean
	public BookServiceImpl bookServiceImpl() {
		return new BookServiceImpl();

	}
}
