package com.Example.Tw.demorestClient.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Example.Tw.demorestClient.Model.Dao.BookServiceImpl;
import com.Example.Tw.demorestClient.Model.Pojo.Book;

@Controller
public class BookController {
	@Autowired
	BookServiceImpl bookServiceImpl;

	@RequestMapping("/")
	public String Home(Model M) {
		return "Home";
	}

	@RequestMapping("/detAllBooks")
	public String GetAllBooks(Model M) {

		M.addAttribute("Blist", bookServiceImpl.GetBooks());
		System.out.println("all books");
		return "DisplayBooks";
	}

	@RequestMapping("/ById")
	public String GetAllBooksById(Model M) {
		M.addAttribute("list", bookServiceImpl.GetBooks());
		return "getById";
	}

	@RequestMapping("/getting")
	public String GetAllBooksById1(Model M, @RequestParam("bid") int id) {
		// System.out.println("ID:" + id);
		M.addAttribute("Blist", bookServiceImpl.GetBooksById(id));
		return "DisplayBooksById";
	}

	@RequestMapping("/Insert")
	public String Insert(Model m) {
		return "Insert";
	}

	@RequestMapping("/Inserted")
	public String Insert1(Model M, @ModelAttribute("B") Book B) {
		// System.out.println(B.getBookId()+" "+B.getDop());
		M.addAttribute("msg", bookServiceImpl.InsertBook(B));

		return "Insert";
	}

	@RequestMapping("/updateById")
	public String updateById(Model M) {
		M.addAttribute("Blist", bookServiceImpl.GetBooks());
		return "updateById";
	}

	@RequestMapping("/update")
	public String updateById1(Model M, @RequestParam("bid") int id) {
		M.addAttribute("list", bookServiceImpl.GetBooksById(id));
		return "updating";
	}

	@RequestMapping("/updated")
	public String updatedBook(Model M, @ModelAttribute("B") Book B) {
		String S = bookServiceImpl.Update(B);
		M.addAttribute("msg", S);
		return "updating";
	}

	@RequestMapping("/deleteById")
	public String deleteById(Model M) {
		M.addAttribute("Blist", bookServiceImpl.GetBooks());
		return "deleteById";
	}

	@RequestMapping("/deleted")
	public String Deleteting(Model M, @RequestParam("bid") int id) {
		M.addAttribute("msg", bookServiceImpl.DeleteById(id));
		return "deleteById";
	}

}
