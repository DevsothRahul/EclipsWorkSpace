package com.Example.Tw.demorestClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemorestClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
