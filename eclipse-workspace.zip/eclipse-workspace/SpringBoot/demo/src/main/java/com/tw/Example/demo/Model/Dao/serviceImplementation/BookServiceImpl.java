package com.tw.Example.demo.Model.Dao.serviceImplementation;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tw.Example.demo.Model.Dao.service.BookService;
import com.tw.Example.demo.Model.Pojo.Book;
import com.tw.Example.demo.Repository.BookRepository;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	BookRepository bookRepository;

	@Override
	public String insertBook(Book B) {
		bookRepository.save(B);
		return "1 Row added";

	}

	@Override
	public List<Book> getAll() {
		List<Book> B = bookRepository.findAll();
		for (Book b : B) {
			System.out.println(b.toString());
		}
		return B;

	}

	@Override
	public String DeleteBookById(int bookId) {
		Optional<Book> B = bookRepository.findById(bookId);
		// B.stream().filter(i->i.getBookId()==bookid).collect(Collectors.toList());
		if (B.isPresent()) {
			bookRepository.deleteById(bookId);
			return "1 Row Deleted";
		} else {
			return "Record Not Found";
		}

	}

	@Override
	public String UpdateBookById(Book b, int bid) {
		Optional<Book> B = bookRepository.findById(bid);
		if (B.isPresent()) {
			bookRepository.save(b);
			return "1 Row updated";
		} else {
			return "Record Not found";
		}

	}

	@Override
	public Book GetById(int bookId) {
		Optional<Book> B = bookRepository.findById(bookId);
		if (B.isPresent()) {
			return B.get();

		}
		return null;

	}

	@Override
	public String update(Book B) {
		bookRepository.save(B);
		return "1 Row Updated";
	}

	@Override
	public List<Book> getbyName(String s) {

		return bookRepository.findByBookName(s);
	}

	@Override
	public List<Book> getByDop(LocalDate dop) {
		// TODO Auto-generated method stub
		return bookRepository.findByDopGreaterThan(dop);
	}

	@Override
	public List<Book> getByType(String s) {

		return bookRepository.findByType(s);
	}

//	@Override
//	public List<Book> getBydopandpublisher(LocalDate dop, String type) {
//		
//		return bookRepository.fetchbyDopandpublisher(dop, type);
//	}

//	@Override
//	public List<Book> getWithDop(LocalDate dop) {
//		
//		return bookRepository.fetchbyDop(dop);
//	}

	@Override
	public List<Book> getbyBookNameLike(String bookName) {

		return bookRepository.findByBookNameLike(bookName);
	}

	@Override
	public String deleteBook(Book book) {
		bookRepository.delete(book);
		return "1 Row deleted";
	}

}
