package com.tw.Example.demo.Controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tw.Example.demo.Model.Dao.serviceImplementation.BookServiceImpl;
import com.tw.Example.demo.Model.Pojo.Book;

@RestController
@RequestMapping("/api")
public class BookController {
	@Autowired
	BookServiceImpl bookServiceImpl;

	@PostMapping("/insertbook")
	public String insertintoBook(@RequestBody Book B) {
		String s = bookServiceImpl.insertBook(B);
		return s;
	}

	@GetMapping("/getAll")
	public List<Book> GetAll() {
		return bookServiceImpl.getAll();
	}

	@DeleteMapping("/deletebook/{Id}")
	public String DeleteBook(@PathVariable("Id") int Id) {
		// String s = bookServiceImpl.DeleteBookById(Id);
		String s = bookServiceImpl.deleteBook(bookServiceImpl.GetById(Id));
		return s;
	}

	@PutMapping("/updatebook/{Id}")
	public String UpdateBook(@RequestBody Book B, @PathVariable("Id") int Id) {
		String s = bookServiceImpl.UpdateBookById(B, Id);
		return s;
	}

	@GetMapping("/getbyId/{id}")
	public Book GetAllById(@PathVariable("id") int id) {
		return bookServiceImpl.GetById(id);
	}

	@PutMapping("/update")
	public String update(@RequestBody Book B) {
		return bookServiceImpl.update(B);

	}

	@GetMapping("getByname/{name}")
	public List<Book> GetbyyName(@PathVariable("name") String bName) {
		return bookServiceImpl.getbyName(bName);

	}

	@GetMapping("getByDop/{dop}")
	public List<Book> GetbyDop(@PathVariable("dop") String dop) {

		return bookServiceImpl.getByDop(LocalDate.parse(dop));
	}

	@GetMapping("getByType/{type}")
	public List<Book> GetbyType(@PathVariable("type") String type) {
		return bookServiceImpl.getbyName(type);

	}
	/*
	 * @GetMapping("getByDopandtype/{dop},{type}") public List<Book>
	 * GetbyType1(@PathVariable("dop") String dop, @PathVariable("type") String
	 * type) { return bookServiceImpl.getBydopandpublisher(LocalDate.parse(dop),
	 * type);
	 * 
	 * }
	 */

	@GetMapping("getLike/{name}")
	public List<Book> GetwithDop(@PathVariable("name") String name) {
		return bookServiceImpl.getbyBookNameLike(name);

	}

}
