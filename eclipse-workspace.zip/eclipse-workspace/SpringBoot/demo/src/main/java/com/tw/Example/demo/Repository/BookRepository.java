package com.tw.Example.demo.Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.tw.Example.demo.Model.Pojo.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {
	public List<Book> findByBookName(String bookName);
	public List<Book> findByDopGreaterThan(LocalDate dop);
	public List<Book> findByType(String type);
	//public List<Book> fetchbyDopandpublisher(LocalDate dop,String type);//Named Query
	//public List<Book> fetchbyDop(@Param("dop") LocalDate dop);//NamedQuery
	public List<Book> findByBookNameLike(String bookName);

}
