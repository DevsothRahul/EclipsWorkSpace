package com.tw.Example.demo.Model.Pojo;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "TblBook")
/*
 * @NamedQueries({
 * 
 * @NamedQuery(name = "fetchbyDopandpublisher", query =
 * "select from Book where DOP>:dp and PUBLISHER=:p"),
 * 
 * @NamedQuery(name = "Book.fetchbyDop", query =
 * "select b from Book  b where b.DOP:>dp"), })
 */
public class Book {
	@Id
	private int bookId;
	@Column(length = 25)
	private String bookName;
	@Column(length = 25)
	private String publisher;
	@Column(length = 25)
	private String type;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dop;
	private int price;

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public LocalDate getDop() {
		return dop;
	}

	public void setDop(LocalDate dop) {
		this.dop = dop;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public Book(int bookId, String bookName, String publisher, String type, LocalDate dop, int price) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.publisher = publisher;
		this.type = type;
		this.dop = dop;
		this.price = price;
	}

	public Book() {
		super();
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", publisher=" + publisher + ", type=" + type
				+ ", dop=" + dop + ", price=" + price + "]";
	}

}
