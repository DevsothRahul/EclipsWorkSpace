package com.tw.Example.demo.Model.Dao.service;

import java.time.LocalDate;
import java.util.List;

import com.tw.Example.demo.Model.Pojo.Book;

public interface BookService {
	String insertBook(Book B);
	List<Book> getAll();
	Book GetById(int id);
	String DeleteBookById(int Id) ;
	String deleteBook(Book book);
	String UpdateBookById(Book B,int bid);
	String update(Book B);
	List<Book> getbyName(String bookName);
	List<Book> getByDop(LocalDate dop);
	List<Book> getByType(String s);

	/*
	 * List<Book> getBydopandpublisher(LocalDate dop,String type); List<Book>
	 * getWithDop(LocalDate dop);
	 */
	List<Book> getbyBookNameLike(String bookName);
}
