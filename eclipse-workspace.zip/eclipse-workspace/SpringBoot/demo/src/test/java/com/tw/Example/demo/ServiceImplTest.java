package com.tw.Example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.tw.Example.demo.Model.Dao.service.BookService;
import com.tw.Example.demo.Model.Pojo.Book;
import com.tw.Example.demo.Repository.BookRepository;

@SpringBootTest
class ServiceImplTest {
	@Autowired
	BookService bookService;
	@MockBean
	BookRepository bookRepository;

	@Test
	void testgetAll() {
		when(bookRepository.findAll()).thenReturn(Stream
				.of(new Book(1, "ABC", "MS", "Story", LocalDate.parse("2000-01-01"), 120),
						new Book(2, "CDE", "MR", "Story", LocalDate.parse("2000-01-01"), 160),
						new Book(2, "EfG", "LUC", "History", LocalDate.parse("2010-01-01"), 140))
				.collect(Collectors.toList()));
		assertEquals(3, bookService.getAll().size());
	}

	@Test
	void testinsertBook() {
		Book B = new Book(1, "ABC", "MCR", "Love", LocalDate.parse("2000-01-01"), 190);
		// when(bookService.insertBook(B)).thenReturn(B);
		// assertEquals(B, bookService.insertBook(B));
		when(bookRepository.save(B)).thenReturn(B);
		String string1 = "1 Row added";
		assertEquals(string1, bookService.insertBook(B));
		// String st2=bookService.insertBook(B);
		// System.out.println(st2);
		// assertSame(string1, st2);
		verify(bookRepository, times(1)).save(B);
	}

	@Test
	void testdeleteBook() {
		String string1 = "1 Row deleted";
		Book B = new Book(1, "ABC", "MCR", "Love", LocalDate.parse("2000-01-01"), 190);
		assertEquals(string1, bookService.deleteBook(B));
		verify(bookRepository, times(1)).delete(B);
	}

}
