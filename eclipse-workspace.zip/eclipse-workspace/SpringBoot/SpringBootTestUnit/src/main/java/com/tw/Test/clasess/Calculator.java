package com.tw.Test.clasess;

public class Calculator {
	public int Add(int a,int b)
	{
		return a+b;
	}
	public int Product(int a,int b)
	{
		return a*b;
	}

}
