package com.tw.TestUnit;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.tw.Test.clasess.Calculator;

public class TestCalculator {
	Calculator C=null;
	@Before
	public void setUp()
	{
		C=new Calculator();
	}
	@After
	public void done()
	{
		C=null;
	}
	@Test
	public void testAdd()
	{
		System.out.println(C);
		assertEquals(210,C.Add(10, 200));
	}
	
	@Test
	public void testProduct()
	{
		System.out.println(C);
		assertEquals(100,C.Product(10, 10));
	}

}
