package com.tw.restapi.Model.Dao;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.tw.restapi.Model.pojo.Persons;
@Repository
@Transactional
public class Personsdao {
	@Autowired
	private SessionFactory sessionFactory;
	

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session getSession() {
		Session session=sessionFactory.getCurrentSession();
		if(session==null)
		{
			return sessionFactory.getCurrentSession();
		}
		else
		{
			return session;
		}
	}

	public String insertintoPersons(Persons P) {
		 getSession().save(P); 
		  return "1 Row Added";
		 		
	}

	@SuppressWarnings("deprecation")
	public List<Persons> getAllPersons() {
		return getSession().createCriteria(Persons.class).list();
	}

}
