package com.tw.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tw.restapi.Model.pojo.Persons;

public interface Personsrep extends JpaRepository<Persons, Long> {

}
