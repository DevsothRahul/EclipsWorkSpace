package com.tw.restapi.Model.Dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.tw.restapi.Model.pojo.Emp;

public class Empdao {

	static List<Emp> list = new ArrayList<Emp>();

	public Empdao() {
		list.add(new Emp(1, "A", LocalDate.parse("2022-01-20"), (double) 30000));
		list.add(new Emp(2, "b", LocalDate.parse("2022-01-20"), (double) 20000));
		list.add(new Emp(3, "c", LocalDate.parse("2022-01-20"), (double) 50000));
		list.add(new Emp(4, "d", LocalDate.parse("2022-01-20"), (double) 30000));
		list.add(new Emp(5, "e", LocalDate.parse("2022-01-20"), (double) 30000));

	}

	public List<Emp> getAll() {
		return list;
	}

	public Emp getById(int id) {
		return list.stream().filter(i -> i.getEmpno() == id).collect(Collectors.toList()).get(0);
	}

	public   String insertEmp(Emp E)
	{
		list.add(E);
		return "1 Emp Added";
	}

	public String updateEmp(@RequestBody Emp ns,@PathVariable("id") int id)
	{
		list.set(id, ns);
		return "1 Row Updated";
	}
	public String DeleteEmp(@PathVariable("id") int id)
	{
		list.remove(id);
		return "1 Row Deleted";
	}
	
}
