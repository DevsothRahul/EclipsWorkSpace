package com.tw.restapi.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class DemoController {

	static String[] list = new String[] { "One", "Two", "three", "Four", "Five" };
	static List<String> list1 = new ArrayList<String>();

	public DemoController() {
		list1.add("One-One");
		list1.add("Two-2");
		list1.add("Three-3");
		list1.add("four-4");
		list1.add("Five-5");
		list1.add("Six-6");
	}

	@GetMapping("/string")

	public String[] displyList() {
		return list;
	}

	/*
	 * @GetMapping("/{id}") public String displyList(@PathVariable("id") int i) {
	 * return list[i]; }
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	// @GetMapping("/")
	public List<String> GetString() {
		return list1;
	}

	@RequestMapping(value = "{id}", method = RequestMethod.GET)
	// @GetMapping("/{id}")
	public String displyList1(@PathVariable("id") int i) {
		return list1.get(i);
	}

	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	// @PostMapping("/insert")
	public void addString(@RequestBody String s) {
		list1.add(s);
	}

	@RequestMapping(value = "/modify/{id}", method = RequestMethod.PUT)
	// @PutMapping("/modify/{id}")
	public void Modify(@RequestBody String ns, @PathVariable("id") int id) {
		list1.set(id, ns);
	}

	@RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
	// @DeleteMapping("/delete/{id}")
	public void delete(@PathVariable("id") int id) {
		list1.remove(id);
	}

}
