package com.tw.restapi.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.tw.restapi.Model.Dao.Personsdao;
import com.tw.restapi.Model.pojo.Persons;
import com.tw.restapi.repository.Personsrep;

@RestController
@RequestMapping("/api")
public class PersonsController {
	
	private Personsdao personsdao;

	public Personsdao getPersonsdao() {
		return personsdao;
	}

	public void setPersonsdao(Personsdao personsdao) {
		this.personsdao = personsdao;
	}

	@PostMapping("/save")
	public String create(@RequestBody Persons P) {
//		personsdao.insertintoPersons(P);
//		P=new Persons();
//		P.setId(2);
//		P.setName("Rahul");
//		P.setCity("Hyd");
//		System.out.println(P.getId()+" "+P.getName());
		String s=personsdao.insertintoPersons(P);
		return s;
	}
	@GetMapping("/Pall")
	public List<Persons> getAllPersons()
	{
//		List<Persons> l= personsdao.getAllPersons();
//		l.stream().forEach(i->System.out.println(i.toString()));
		return personsdao.getAllPersons();
	}
	
	
}
