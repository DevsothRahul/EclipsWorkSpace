package com.tw.restapi.Model.pojo;

import java.time.LocalDate;

public class Emp {
	private int empno;
	private String ename;
	private LocalDate doj;
	private Double basic;

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public Double getBasic() {
		return basic;
	}

	public void setBasic(Double basic) {
		this.basic = basic;
	}

	public Emp(int empno, String ename, LocalDate doj, Double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.doj = doj;
		this.basic = basic;
	}

	public Emp() {
		super();
	}
}
