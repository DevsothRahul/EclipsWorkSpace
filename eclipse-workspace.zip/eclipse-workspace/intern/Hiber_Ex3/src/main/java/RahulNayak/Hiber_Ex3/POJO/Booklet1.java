package RahulNayak.Hiber_Ex3.POJO;

import java.time.LocalDate;
public class Booklet1 {
	private int bookId;
	private String bookName;
	/**
	 * @param bookId the bookId to set
	 */
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	/**
	 * @param bookName the bookName to set
	 */
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	/**
	 * @param cost the cost to set
	 */
	public void setCost(double cost) {
		this.cost = cost;
	}
	/**
	 * @param pub_date the pub_date to set
	 */
	public void setPub_date(LocalDate pub_date) {
		this.pub_date = pub_date;
	}
	private String author;
	private double cost;
	private LocalDate pub_date;
	public Booklet1()
	{
		
	}
	public Booklet1(int bookId, String bookName, String author, double cost, LocalDate pub_date) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
		this.cost = cost;
		this.pub_date = pub_date;
	}
	public int getBookId() {
		return bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public String getAuthor() {
		return author;
	}
	public double getCost() {
		return cost;
	}
	public LocalDate getPub_date() {
		return pub_date;
	}

}
