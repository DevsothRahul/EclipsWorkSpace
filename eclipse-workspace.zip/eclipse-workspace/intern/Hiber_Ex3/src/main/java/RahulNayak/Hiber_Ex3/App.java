package RahulNayak.Hiber_Ex3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import RahulNayak.Hiber_Ex3.POJO.Booklet1;
public class App 
{
    public static void main( String[] args )
    {
       Configuration cfg=new Configuration();
       cfg.configure("RahulNayak/Hiber_Ex3/hibernate.cfg.xml");
       SessionFactory factory=cfg.buildSessionFactory();
       Session session=factory.openSession();
       DateTimeFormatter  D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
       Booklet1 B=new Booklet1(1,"RaGhuPati Raghava Raja Ram","Anjali",10,LocalDate.parse("01-Oct-2000",D));
       Transaction T=session.beginTransaction();
       session.save(B);
       T.commit();
       session.close();
       factory.close();
       
    }
}
