package com.Techwave.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Location2 {
	@Id
	private int locationId;
	@Column(length = 20)
	private String name;
	@Column(length = 20)
	private String address;
	@OneToMany
	@JoinColumn
	private List<Employee2> employee;

	public List<Employee2> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee2> employee) {
		this.employee = employee;
	}

	public Location2(int locationId, String name, String address) {
		super();
		this.locationId = locationId;
		this.name = name;
		this.address = address;
	}

	public int getLocationId() {
		return locationId;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

}
