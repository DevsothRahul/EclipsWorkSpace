package com.Techwave.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Employee {
	@Id
	private int empno;
	@Column(length = 20)
	private String empName;
	@OneToOne
	private Location location;
	public Employee(int empno, String empName, Location location) {
		super();
		this.empno = empno;
		this.empName = empName;
		this.location = location;
	}
	public int getEmpno() {
		return empno;
	}
	public String getEmpName() {
		return empName;
	}
	public Location getLocation() {
		return location;
	}
	
	

}
