//One to Many
package com.Techwave;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cgf=new Configuration();
        cgf.configure("com/Techwave/hibernate.cfg.xml");
        SessionFactory factory=cgf.buildSessionFactory();
        Session session=factory.openSession();
        
        session.close();
        factory.close();
        
    }
}
