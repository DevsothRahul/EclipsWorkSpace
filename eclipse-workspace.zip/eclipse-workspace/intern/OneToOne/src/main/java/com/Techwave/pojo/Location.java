package com.Techwave.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Location {
	@Id
	private int locationId;
	@Column(length = 20)
	private String name;
	@Column(length = 20)
	private String address;
	public Location(int locationId, String name, String address) {
		super();
		this.locationId = locationId;
		this.name = name;
		this.address = address;
	}
	public int getLocationId() {
		return locationId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}

}
