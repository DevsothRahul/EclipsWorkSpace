package com.Techwave.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Employee2 {
	@Id
	private int empno;
	@Column(length = 20)
	private String empName;
	public Employee2(int empno, String empName) {
		super();
		this.empno = empno;
		this.empName = empName;

	}
	public int getEmpno() {
		return empno;
	}
	public String getEmpName() {
		return empName;
	}
	
	

}
