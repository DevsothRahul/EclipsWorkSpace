package PracticeExam;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;			

abstract class Emp implements ICalculate
{
	private int id;
	private String name;
	private String gender;
	private String city;
	private LocalDate doj;
	
	public void Accept( int id,String name,String gender,String city,LocalDate doj)
	{
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.city = city;
		this.doj = doj;
	}
	public void print() {
		System.out.println("Id"+ id);
		//return  "empId:" + id + "\nEmpname:" + name + "\nEmGender: " + gender +  "\n Emp City:" + city+"\n Goj"+getDoj();
	}
	public LocalDate getDoj() {
		return doj;
	}
	class Pemp extends Emp
	{
		private double sal;
		private double inc;
		public void Accept(int id,String name,String gender,String city,LocalDate doj,double sal)
		{
			super.Accept(id, name, gender, city, doj);
			this.sal=sal;
		}
		@Override
		public void CalculateIncrement() {
			
			//LocalDate L=LocalDate.of(2017, 01, 01);
			LocalDate L=LocalDate.parse("2017-01-01");
			if(this.getDoj().compareTo(L)==-1)
			{
				inc=inc+sal*(25/100);
			}
			else
			{
				inc=inc+sal*(10/100);
			}
		}
	}
	public void Print()
	{
		//super.print();
		CalculateIncrement();
	}

	
}
public class Emp1 {
public static void main(String[] args) {
	
	
	Scanner sc=new Scanner(System.in);
	int id;
	String name,gender,city;
	LocalDate doj;
	double sal;
	
	Pemp P[]=new Pemp[3];
	for(int i=0;i<P.length;i++)
	{
		P[i]=new Pemp();
		id=sc.nextInt();
		sc.nextLine();
		name=sc.nextLine();
		gender=sc.nextLine();
		city=sc.nextLine();
		doj=LocalDate.parse(sc.nextLine());
		sal=sc.nextDouble();
		//P[i].Accept();
	}
	//System.out.println(E.print());
}
}
