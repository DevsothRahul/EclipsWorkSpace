package PracticeExam;

public interface ICalculate {
	void CalculateIncrement();
	
	
}
