//Accept a list Vehicle registration nos and display those which are valid vehicle nos
//TS 2 A 6789  Valid
//TS 08 A 7878  Valid
//TS 09 AV 7865 Valid
//TS 6767 Invalid
//TS 09 7878 Invalid
package JAVA8Fe_Assignment_onJava8;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public class Q3 {
	public static void main(String[] args) {
		List<String> li = new ArrayList<>();
		Scanner Sc = new Scanner(System.in);
		int no = Sc.nextInt();
		Sc.nextLine();
		for (int i = 0; i < no; i++) {
			li.add(Sc.nextLine());
		}
//	Predicate<String>f=new Predicate<String>() {
//		
//		@Override
//		public boolean test(String t) {
//			if(t.matches("[A-Z]{2}\\s[0-9]{1,2}\\s[A-Z]{1,2}\\s[0-9]{4}"))
//				return true;
//			return false;
//		}
//	};
//	li.stream().filter(f).forEach(i->System.out.println("Valid vehicle No:"+i));
		li.stream().filter(i -> i.matches("[A-Z]{2}\\s[0-9]{1,2}\\s[A-Z]{1,2}\\s[0-9]{4}"))
				.forEach(i -> System.out.println(i));

	}
}
