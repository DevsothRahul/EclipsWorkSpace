//Accept a list of Integers and display the maximum value.
package JAVA8Fe_Assignment_onJava8;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
public class Q2 {
	public static void main(String[] args) {
		List<Integer> list=new ArrayList<Integer>();
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		for(int i=0;i<no;i++)
		{
			
			list.add(sc.nextInt());
		}
//		Integer i=Collections.max(list);
//		System.out.println(i);
		
		//System.out.println(list.stream().reduce(Integer.MIN_VALUE,(a,b)->a>b?a:b));
		
		list.stream().mapToInt(i->i).distinct().max().ifPresent(i->System.out.println(i));
		
		
	
	}
}
