//1.Accept a list Dates (Dob)  and display the ages who are more than 30.

package JAVA8Fe_Assignment_onJava8;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Q1 {
	public static void main(String[] args) {
		DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		List<LocalDate>D1=new ArrayList<LocalDate>();
		for(int i=0;i<no;i++)
		{
			
			D1.add(LocalDate.parse(sc.next(),D));
		}
		
		LocalDate d=LocalDate.now();
		D1.stream().filter(o1->d.compareTo(o1)>30).forEach(i->System.out.println(i));
	}

}
