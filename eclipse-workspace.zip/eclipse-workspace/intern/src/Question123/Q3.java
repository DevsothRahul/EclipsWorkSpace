package Question123;

import java.util.Scanner;

class Sales {
	private int id;
	public int getId() {
		return id;
	}

	public double getSaleamt() {
		return saleamt;
	}

	private double saleamt;

	public Sales(int id, double saleamt) {
		super();
		this.id = id;
		this.saleamt = saleamt;
	}

}

public class Q3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no of Sales:");
		int no=sc.nextInt();
		int id;
		double maxamt=0,sum=0;
		double minamt=Integer.MAX_VALUE;
			int	maxid=0;
			int minid=0;
		double amt;
		Sales[] S=new Sales[no];
		for(int i=0;i<no;i++)
		{
			
			id=sc.nextInt();
			amt=sc.nextDouble();
			S[i]=new Sales(i, amt);
		}
		for(int i=0;i<S.length;i++)
		{
			if(maxamt<S[i].getSaleamt())
			{
				maxamt=S[i].getSaleamt();
				maxid=S[i].getId();
			}
			if(minamt>S[i].getSaleamt())
			{
				minamt=S[i].getSaleamt();
				minid=S[i].getId();
			}
			sum=sum+S[i].getSaleamt();
			
		}
		System.out.println("Salesperson \"+ maxid +\" had the highest sale with  "+ maxamt);
		System.out.println("Salesperson \"+ minid +\" had the lowest sale with  "+ minamt);
		System.out.println("avg:"+ sum/no);
		for(int i=0;i<S.length;i++)
		{
			if(S[i].getSaleamt()>20000)
			{
				System.out.println(S[i].getId()+ " " +S[i].getSaleamt());
			}
		}
	}

}
