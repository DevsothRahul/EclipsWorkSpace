package Question123;

import java.time.LocalDate;
import java.util.Scanner;

abstract class Employee implements Icalculate {
	private int id;
	private String name;

	private String gender;;
	private String city;
	private LocalDate doj;

	public LocalDate getDoj() {
		return doj;
	}

	void Accept(int id, String name, String gender, String city, LocalDate doj) {
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.city = city;
		this.doj = doj;
	}

	void print() {
		System.out.println("Emp Id:" + id);
		System.out.println("Emp name:" + name);
		System.out.println("Emp Gender:" + gender);
		System.out.println("Emp city:" + city);
		System.out.println("Emp Doj:" + doj);
	}

}

class PerEmp extends Employee {
	private double salary;
	private double increment;

	public void Accept(int id, String name, String gender, String city, LocalDate doj, double salary) {
		super.Accept(id, name, gender, city, doj);
		this.salary = salary;
	}

	public void print() {
		super.print();
		System.out.println("Emp Sal:" + salary);
		CalculateIncrement();
		System.out.println("Emp inc:" + increment);
	}

	public void CalculateIncrement() {
		LocalDate D = LocalDate.parse("2017-01-01");
		if (this.getDoj().compareTo(D) == -1) {
			increment = salary + salary * (25 / 100);
		} else {
			increment = salary + salary * (10 / 100);
		}
	}

	public class Q2 {
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);

			System.out.println("Enter the no of Employees:\n");
			int no = sc.nextInt();
			PerEmp p[] = new PerEmp[no];
			int id;
			String name, g, c;
			LocalDate d;
			double sal;
			for (int i = 0; i < no; i++) {
				p[i] = new PerEmp();
				System.out.println("enter Emp id:\n");
				id = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter Emp Name:");
				name = sc.nextLine();
				System.out.println("Emp Gender:");
				g = sc.nextLine();
				System.out.println("Emp City:");
				c = sc.nextLine();
				System.out.println("Emp Doj:");
				d = LocalDate.parse(sc.nextLine());
				System.out.println("Emp Salary:");
				sal = sc.nextDouble();
				p[i].Accept(id, name, g, c, d, sal);
			}
			for (int i = 0; i < p.length; i++) {
				p[i].CalculateIncrement();
				p[i].print();
			}
		}
	}
}
