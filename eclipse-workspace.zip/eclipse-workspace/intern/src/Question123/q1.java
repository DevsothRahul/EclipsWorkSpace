package Question123;

import java.util.Scanner;

public class q1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Character Array:\n");
		int n=sc.nextInt();
		char[] a=new char[n];
		int[] b=new int[n];
		System.out.println("Enter character Array:\n");
		for(int i=0;i<n;i++)
		{
			a[i]=sc.next().charAt(0);
		}
		System.out.println("Enter the integer array:\n");
		for(int i=0;i<n;i++)
		{
			b[i]=sc.nextInt();
		}
		System.out.println("Enter the number:\n");
		int no=sc.nextInt();
		System.out.println("Enter the  character to search:\n");
		char ch=sc.next().charAt(0);
		int sum=0;
		for(int i=0;i<n;i++)
		{
			if(a[i]==ch && b[i]>no)
			{
				sum=sum+b[i];
			}
		}
		System.out.println(sum);
	}
}
