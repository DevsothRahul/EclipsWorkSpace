package Question123;

public interface Icalculate {
	void CalculateIncrement();
}
