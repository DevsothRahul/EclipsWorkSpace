import java.util.List;

public class empBl {
public  List<Emp> getByValues(String[] arr)
{
	return DataDl.Arry(arr);
	
}
}
