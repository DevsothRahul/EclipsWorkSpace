package SETexamples;

public class equalHashmap {

}
