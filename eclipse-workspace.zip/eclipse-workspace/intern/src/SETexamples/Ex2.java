package SETexamples;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Set;

public class Ex2 {
	public static void main(String[] args) {
		HashMap<String, String> HM=new HashMap<String,String>();
		HM.put("Hyd","500080" );
		HM.put("RCB","500010" );
		HM.put("DC","500301" );
		HM.put("DC","500301" );
		HM.put("DC3","500301" );
		HM.put("CSK","500401" );
		HM.put("NKD",null );
		HM.put(null,"500080" );
		System.out.println(HM.get("CSK"));
		Set<String> S=HM.keySet();
		for(String s:S)
		{
			System.out.println(s+ " "+HM.get(s));
		}
		System.out.println();
		HashMap<String, Integer> HM1=new HashMap<String,Integer>();
		HM1.put("Hyd",500080 );
		HM1.put("RCB",500010 );
		HM1.put("DC",500301 );
		HM1.put("DC",500301 );
		HM1.put("DC3",500301 );
		HM1.put("CSK",500401 );
		HM1.put("NKD",null );
		HM1.put(null,500080 );
		System.out.println(HM1.get("CSK"));
		Set<String> S2=HM1.keySet();
		for(String s:S2)
		{
			System.out.println(s+ " "+HM1.get(s));
		}
		System.out.println();
		Hashtable<String, String> Ht=new Hashtable<String,String>();
		Ht.put("Hyd","500080" );
		Ht.put("RCB","500010" );
		Ht.put("DC","500301" );
		Ht.put("DC","500301" );
		Ht.put("DC3","500301" );
		Ht.put("CSK","500401" );
		//Ht.put("NKD",null );
		//Ht.put(null,"500080" );
		System.out.println(Ht.get("CSK"));
		Set<String> S1=Ht.keySet();
		for(String s:S1)
		{
			System.out.println(s+ " "+Ht.get(s));
		}
	}
}
