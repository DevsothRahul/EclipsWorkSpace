package SETexamples;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

public class setEx1 {
	public static void main(String[] args) {
		Set<Integer> S=new HashSet<Integer>();
		S.add(20);
		S.add(120);
		S.add(120);
		S.add(110);
		S.add(180);
		S.add(100);
		for(Integer I:S)
		{
			System.out.println(I);
		}
		System.out.println();
		List<Integer> L=new ArrayList<Integer>();
		L.add(20);
		L.add(120);
		L.add(120);
		L.add(110);
		L.add(180);
		L.add(100);
		for(Integer I:L)
		{
			System.out.println(I);
		}
		System.out.println();
		Set<Integer> T=new TreeSet<Integer>();
		T.add(20);
		T.add(120);
		T.add(120);
		T.add(110);
		T.add(180);
		T.add(100);
		for(Integer I:T)
		{
			System.out.println(I);
		}
		System.out.println();
		Set<Integer> LH=new LinkedHashSet<>();
		LH.add(20);
		LH.add(120);
		LH.add(120);
		LH.add(110);
		LH.add(180);
		LH.add(100);
		for(Integer I:LH)
		{
			System.out.println(I);
		}
		
		
		
		System.out.println();
		Stack<Integer> St=new Stack<Integer>();
		St.push(100);
		St.push(200);
		St.push(50);
		
		
				
		
	}
}
