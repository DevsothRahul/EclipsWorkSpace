package JAVA8Feature_Collectors;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;

import JAVA8Fe.Employee;

public class Ex6Fe_Reduce1 {
public static void main(String[] args) {
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	List<Employee> L=Arrays.asList(
			new Employee(1,"Rahul",LocalDate.parse("01-Jul-2002",D),30000),
			new Employee(2,"Raju",LocalDate.parse("21-Jun-2002",D),70000),
			new Employee(3,"RaKhi",LocalDate.parse("01-Jan-2002",D),12000),
			new Employee(4,"Ramulu",LocalDate.parse("01-Sep-2002",D),50000)
			);
	
//	BinaryOperator<Employee>b=new BinaryOperator<Employee>() {
//		@Override
//		public Employee apply(Employee t, Employee u) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//	};
	System.out.println(L.stream().map(i->i.getBasic()).reduce(0.0, (a, b) -> a + b));
}
}
