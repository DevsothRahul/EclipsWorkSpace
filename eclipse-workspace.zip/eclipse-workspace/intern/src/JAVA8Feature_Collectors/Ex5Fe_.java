package JAVA8Feature_Collectors;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import JAVA8Fe.Employee;

public class Ex5Fe_ {
public static void main(String[] args) {
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	List<Employee> L=Arrays.asList(
			new Employee(1,"Rahul",LocalDate.parse("01-Jul-1999",D),30000),
			new Employee(2,"Raju",LocalDate.parse("21-Jun-2022",D),70000),
			new Employee(3,"RaKhi",LocalDate.parse("01-Jan-1960",D),12000),
			new Employee(4,"Ramulu",LocalDate.parse("01-Sep-2021",D),50000)
			);
	Function<Employee, Employee>f=new Function<Employee, Employee>() {
		@Override
		public Employee apply(Employee t) {
			
			 t.setBasic(t.getBasic()+0.1*t.getBasic());
			 return t;
		}
	};
	L.stream().map(f).forEach(i->System.out.println(i.getEmpNo()+" "+i.getBasic()));
	//L.stream().map(t->{t.setBasic(t.getBasic()+0.1*t.getBasic());return t;}).forEach(i->System.out.println(i.getBasic()+" "+i.getEmpNo()));
	
	
}
}
