package JAVA8Feature_Collectors;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Ex4Fe_Map {
public static void main(String[] args) {
	 List<Integer>L=Arrays.asList(100,50,30,70,20,20,10);
	 
	 Stream<Integer>s=L.stream();
//	 Function<Integer , Integer>f=new Function<Integer, Integer>() {
//		@Override
//		public Integer apply(Integer t) {
//			return t*10;
//		}
//	};
// s.map(f).forEach(i->System.out.println(i));
	
	//L.stream().filter(j->j>50).map(f).forEach(i->System.out.println(i));
	
	L.stream().filter(j->j>50).map(t->t*20).forEach(i->System.out.println(i));

	
}
}
