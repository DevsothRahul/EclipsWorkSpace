package JAVA8Feature_Collectors;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import collection.collection;

public class Ex2Fe_filter {
	public static void main(String[] args) {
		List<Integer> L = Arrays.asList(80, 20, 100, 2, 50, 38, 1);

//	for(int i=0;i<L.size();i++)
//	{
//		if(L.get(i)>25)
//		{
//			System.out.println(L.get(i));
//		}
//	}
		
		
//		Predicate<Integer> P = new Predicate<Integer>() {
//			@Override
//			public boolean test(Integer t) {
//				return t > 25;
//			}
//		};
//
//		Stream<Integer> s = L.stream();
//		Stream<Integer> s1 = s.filter(P);
//		s1.forEach(i->System.out.println(i));
		
		
		Predicate<Integer> s=o1->{return o1>20;};
		L.stream().filter(s).forEach(i->System.out.println(i));
		System.out.println();
		L.stream().filter(o1->o1>26).forEach(i->System.out.println(i));

	}
}
