package JAVA8Feature_Collectors;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.stream.Stream;

public class Ex6Fe_Ruduce {
	public static void main(String[] args) {
		List<Integer> l=Arrays.asList(10,50,20,40,60,90,1);
		
//		BinaryOperator<Integer> b=new BinaryOperator<Integer>() {
//			@Override
//			public Integer apply(Integer t, Integer u) {
//				System.out.println(t+" "+u);
//				return t+u;
//			}
//		};
		
		
//		
//		BinaryOperator<Integer>b=(t,u)->{return t+u;};
//		System.out.println(l.stream().reduce(0,b));
		
		System.out.println("sum :" +" "+ l.stream().filter(t->t>10).map(i->i*3).reduce(0, (a, b) -> a + b));

		
	}
}
