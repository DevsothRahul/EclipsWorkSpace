package JAVA8Feature_Collectors;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import JAVA8Fe.Employee;

public class Ex1Fe_Col {
	public static void main(String[] args) {
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		List<Employee> L = Arrays.asList(new Employee(1, "Rahul", LocalDate.parse("01-Jul-2002", D), 30000),
				new Employee(2, "Raju", LocalDate.parse("21-Jun-2002", D), 70000),
				new Employee(3, "RaKhi", LocalDate.parse("01-Jan-2002", D), 12000),
				new Employee(4, "Ramulu", LocalDate.parse("01-Sep-2002", D), 50000));

//		for (int i = 0; i < L.size(); i++) {
//			if (L.get(i).getBasic() >= 50000)
//				System.out.println(L.get(i).getEmpNo() + " " + L.get(i).getEname() + " " + L.get(i).getDoj() + " "
//						+ L.get(i).getBasic());

		// Sorting without paasing any paramaeter in sorted
//		List<Integer> L1=Arrays.asList(10,30,5,3,22,90,1,100);
//		Stream<Integer>s=L1.stream().sorted();
//		List<Integer> result=L1.stream().sorted().collect(Collectors.toList());
//		result.forEach(i->System.out.println(i));

			//Sorting using comparator 
//		Comparator<Employee> C = new Comparator<Employee>() {
//			@Override
//			public int compare(Employee o1, Employee o2) {
//				if (o1.getBasic() > o2.getBasic())
//					return 1;
//				else if (o1.getBasic() < o2.getBasic())
//					return -1;
//				else
//					return 0;
//			}
//		};
//		List<Employee> L1 = L.stream().sorted(C).collect(Collectors.toList());
//		L1.forEach(i -> System.out.println(i.getEmpNo() + " " + i.getEname() + " " + i.getBasic()));
		
		
		     //Compare methos using lamda expression:
//		Comparator<Employee> C1=(o1,o2)->{
//			if (o1.getBasic() > o2.getBasic())
//				return 1;
//			else if (o1.getBasic() < o2.getBasic())
//				return -1;
//			else
//				return 0;
//		};
//		List<Employee> L1 = L.stream().sorted(C1).collect(Collectors.toList());
//		L1.forEach(i -> System.out.println(i.getEmpNo() + " " + i.getEname()+" "+i.getBasic()));
//		
		//reducing the code using lamda
//		Comparator<Employee>C2=(o1,o2)->{
//			return (int)(o1.getBasic()-o2.getBasic());
//		};
//		List<Employee> E=L.stream().sorted((o1,o2)->(int)(o1.getBasic()-o2.getBasic())).collect(Collectors.toList());
//		E.forEach(i->System.out.println(i.getEmpNo()+ " "+i.getBasic()));
		
		
		L.stream().sorted((o1,o2)->(int)(o1.getBasic()-o2.getBasic())).forEach(i->System.out.println(i.getBasic()));
		System.out.println();
		
//		Collections.sort(L,(o1,o2)->(int)(o1.getBasic()-o2.getBasic()));
//		L.forEach(i->System.out.println(i.getBasic()));
		
		
	}

}
