package JAVA8Feature_Collectors;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import JAVA8Fe.Employee;

public class Ex3Fe_filter_in_Employee {
public static void main(String[] args) {
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	List<Employee> L=Arrays.asList(
			new Employee(1,"Rahul",LocalDate.parse("01-Jul-1999",D),30000),
			new Employee(2,"Raju",LocalDate.parse("21-Jun-2022",D),70000),
			new Employee(3,"RaKhi",LocalDate.parse("01-Jan-1960",D),12000),
			new Employee(4,"Ramulu",LocalDate.parse("01-Sep-2021",D),50000)
			);
	
//	Predicate<Employee>E=new Predicate<Employee>() {
//		@Override
//		public boolean test(Employee t) {
//			return t.getBasic()>500;
//		}
//	};
//	Stream<Employee>s=L.stream();
//	Stream<Employee>s1=s.filter(E);
//	s1.forEach(i->System.out.println(i.getEmpNo()+" "+i.getBasic()));
	
	//	Predicate<Employee>e=o1->{return o1.getBasic()>100;};
	//	L.stream().filter(e).forEach(i->System.out.println(i.getEmpNo()+" "+i.getBasic()));
	
	//L.stream().filter((o1)->{return o1.getBasic()>100;}).forEach(i->System.out.println(i.getBasic()));
	L.stream().filter(o1->o1.getBasic()>100).forEach(i->System.out.println(i.getBasic()));
	
	LocalDate d1=LocalDate.parse("31-Dec-2019",D);
	L.stream().filter(o1->o1.getDoj().compareTo(d1)>1 && o1.getBasic()>200).forEach(i->System.out.println(i.getEmpNo()+" "+i.getDoj()));
}
}
