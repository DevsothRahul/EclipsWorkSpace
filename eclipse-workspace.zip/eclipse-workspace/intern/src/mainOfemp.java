import java.util.List;
import java.util.Scanner;

public class mainOfemp {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		s.nextLine();
;		String[] E=new String[n];
		empBl B=new empBl();
		for(int i=0;i<E.length;i++)
		{
			E[i]=s.nextLine();
		}
		List<Emp>list=B.getByValues(E);
		for(Emp e:list)
		{
			System.out.println(e.getEmpId()+" "+e.getEmpName()+" "+e.getGender()+" "+e.getDate()+" "+e.getBasic());
		}
		
	}
}
