package intern;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Day2DateEx {
	public static void main(String[] args) {
		//LocalDate D=new LocalDate.now();
		//System.out.println(D);
		String Dt="June-30-2022";
		DateTimeFormatter D1=DateTimeFormatter.ofPattern("MMMM-dd-yyyy");
		LocalDate L1=LocalDate.parse(Dt,D1);
		System.out.println(L1.format(D1));
		
		LocalDate L2=LocalDate.of(2050, 06, 20);
		int y=Period.between(L1, L2).getYears();
		int m=Period.between(L1, L2).getMonths();
		int d=Period.between(L1, L2).getDays();
		System.out.println(y + " Years "+ m + " Months " +d +" Days");
		System.out.println(ChronoUnit.DAYS.between(L1, L2));
		
		
		
		
		 
	}
}
