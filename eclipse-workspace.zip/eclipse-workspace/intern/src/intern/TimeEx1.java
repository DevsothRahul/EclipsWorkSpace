package intern;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TimeEx1 {
public static void main(String[] args) throws ParseException {
	String time1 = "16:00:00";
	String time2 = "19:00:00";

	SimpleDateFormat format = new SimpleDateFormat("HH:mm:ss");
	Date date1 = (Date) format.parse(time1);
	Date date2 = (Date) format.parse(time2);
	long difference = date2.getTime() - date1.getTime(); 
}
}
