package intern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateEx1 {
public static void main(String[] args) throws ParseException {
	Date D=new Date();
	System.out.println(D);
	SimpleDateFormat F=new SimpleDateFormat("dd-MM-yyyy");
	System.out.println(F.format(D));
	
	
	SimpleDateFormat F2=new SimpleDateFormat("dd/MM/yyyy");
	System.out.println(F2.format(D));
	
	SimpleDateFormat F1=new SimpleDateFormat("dd-yyyy-MM");
	String dt="12-2009-02";
	Date D1=F1.parse(dt);
	System.out.println(F1.format(D1));
	String date1 = F1.format(new Date());
	System.out.println(date1);
	
	
	String pattern = "yyyy-MM-dd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	String date = simpleDateFormat.format(new Date());
	System.out.println(date);
	

	SimpleDateFormat s = new SimpleDateFormat("MM dd yyyy");
		System.out.println(s.format(D));
	

}
}
