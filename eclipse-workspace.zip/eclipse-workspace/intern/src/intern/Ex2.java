package intern;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

public class Ex2 {
	public static void main(String[] args) throws ParseException {
		SimpleDateFormat F=new SimpleDateFormat("dd-MM-yyyy");
		Date D =F.parse("25-05-2022");
		Date D1 = F.parse("25-03-2022");
	
		System.out.println(D.after(D1));
		if(D==D1)
			System.out.println("Equals");
		else
			System.out.println("not Equal");
		
		
		if(D.equals(D1))
			System.out.println("Equal");
		else
			System.out.println("not Equal");
		
		Date D3=D;
		if(D3.equals(D))
			System.out.println("Equal");
		else
			System.out.println("not Equal");
		
		if(D.compareTo(D1)==1)
		{
			System.out.println("D>D1");
		}
		else
		{
			System.out.println("D<D1");
		}
		
		LocalDate date = LocalDate.parse("2019-07-15");
	    
		//add 5 days
		LocalDate date2 = date.plusMonths(7);
		System.out.println("Date "+date+" plus 5 days is "+date2);
		
		
	}
}
