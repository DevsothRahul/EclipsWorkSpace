import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DataDl {
	static List<Emp> Result = new ArrayList<Emp>();

	public static List<Emp> Arry(String[] E) {
		System.out.println(E.length);
		for (int i = 0; i < E.length; i++) {
			String[] B = E[i].split(";");
			Emp e = new Emp(Integer.parseInt(B[0]), B[1], B[2], LocalDate.parse(B[3]), Integer.parseInt(B[4]));
			Result.add(e);
		}
		return Result;

	}
}
