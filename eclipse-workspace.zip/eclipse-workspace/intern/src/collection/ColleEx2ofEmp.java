package collection;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ColleEx2ofEmp {
public static void main(String[] args) {
	List<Employee> L=new ArrayList<Employee>();
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MM-yyyy");
	L.add(new Employee(1,"Ravi","Male",LocalDate.parse("01-02-2003",D),20000));
	Employee E=null;
	E=new Employee(2,"Raju","Male",LocalDate.parse("29-05-1999",D),30000);
	L.add(E);
	
	E=new Employee(3,"Harika","Female",LocalDate.parse("10-05-2004",D),20);
	L.add(E);
	
	
	
	//Gives no.of Objects
	System.out.println(L.size());
	for(Employee e:L)
	{
		System.out.println(e);
		System.out.println(e.getEmpno()+" "+e.getEname()+" "+e.getGender()+" "+e.getDoj());
	}
	System.out.println("\n After basic sorting:");
	Collections.sort(L);
	
	for(Employee e:L)
	{
		//System.out.println(e);
		System.out.println(e.getEmpno()+" "+e.getEname()+" "+e.getGender()+" "+e.getDoj()+" "+e.getBasic());
	}
	
}
}
