package collection;

import java.util.Comparator;

public class Basiccomarator implements Comparator<EmployeeAssQ1> {

	@Override
	public int compare(EmployeeAssQ1 o1, EmployeeAssQ1 o2) {
		if(o1.getBasic()>o2.getBasic())
			return 1;
		else if(o1.getBasic()<o2.getBasic())
			return -1;
		else
			return 0;
	}
}
