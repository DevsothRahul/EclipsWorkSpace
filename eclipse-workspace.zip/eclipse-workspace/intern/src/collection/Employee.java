package collection;

import java.time.LocalDate;

public class Employee implements Comparable<Employee>{
	private int empno;
	private String ename;
	private String gender;
	private LocalDate doj;
	private double basic;
	public double getBasic() {
		return basic;
	}

	public int getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public String getGender() {
		return gender;
	}

	public LocalDate getDoj() {
		return doj;
	}

	Employee() {

	}

	public Employee(int empno, String ename, String gender, LocalDate doj, double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.gender = gender;
		this.doj = doj;
		this.basic = basic;
	}

	@Override
	public int compareTo(Employee o) {
			if(this.getBasic()>o.getBasic())
				return 1;
			else if(this.getBasic()<o.getBasic())
			
				return -1;
			else
				return 0;
			
	}

}
