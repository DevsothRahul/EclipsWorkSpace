package collection.BI;
import java.time.LocalDate;
import java.util.List;

import collection.EmployeeAssQ1;
import collection.DI.Employeedao;
public class Employeebl {
	public List<EmployeeAssQ1> getEmpByDate(LocalDate D)
	{
		
		return Employeedao.getEmpByDate(D);
		
	}

	public List<EmployeeAssQ1> getEmpByBasic(double d) {
		// TODO Auto-generated method stub
		
		return Employeedao.getEmpByBasic(d);
	}

	

}
