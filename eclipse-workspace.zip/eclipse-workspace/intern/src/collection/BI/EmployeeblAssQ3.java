package collection.BI;

import java.time.LocalDate;
import java.util.List;

import collection.EmployeeAssQ1;
import collection.DI.EmployeedaoAssQ1;
import collection.DI.EmployeedaoAssQ2;
import collection.DI.EmployeedaoAssQ3;

public class EmployeeblAssQ3 {
	public static List<EmployeeAssQ1> getSortByDob()
	{
		return EmployeedaoAssQ3.getsortBydob();
	}
	public static List<EmployeeAssQ1> getSortByBasic()
	{
		return EmployeedaoAssQ3.getsortByBasic();
	}

}
