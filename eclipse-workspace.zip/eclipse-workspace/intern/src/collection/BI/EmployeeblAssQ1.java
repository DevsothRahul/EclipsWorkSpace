package collection.BI;

import java.time.LocalDate;
import java.util.List;

import collection.EmployeeAssQ1;
import collection.DI.EmployeedaoAssQ1;

public class EmployeeblAssQ1 {
	public String getEmpById(int id) {
		return EmployeedaoAssQ1.getEmpById(id);

	}

}
