package collection.BI;

import java.time.LocalDate;
import java.util.List;

import collection.EmployeeAssQ1;
import collection.DI.EmployeedaoAssQ1;
import collection.DI.EmployeedaoAssQ2;

public class EmployeeblAssQ2 {
	public String getUpdateBySal(int id,double sal) {
		return EmployeedaoAssQ2.getupdateByBasic(id,sal);

	}

}
