package collection.DI;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import collection.EmployeeAssQ1;

public class EmployeedaoAssQ3 {
	static List<EmployeeAssQ1> L =new ArrayList<EmployeeAssQ1> 
		(Arrays.asList(new EmployeeAssQ1(2, "B", "Female", LocalDate.parse("1995-11-02"), 20000),
			new EmployeeAssQ1(3, "C", "Male", LocalDate.parse("2000-01-02"), 10000),
			new EmployeeAssQ1(4, "D", "Male", LocalDate.parse("1997-10-02"), 110000),
			new EmployeeAssQ1(5, "E", "Female", LocalDate.parse("2000-08-02"), 130000),
			new EmployeeAssQ1(6, "F", "Male", LocalDate.parse("1999-01-02"), 45000),
			new EmployeeAssQ1(7, "G", "Female", LocalDate.parse("2000-07-02"), 33000),
			new EmployeeAssQ1(8, "H", "Male", LocalDate.parse("1998-01-02"), 41000),
			new EmployeeAssQ1(9, "I", "Female", LocalDate.parse("2000-12-02"), 60000),
			new EmployeeAssQ1(10, "J", "Male", LocalDate.parse("2001-02-02"), 23000)));

	public static List<EmployeeAssQ1> getsortBydob()
	{
		Collections.sort(L,new CompareWithDob());
		return L;
		
	}
	public static List<EmployeeAssQ1> getsortByBasic()
	{
		Collections.sort(L,new ComapreWithSal());
		return L;
	}



}
