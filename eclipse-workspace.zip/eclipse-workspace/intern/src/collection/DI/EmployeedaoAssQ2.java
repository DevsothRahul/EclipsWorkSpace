package collection.DI;

import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;

import collection.EmployeeAssQ1;

public class EmployeedaoAssQ2 {
	static List<EmployeeAssQ1> L =new ArrayList<EmployeeAssQ1> 
		(Arrays.asList(new EmployeeAssQ1(2, "B", "Female", LocalDate.parse("1995-11-02"), 20000),
			new EmployeeAssQ1(3, "C", "Male", LocalDate.parse("2000-01-02"), 10000),
			new EmployeeAssQ1(4, "D", "Male", LocalDate.parse("1997-10-02"), 110000),
			new EmployeeAssQ1(5, "E", "Female", LocalDate.parse("2000-08-02"), 130000),
			new EmployeeAssQ1(6, "F", "Male", LocalDate.parse("1999-01-02"), 45000),
			new EmployeeAssQ1(7, "G", "Female", LocalDate.parse("2000-07-02"), 33000),
			new EmployeeAssQ1(8, "H", "Male", LocalDate.parse("1998-01-02"), 41000),
			new EmployeeAssQ1(9, "I", "Female", LocalDate.parse("2000-12-02"), 60000),
			new EmployeeAssQ1(10, "J", "Male", LocalDate.parse("2001-02-02"), 23000)));

	public static String getupdateByBasic(int id,double bas) {
		String str ="";
		int c = 0;
		EmployeeAssQ1 temp=null;
		for (EmployeeAssQ1 e : L) {
			if (e.getEmpno() == id)
			{   c = 1;
				temp=e;
				break;
			}
		}
		if (c == 0) {
			str+="Employee not found";
		}
		else
		{
			
			str +="Before updatibg Basic:" + temp.toString();
				temp.setBasic(bas);
			str+="After Updating Basic:"+temp.toString();
		}
		return str;
	}


}
