package collection.DI;
import java.util.Comparator;
import collection.EmployeeAssQ1;
public class CompareWithDob implements Comparator<EmployeeAssQ1>{
	@Override
	public int compare(EmployeeAssQ1 o1, EmployeeAssQ1 o2) {
		if(o1.getDoj().compareTo(o2.getDoj())>=1)
			return 1;
		else if(o1.getDoj().compareTo(o2.getDoj())<-1)
			return -1;
		else
			return 0;
	}

}
