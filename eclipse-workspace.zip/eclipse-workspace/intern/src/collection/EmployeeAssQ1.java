package collection;

import java.time.LocalDate;

public class EmployeeAssQ1 {
	private int empno;
	private String ename;
	private String gender;
	private LocalDate doj;
	private double basic;
	public double getBasic() {
		return basic;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	public int getEmpno() {
		return empno;
	}

	public String getEname() {
		return ename;
	}

	public String getGender() {
		return gender;
	}

	public LocalDate getDoj() {
		return doj;
	}

	EmployeeAssQ1() {

	}

	public EmployeeAssQ1(int empno, String ename, String gender, LocalDate doj, double basic) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.gender = gender;
		this.doj = doj;
		this.basic = basic;
	}

	@Override
	public String toString() {
		return "\n empno:" + empno + "\n ename:" + ename + "\n gender:" + gender + "\n doj:" + doj + "\n basic:"
				+ basic ;
	}


}
