package collection;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ColleEx2ofEmp2 {
	public static void main(String[] args) {
		List<EmployeeAssQ1> L = new ArrayList<EmployeeAssQ1>();
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		L.add(new EmployeeAssQ1(1, "Ravi", "Male", LocalDate.parse("01-02-2003", D), 20000));
		EmployeeAssQ1 E = null;
		E = new EmployeeAssQ1(2, "Raju", "Male", LocalDate.parse("29-05-1999", D), 30000);
		L.add(E);

		E = new EmployeeAssQ1(3, "Harika", "Female", LocalDate.parse("10-05-2004", D), 20);
		L.add(E);

		// Gives no.of Objects
		System.out.println(L.size());

		System.out.println("With Iterator:");
		Iterator<EmployeeAssQ1> I = L.iterator();
		while (I.hasNext()) {
			EmployeeAssQ1 E1 = I.next();
			System.out.println(E1.getEmpno() + " " + E1.getEname() + " " + E1.getGender() + " " + E1.getBasic());
		}

		for (EmployeeAssQ1 e : L) {
			System.out.println(e);
			System.out.println(e.getEmpno() + " " + e.getEname() + " " + e.getGender() + " " + e.getDoj());
		}
		System.out.println("\n After basic sorting:");
		Collections.sort(L, new Basiccomarator());

		for (EmployeeAssQ1 e : L) {
			// System.out.println(e);
			System.out.println(
					e.getEmpno() + " " + e.getEname() + " " + e.getGender() + " " + e.getDoj() + " " + e.getBasic());
		}
		System.out.println("doj Camparing");
		Collections.sort(L, new DOJcomarator());

		for (EmployeeAssQ1 e : L) {
			// System.out.println(e);
			System.out.println(
					e.getEmpno() + " " + e.getEname() + " " + e.getGender() + " " + e.getDoj() + " " + e.getBasic());
		}

	}
}
