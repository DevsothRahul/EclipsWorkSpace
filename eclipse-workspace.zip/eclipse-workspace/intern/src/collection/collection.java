package collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class collection {
	public static void main(String[] args) {
		//Non-Generic 
		ArrayList A=new ArrayList();
		A.add("Hello");
		A.add(10.8);
		A.add(11);
		for(Object ob: A)
		{
			System.out.println(ob);
		}
		
		//Generic
		ArrayList<Integer> B=new ArrayList<Integer> ();
		B.add(122);
		B.add(100);
		B.add(30);
		B.add(1);
		for(Integer ob: B)
		{
			System.out.println(ob);
		}
		Collections.sort(B);
		for(Integer ob: B)
		{
			System.out.println(ob);
		}
		
	}
}
