package collection.PL;

import java.time.LocalDate;
import java.util.List;

import collection.Employee;
import collection.EmployeeAssQ1;
import collection.BI.Employeebl;

public class mainclass {
	public static void main(String[] args) {
		
	
		// TODO Auto-generated constructor stub
		LocalDate L=LocalDate.parse("1999-01-02");
		double d=45000;
		Employeebl Eb=new Employeebl();
		List<EmployeeAssQ1>list=Eb.getEmpByDate(L);
		
		for(EmployeeAssQ1 e:list)
		{
			System.out.println(e.getEmpno()+" "+e.getEname()+" "+e.getGender()+" "+e.getBasic());
		}
		System.out.println("Basic based on:");
		List<EmployeeAssQ1>list1=Eb.getEmpByBasic(d);
		for(EmployeeAssQ1 e:list1)
		{
			System.out.println(e.getEmpno()+" "+e.getEname()+" "+e.getGender()+" "+e.getBasic());
		}
	}
}
