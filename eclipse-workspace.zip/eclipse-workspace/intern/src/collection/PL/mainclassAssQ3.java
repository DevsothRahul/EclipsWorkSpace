package collection.PL;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import collection.Employee;
import collection.EmployeeAssQ1;
import collection.BI.Employeebl;
import collection.BI.EmployeeblAssQ1;
import collection.BI.EmployeeblAssQ2;
import collection.BI.EmployeeblAssQ3;

public class mainclassAssQ3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("1.Sort By Dob 2.Sort By Basic \n");
		int id = sc.nextInt();
		switch (id) {
		case 1:
			List<EmployeeAssQ1> L = EmployeeblAssQ3.getSortByDob();
			for (EmployeeAssQ1 e : L) {
				System.out.println(e.getEmpno() + " " + e.getEname() + " " + e.getGender() + " " + e.getDoj() + " "
						+ e.getBasic());
			}
			break;
		case 2:
			List<EmployeeAssQ1> L1 = EmployeeblAssQ3.getSortByBasic();
			for (EmployeeAssQ1 e : L1) {
				System.out.println(e.getEmpno() + " " + e.getEname() + " " + e.getGender() + " " + e.getDoj() + " "
						+ e.getBasic());
			}
		}

	}
}
