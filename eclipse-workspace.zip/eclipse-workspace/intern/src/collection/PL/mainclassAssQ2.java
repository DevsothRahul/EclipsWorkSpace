package collection.PL;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import collection.Employee;
import collection.EmployeeAssQ1;
import collection.BI.Employeebl;
import collection.BI.EmployeeblAssQ1;
import collection.BI.EmployeeblAssQ2;
public class mainclassAssQ2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		double d=sc.nextDouble();
		//System.out.println(Employeebl.getUpdateBySal(id,d));
		EmployeeblAssQ2 Eb=new EmployeeblAssQ2();
		String s=Eb.getUpdateBySal(id, d);
		System.out.println(s);
	}
}
