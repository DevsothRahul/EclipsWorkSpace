package collection.PL;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import collection.Employee;
import collection.EmployeeAssQ1;
import collection.BI.Employeebl;
import collection.BI.EmployeeblAssQ1;
public class mainclassAssQ1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		EmployeeblAssQ1 Eb=new EmployeeblAssQ1();
		String s=Eb.getEmpById(id);
		System.out.println(s);
	}
}
