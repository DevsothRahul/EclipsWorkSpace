package AssignmentByVeda;

import java.util.Scanner;

public class Q2 {

	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		int a=Sc.nextInt();
		int b=Sc.nextInt();
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After Swapping :"+ a +" "+b);
	}

}
