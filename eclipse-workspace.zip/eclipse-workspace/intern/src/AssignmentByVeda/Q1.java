package AssignmentByVeda;

import java.util.Scanner;

public class Q1 {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		int a=Sc.nextInt();
		int b=Sc.nextInt();
		int c=Sc.nextInt();
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("Greater number A");
			}else
			{
				System.out.println("Greater number is C");
			}
		}else
		{
			System.out.println("Greater number is b");
		}
	}

}
