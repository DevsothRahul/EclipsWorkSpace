package AssignmentByVeda;

public class Q3 {

	public static void main(String[] args) {
		
	}

}
