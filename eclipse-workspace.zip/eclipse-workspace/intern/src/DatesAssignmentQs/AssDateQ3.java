package DatesAssignmentQs;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class AssDateQ3 {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		LocalDate arr[]=new LocalDate[5];
		String str[]=new String[5];
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=LocalDate.parse(Sc.nextLine());
			str[i]=Sc.nextLine();
			
		}
		LocalDate D=LocalDate.now();
		for(int i=0;i<arr.length;i++)
		{
			if(D.compareTo(arr[i])>30)
			{
				System.out.println(str[i]+ " " +arr[i]);
			}
		}
	}

}
