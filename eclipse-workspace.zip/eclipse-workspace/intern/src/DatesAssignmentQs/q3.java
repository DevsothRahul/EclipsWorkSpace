package DatesAssignmentQs;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

public class q3 {
public static void main(String[] args) {
	String pattern = "yyyy-MM-dd";
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	String date = simpleDateFormat.format(new Date());
	System.out.println(date);
	LocalDate D=LocalDate.now();
}
}
