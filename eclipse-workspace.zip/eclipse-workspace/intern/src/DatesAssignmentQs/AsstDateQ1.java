package DatesAssignmentQs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

public class AsstDateQ1 {
	public static void main(String[] args) throws ParseException {
		SimpleDateFormat S=new SimpleDateFormat("yyyy-MM-dd");
		Date D=S.parse("2022-01-01");
		//System.out.println(D.getDayOfMonth());
		if(D.getDate()==01)
		{
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(D);
			cal.add(Calendar.MONTH, -1);
			cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			System.out.println(cal.getTime());
		}
		else
		{
			Calendar cal = Calendar.getInstance();
			cal.setTime(D);
			cal.add(Calendar.MONTH, 0);
			cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			System.out.println(cal.getTime());
		}
	}
}
