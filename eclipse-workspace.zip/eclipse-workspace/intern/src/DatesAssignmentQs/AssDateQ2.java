package DatesAssignmentQs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class AssDateQ2 {
	public static void main(String[] args) throws ParseException {
		SimpleDateFormat F=new SimpleDateFormat("yyyy-MM-dd");
		Date D=F.parse("2022-10-01");
		Scanner sc=new Scanner(System.in);
		int no=sc.nextInt();
		if(no>0)
		{
			Calendar cal=Calendar.getInstance();
			cal.setTime(D);
			cal.add(Calendar.MONTH, +no);
			cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			System.out.println(cal.getTime());
			
		}
		else
		{
			Calendar cal=Calendar.getInstance();
			cal.setTime(D);
			cal.add(Calendar.MONTH, no);
			cal.set(Calendar.DAY_OF_MONTH,cal.getActualMaximum(Calendar.DAY_OF_MONTH));
			System.out.println(cal.getTime());
		}
	}
}
