package JAVA8Fe;

@FunctionalInterface
interface ExJava {
	int method1(int a,int b,String st);

}

public class Ex4Fe {
	public static void main(String[] args) {
		ExJava I = (i,j,s) -> {
			System.out.println("Method called "+i+ " "+j+ " "+s);
			return i+j;
		};
		System.out.println(I.method1(10,20,"Hello Rahul"));
	}
}
