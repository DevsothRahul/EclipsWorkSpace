package JAVA8Fe;

@FunctionalInterface
interface Ex3Java {
	void method1(int a,int b,String st);

}

public class Ex3 {
	public static void main(String[] args) {
		Ex3Java I = (i,j,s) -> {
			System.out.println("Method called "+i+ " "+j+ " "+s);
		};
		I.method1(10,20,"Hello Rahul");
	}
}
