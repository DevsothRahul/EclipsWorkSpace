package JAVA8Fe;

@FunctionalInterface
interface Ex2 {
	void method();
	// void method1();
	int hashCode();
	String toString();
	boolean equals(Object ob);
}

public class Ex2Java8 {
	public static void main(String[] args) {
//		Ex2 E = new Ex2() {
//
//			@Override
//			public void method() {
		//int n=10;
		//int sum=0;
//		for(int i=0;i<=n;i++)
//		{
//			sum=sum+i;
//		}
//				System.out.println("method in anonymous");
//			}
//		};
//		E.method();
		
		
		Ex2 E=() -> {
			int n=10;
			int sum=0;
			for(int i=0;i<=n;i++)
			{
				sum=sum+i;
			}
			System.out.println("method in anonymous sum is: " +sum);
		};
		E.method();
	}
}
