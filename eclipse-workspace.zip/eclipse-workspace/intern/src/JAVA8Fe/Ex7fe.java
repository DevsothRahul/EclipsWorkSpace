//static method in interface
package JAVA8Fe;

@FunctionalInterface
interface staticEx {
	void method1();

	static void method2() {
		System.out.println("Method 2 in static");
	}
	default void method3() {
		System.out.println("Method3 in default");
	}
	
}

class child1 implements staticEx {

	@Override
	public void method1() {
		System.out.println("method1 of child1");
	}
	//this method2 can not override because it is static method
		//		@Override
		//		public void method2()
		//		{
		//			
		//		}

}
class child2 implements staticEx {

	@Override
	public void method1() {
		System.out.println("method1 of child2");
	}

}

public class Ex7fe {
	public static void main(String[] args) {
		staticEx ch1=new child1();
		child2 ch2=new child2();
		ch1.method1();
		ch1.method3();
		ch2.method1();
		ch2.method3();
		staticEx.method2();
		
	}
}
