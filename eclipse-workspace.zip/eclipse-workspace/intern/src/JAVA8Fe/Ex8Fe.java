package JAVA8Fe;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Ex8Fe {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(10, 30, 20, 35, 60, 30);
//
//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//		}
		
		System.out.println();

//		Consumer<Integer> C = new Consumer<Integer>() {
//			@Override
//			public void accept(Integer t) {
//				System.out.println(t);
//			}
//		};
//		list.forEach(C);

		System.out.println();

//		list.forEach(new Consumer<Integer>() {
//			@Override
//			public void accept(Integer t) {
//				System.out.println(t);
//			}
//		});

	

		Consumer<Integer> C1 = one ->System.out.println(one);
		System.out.println(C1);
		list.forEach(i->System.out.println(i));

		// list.forEach(i -> System.out.println(i));
	}
}
