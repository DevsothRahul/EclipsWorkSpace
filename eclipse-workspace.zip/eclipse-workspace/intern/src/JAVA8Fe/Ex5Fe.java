package JAVA8Fe;

@FunctionalInterface
interface interEx1 {
	void method1();
}
@FunctionalInterface
interface interex extends interEx1
{
	//void method2();
	
}
public class Ex5Fe {
	public static void main(String[] args) {

	}
}
