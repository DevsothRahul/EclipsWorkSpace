package JAVA8Fe;

interface Ex {
	void method1();

	void method2();
}
public class Ex1Java8 {
	public static void main(String[] args) {
		Ex E=new Ex() {
			
			@Override
			public void method2() {
				// TODO Auto-generated method stub
				System.out.println("Method2");
			}
			
			@Override
			public void method1() {
				// TODO Auto-generated method stub
				System.out.println("Method1");
			}
		};
		E.method1();
		E.method2();
	}
}
