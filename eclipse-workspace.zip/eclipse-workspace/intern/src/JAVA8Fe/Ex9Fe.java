package JAVA8Fe;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

public class Ex9Fe {
public static void main(String[] args) {
	DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
	List<Employee> L=Arrays.asList(
			new Employee(1,"Rahul",LocalDate.parse("01-Jul-2002",D),30000),
			new Employee(2,"Raju",LocalDate.parse("21-Jun-2002",D),70000),
			new Employee(3,"RaKhi",LocalDate.parse("01-Jan-2002",D),12000),
			new Employee(4,"Ramulu",LocalDate.parse("01-Sep-2002",D),50000)
			);
	L.forEach(i->System.out.println(i.getEmpNo()+" "+i.getEname()+ " "+i.getDoj()+" "+i.getBasic()));
}
}
