package JAVA8Fe;
@FunctionalInterface
interface interex3 {
	void method1();
	void method2();
	default void method2() {
		System.out.println("Method2 in default ");
	}
}

class c1 implements interex3 {

	@Override
	public void method1() {
		System.out.println("method1 in c1");
	}

}

class c2 implements interex3 {
	public void method2() {
		System.out.println("method in c2 as ");
	}

	@Override
	public void method1() {
		System.out.println("method1 in c2");
	}

}

class c3 implements interex3 {

	@Override
	public void method1() {
		System.out.println("method1 in c3");
	}

}

public class Ex6 {
	public static void main(String[] args) {
		c1 c = new c1();
		c2 c2 = new c2();
		c3 c3 = new c3();
		c.method1();
		c.method2();
		c2.method1();
		c2.method2();
		c3.method1();
		c3.method2();

	}
}
