import java.time.LocalDate;
public class Emp {
	private int empId;
	private String empName;
	private String gender;
	private LocalDate date;
	private double basic;
	public Emp(int empId, String empName, String gender, LocalDate date, double basic) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.gender = gender;
		this.date = date;
		this.basic = basic;
	}
	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empName=" + empName + ", gender=" + gender + ", date=" + date + ", basic="
				+ basic + "]";
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

}
