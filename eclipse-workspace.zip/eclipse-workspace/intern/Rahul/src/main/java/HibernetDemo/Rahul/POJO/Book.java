package HibernetDemo.Rahul.POJO;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Book {
	@Id
	private int boolId;
	@Column(length=20,name="bName")
	private String bookName;
	private Double cost;
	public Book(int boolId, String bookName, Double cost) {
		super();
		this.boolId = boolId;
		this.bookName = bookName;
		this.cost = cost;
	}
	/**
	 * @return the boolId
	 */
	public int getBoolId() {
		return boolId;
	}
	/**
	 * @return the bookName
	 */
	public String getBookName() {
		return bookName;
	}
	/**
	 * @return the cost
	 */
	public Double getCost() {
		return cost;
	}
	
	

}
