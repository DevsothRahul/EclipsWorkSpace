package RelationwithXML.onetoMany.pojo;

public class EmployeeXml {
	private int empNo;
	private String ename;
	private EmployeeXml employee;

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}
	public EmployeeXml(int empNo, String ename) {
		super();
		this.empNo = empNo;
		this.ename = ename;
		
	}


}
