package RelationwithXML.onetoMany.pojo;

public class salaryXml {
	private int empno;
	private int basic;
	private EmployeeXml employee;
	
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public int getBasic() {
		return basic;
	}
	public void setBasic(int basic) {
		this.basic = basic;
	}
	public EmployeeXml getEmployee() {
		return employee;
	}
	public void setEmployee(EmployeeXml employee) {
		this.employee = employee;
	}
	public salaryXml(int empno, int basic, EmployeeXml employee) {
		super();
		this.empno = empno;
		this.basic = basic;
		this.employee = employee;
	}
	
	
}
