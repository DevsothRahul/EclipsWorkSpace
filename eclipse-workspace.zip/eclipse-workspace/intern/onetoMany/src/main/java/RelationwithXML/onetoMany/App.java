package RelationwithXML.onetoMany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	 Configuration cgf=new Configuration();
         cgf.configure("RelationwithXML/onetoMany/hibernate.cfg.xml");
         SessionFactory factory=cgf.buildSessionFactory();
         Session session=factory.openSession();
         
         session.close();
         factory.close();
    }
}
