package RahulNayak.Hi_Ex2.POJO;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Booklet {
	@Id
	private int bookId;
	private String bookName;
	private String author;
	private double cost;
	private LocalDate pub_date;
	public Booklet()
	{
		
	}
	public Booklet(int bookId, String bookName, String author, double cost, LocalDate pub_date) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.author = author;
		this.cost = cost;
		this.pub_date = pub_date;
	}
	public int getBookId() {
		return bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public String getAuthor() {
		return author;
	}
	public double getCost() {
		return cost;
	}
	public LocalDate getPub_date() {
		return pub_date;
	}
	
	
}
