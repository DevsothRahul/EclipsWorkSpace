package RahulNayak.Hi_Ex2;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import RahulNayak.Hi_Ex2.POJO.Booklet;

public class App 
{
    public static void main( String[] args )
    {
        Configuration cfg=new Configuration();
        cfg.configure("RahulNayak/Hi_Ex2/Booklet.hbm.xml");
        SessionFactory factory=cfg.buildSessionFactory();
        Session session=factory.openSession();

        DateTimeFormatter D=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
       Booklet B=new Booklet(10,"Complete Reference java","XYZ",100,LocalDate.parse("01-Oct-2022",D));
       
       Transaction T=session.beginTransaction();
       session.save(B);
       T.commit();
       
       session.close();
       factory.close();
        
        System.out.println(factory);
        
    }
}
