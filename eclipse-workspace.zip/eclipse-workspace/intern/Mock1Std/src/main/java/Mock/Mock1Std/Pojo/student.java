package Mock.Mock1Std.Pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class student {
	@Id
	private int stdId;
	private String stdName;
	private String gender;
	
	//private int addressId;
	@OneToOne
	@JoinColumn(unique=true)
	private Address address;
	
	
	public int getStdId() {
		return stdId;
	}
	public void setStdId(int stdId) {
		this.stdId = stdId;
	}
	public String getStdName() {
		return stdName;
	}
	public void setStdName(String stdName) {
		this.stdName = stdName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public student(int stdId, String stdName, String gender, Address address) {
		super();
		this.stdId = stdId;
		this.stdName = stdName;
		this.gender = gender;
		this.address = address;
	}

	
}
