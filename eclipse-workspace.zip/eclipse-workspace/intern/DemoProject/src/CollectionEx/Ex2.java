package CollectionEx;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Scanner;

public class Ex2 {
	public static void main(String[] args) {
		// Type Collection Typesafe
		ArrayList<Integer> l1 = new ArrayList<Integer>();
		l1.add(10);
		l1.add(100);
		l1.add(300);
		l1.add(20);
		l1.add(400);
		l1.add(3);
		l1.add(120);
		l1.add(150);
		l1.add(1200);
		// Different Types of for loops
		for (Integer I : l1) {
			System.out.println(I);
		}
System.out.println("Loop______________2");
		for (int i = 0; i < l1.size(); i++) {
			System.out.println(l1.get(i));
		}
		Collections.sort(l1);
		System.out.println("Loop___________3");
		Iterator<Integer> I = l1.iterator();
		while(I.hasNext())
		{
			System.out.println(I.next());
		}
		

	}
}
