package CollectionEx;

import java.util.ArrayList;

public class CollectionEx1 {
public static void main(String[] args) {
	//not Type Safe Non-Generic Collection
	ArrayList L=new ArrayList();
	L.add(10);
	L.add("Hello");
	L.add(10.4);
	L.add(10.45f);
	for(Object ob:L)
	{
		System.out.println(ob);
	}
	//Type Collection Type Safe
	
	ArrayList<Integer> L1=new ArrayList<Integer>();
	L1.add(10);
	L1.add(20);
	L1.add(30);
	L1.add(40);
	for(Object ob:L1)
	{
		System.out.println(ob);
	}
}
}
