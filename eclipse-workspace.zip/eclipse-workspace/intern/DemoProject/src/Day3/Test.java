package Day3;

class base {
	void Method1() {
		System.out.println("Method1");
	}

	void Method2() {
		System.out.println("Method2");
	}
}

class derived extends base {
	void Method1() {
		System.out.println("Method1-Derived");
	}

	void Method3() {
		System.out.println("Method3-Derived");
	}
}

public class Test {
	public static void main(String[] args) {
		// run time poly
		base b = new base();
		b.Method1();
		b.Method2();
		// b.Method3();
		base b1 = new derived();
		b1.Method1();
		b1.Method2();
		// b1.Method4();

	}
}
