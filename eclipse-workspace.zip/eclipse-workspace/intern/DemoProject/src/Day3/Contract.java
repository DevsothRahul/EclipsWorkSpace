package Day3;

public class Contract extends Employee {
	private String stdate;
	private String eddate;
	private double renum;

	public Contract() {
		super();
	}

	public Contract(int enoNo, String empName, String gender, String stdate, String endate, double rennum) {
		super(enoNo, empName, gender);
		this.eddate = stdate;
		this.stdate = endate;
		this.renum = rennum;
	}

	public String print() {
		return super.print() + "\n Emp Stdate::" + stdate + "\n Emp Enddate:" + eddate + "\n Emp Rem:" + renum;
	}

	public double calculate() {
		return 100 * 100;
	}
}
