package Day3.pack1;

public class child extends parent{
	public child()
	{
		pro_i=10;
		
	}

}
