package Day3.pack1;

public class parent {
		
	private int pri_i;
	int def_i;
	protected int pro_i;
	public int pub_i;
	public parent()
	{
		def_i=10;
		pri_i=20;
		pro_i=30;
		pub_i=40;
	}

}
