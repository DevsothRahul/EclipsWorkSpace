package Day3.pack1;

public class NonChild {
	public NonChild()
	{
		parent p=new parent();
		p.def_i=200;
		p.pro_i=300;
		p.pub_i=400;
	}

}
