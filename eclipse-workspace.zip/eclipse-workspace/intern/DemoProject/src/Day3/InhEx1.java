package Day3;

import java.util.Scanner;

public class InhEx1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Employee Type:P.permenent ");
		String t = sc.nextLine();
		int eno = sc.nextInt();
		sc.nextLine();
		String en = sc.nextLine();
		String g = sc.nextLine();
		Employee E = null;
		if (t.equals("P")) {
			
			double b = sc.nextDouble();
			sc.nextLine();
			String dj = sc.nextLine();

			E = new permanent(eno, en, g, b, dj);
			// System.out.println(p.print());
		} else {
//			int eno = sc.nextInt();
//			sc.nextLine();
//			String en = sc.nextLine();
//			String g = sc.nextLine();
			String st = sc.nextLine();
			String end = sc.nextLine();
			double re = sc.nextDouble();
			E = new Contract(eno, en, g, st, end, re);
			// System.out.println(c.print());
		}
		System.out.println(E.print());
		System.out.println(E.calculate());

//	
//	permanent p1=new permanent(2,"Rahul","Male",2000,"17-Mar-2022");

		// System.out.println(p1.print());

	}
}
