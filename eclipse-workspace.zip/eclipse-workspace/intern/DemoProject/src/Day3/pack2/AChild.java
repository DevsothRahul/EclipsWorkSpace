package Day3.pack2;

import Day3.pack1.parent;

public class AChild extends parent {
	public AChild()
	{
//		def_i=10;
//		pri_i=20;
		pro_i=500;
		pub_i=600;
	}

}
