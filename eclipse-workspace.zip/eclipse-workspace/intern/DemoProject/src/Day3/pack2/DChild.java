package Day3.pack2;

import Day3.pack1.parent;

public class DChild {
	public DChild()
	{
		parent p=new parent();
		p.pub_i=1000;
		//p.pri_i=2000;
		//p.pro_i=100;
		//p.def_i=20;
	}

}
