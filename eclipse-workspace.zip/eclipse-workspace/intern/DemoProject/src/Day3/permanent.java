package Day3;
public class permanent extends Employee {
	private double basic;
	private String doj;
	public permanent(int enoNo, String empName, String gender, double basic, String doj) {
		super(enoNo, empName, gender);
		this.doj = doj;
		this.basic = basic;
	}

	// Printing Using polymerphism
	public String print() {
		return super.print() + "\n Basic:" + basic + "\n Doj:" + doj;
	}
	public double calculate() {
		return 10 * 100;
	}

}
