package Assignment;
import java.util.Scanner;
public class CompanyWorker {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Time taken by Worker:\n");
	int hrs=sc.nextInt();
	if(hrs>=2 && hrs<=3)
	{
		System.out.println("Higly Efficenr");
	}
	else if(hrs>3 && hrs<=4)
	{
		System.out.println("Increase Their Speed");
	}
	else if(hrs>4 && hrs<=5)
	{
		System.out.println("Improving his Speed");
	}
	else if(hrs>5)
	{
		System.out.println("Must Leave The company");
	}
}
}
