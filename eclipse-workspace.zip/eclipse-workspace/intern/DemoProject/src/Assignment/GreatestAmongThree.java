package Assignment;

import java.util.Scanner;

public class GreatestAmongThree {
	static int Greatest(int m1,int m2,int m3)
	{
//		if(m1>m2)
//		{
//			if(m1>m3)
//			{
//				return m1;
//			}
//			else
//			{
//				return m3;
//			}
//		}
//		else
//		{
//			if(m2>m3)
//			{
//				return m2;
//			}
//			else
//			{
//				return m3;
//			}
//		}
		return (m1>m2)?(m1>m3?m1:m3):(m2>m3)?m2:m3;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter three Numbers:\n");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		int d=Greatest(a,b,c);
		System.out.println("Greatest Among Three Number is:"+d);
		
		
		
	}
}
