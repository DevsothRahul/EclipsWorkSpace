package Assignment;
import java.util.Scanner;
public class StarPrint {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter to print odd no to print Diamond:");
	int n=sc.nextInt();
	int star=1,space=n/2;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<space;j++)
			System.out.print(" ");
		for(int k=0;k<star;k++)
			System.out.print("*");
		System.out.println();
		if(i>=n/2)
		{
			star=star-2;
			space=space+1;
			
		}
		else
		{
			star=star+2;
			space=space-1;
			
		}
	}
}
}
