package Assignment;
import java.util.Scanner;
public class Vowel {
	public static void main(String[] args) {
		String str;
		Scanner sc=new Scanner(System.in);
		System.out.println("ENter String:");
		str=sc.nextLine();
		str=str.toUpperCase();
		int l=str.length();	
		for(int i=0;i<l;i++)
		{
			char ch=str.charAt(i);
			if(ch=='A' || ch=='E' ||ch=='I' ||ch=='O' || ch=='U')
			{
				System.out.print(ch+" ");
			}
		}
		
	}
}
