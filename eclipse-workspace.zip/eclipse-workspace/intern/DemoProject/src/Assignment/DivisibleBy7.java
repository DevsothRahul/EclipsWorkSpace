package Assignment;

import java.util.Scanner;

public class DivisibleBy7 {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the starting and ending limit:");
	int st=s.nextInt();
	int lst=s.nextInt();
	for(int i=st;i<lst;i++)
	{
		if(i%7==0)
		{
			System.out.print(i+" ");
		}
	}
}
}
