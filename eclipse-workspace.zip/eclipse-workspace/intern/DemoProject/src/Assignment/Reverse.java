package Assignment;

import java.util.Scanner;

public class Reverse {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the Length of Digit:\n");
	int len=sc.nextInt();
	int rev=0;
	if(len>=2 && len<=6)
	{
		System.out.println("Enter the Digit:\n");
		int n=sc.nextInt();
		while(n!=0)
		{
			
			int q=n%10;
			rev=rev*10+q;
			n=n/10;	
		}
	}
	System.out.println("Reverse Numer is:"+ rev);
}
}
