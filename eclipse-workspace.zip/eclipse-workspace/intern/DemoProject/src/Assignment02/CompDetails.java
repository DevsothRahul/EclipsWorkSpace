package Assignment02;

import java.util.Objects;
import java.util.Scanner;

class Contact{
	private String empName;
	private String compName;
	private String title;
	private String mobile;
	private String altMob;
	private String email;
	public Contact(String empName, String compName, String title, String mobile, String altMob, String email) {
		super();
		this.empName = empName;
		this.compName = compName;
		this.title = title;
		this.mobile = mobile;
		this.altMob = altMob;
		this.email = email;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contact other = (Contact) obj;
		return  this.empName.equalsIgnoreCase(empName) && this.mobile.equalsIgnoreCase(mobile)  &&this.email.equalsIgnoreCase(email);
	}
	
	@Override
	public String toString() {
		return " empName:" + empName + "\n compName:" + compName + "\n title:" + title + "\n mobile:" + mobile
				+ "\n altMob:" + altMob + "\n email:" + email;
	}
	
	

}

public class CompDetails {
	public static void main(String[] args) {
//		
//		Contact c1=new Contact("Rahul","Techwave","Traine","7093485914","70934850","rahul.devsoth@techwave.net");
		Scanner sc=new Scanner(System.in);
		//String str,st1;
		System.out.println("Enter Contact 1 Details:");
		String  str=sc.nextLine();
		String [] st1=str.split(",");
		Contact c=new Contact(st1[0],st1[1],st1[2],st1[3],st1[4],st1[5]);
		System.out.println("Enter Contact 2 Details:");
		String[] str1=sc.nextLine().split(",");
		Contact c1=new Contact(str1[0],str1[1],str1[2],str1[3],str1[4],str1[5]);
		System.out.println( "Contanct 1: "+"\n "+ c.toString());
		System.out.println("\n");
		System.out.println("Contanct 2:" + "\n"+ c1.toString());
		System.out.println("\n");
		boolean t=c.equals(c1);
		if(t==true)
		{
			System.out.println("Contact 1 is same as Contact 2");
		}
		else
		{
			System.out.println("Contact 1 is dirrent from Contact 2");
		}
		
	}
}
