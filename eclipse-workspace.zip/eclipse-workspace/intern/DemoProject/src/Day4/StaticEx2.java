package Day4;
class Demo1
{
	static int empid;
	class print
	{
		
	}
	
	static class personal
	{
		String name;
		String Dob;
		public personal(String name, String dob)
		{
			super();
			this.name = name;
			Dob = dob;
			empid=100;
		}
	}
	static class quali
	{
		String DName;
		Double year;
		public quali(String dName, Double year) {
			super();
			DName = dName;
			this.year = year;
		}
		
	}
	
}

public class StaticEx2 {
	public static void main(String[] args) {
		Demo1.personal p1=new Demo1.personal("Shiva", "14-12-2000");
	}
}
