package Day4;
class Demofinal
{
	int i=100;
	 void method1()//If i take final key word we can't overridden
	{
		System.out.println("Method1 Parent");
	}
	 void method2()
	 {
		 System.out.println("Method2 in Parent");
	 }
}
class Demochild extends Demofinal
{
	void method1()
	{
		super.method1();//Run Time Polymerphism
		System.out.println("Method1 Child");	
	}
}
public class FinalMethodEx1 {
public static void main(String[] args) {
	//Demofinal d=new Demofinal();
	Demochild d=new Demochild();
	d.method1();
	System.out.println(d.i);
}
}
