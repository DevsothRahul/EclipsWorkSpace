package Day4;

class parent
{
	static int i;
	int j;
	static
	{
		i=1000;
	}
}
class child extends parent
{
	public child()
	{
		i=10;
		j=20;
	}
}
public class inhEx1 
{
public static void main(String[] args) {
	child c=new child();
	System.out.println(c.i);
	System.out.println(child.i);
	parent p=new parent();
	p.i++;
	System.out.println(p.i);
	System.out.println(parent.i);
}
}
