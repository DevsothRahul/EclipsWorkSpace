package Day4;
class FinalDemo
{
	//final int i=10;
	int j,k;
	final int i;
	static int l;
	public FinalDemo()
	{
		i=100;
		j++;
		k++;
		l=200;
	}
	public FinalDemo(int j, int k, int i,int m) {
		//super();
		this.j = j;
		this.k = k;
		this.i = i;
		l=m;
	}
	
}
public class FinalEx1 {
public static void main(String[] args) {
	FinalDemo d=new FinalDemo();
	System.out.println(d.i+ " "+d.j+" "+d.k +" "+d.l);
	FinalDemo d1=new FinalDemo(10,20,30,100);
	System.out.println(d1.i+ " "+d1.j+" "+d1.k+" "+d1.l);
	FinalDemo d2=new FinalDemo(100,200,300,1000);
	System.out.println(d2.i+ " "+d2.j+" "+d2.k+" "+d2.l);
}
}
