package Day4;

class Demo {
//	int i,j;
//	public static int k;
	private int i, j;
	private static int k;
	static
	{
		System.out.println("Iam in Static Block of Demo");
	}

	public Demo(int a, int b, int c) {
		i = a;
		j = b;
		k = c;

	}
	public static void calculate()
	{
	//	i=10;
		//j=20;
		k=100;
		//Total();
	}
	public void Total()
	{
		k=100;
		i=100;
		j=2003;
		calculate();
	}

	public String print() {
		return " " + i + " " + j + " " + k;
	}
}

public class StaticEx {
	static {
		System.out.println("Static block in main method");
	}

	public static void main(String[] args) {

//	Demo d=new Demo();
//	Demo d1=new Demo();
//	d.i=10;
//	d.j=20;
//	d.k=30;
//	d1.k=100;
//	System.out.println(d1.k);
		Demo d = new Demo(10, 20, 30);
		Demo d1 = new Demo(100, 200, 300);
		System.out.println(d.print());
		System.out.println(d.print());

	}
}
