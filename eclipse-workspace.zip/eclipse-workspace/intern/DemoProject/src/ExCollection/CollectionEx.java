package ExCollection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
class Employee implements Comparable<Employee> {
	private int empNo;
	private String empName;
	private LocalDate doj;
	private double basic;

	public Employee(int empNo, String empName, LocalDate doj, double basic) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.doj = doj;
		this.basic = basic;
	}

	/**
	 * @return the empNo
	 */
	public int getEmpNo() {
		return empNo;
	}

	/**
	 * @param empNo the empNo to set
	 */
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}

	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	/**
	 * @return the doj
	 */
	public LocalDate getDoj() {
		return doj;
	}

	/**
	 * @param doj the doj to set
	 */
	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	/**
	 * @return the basic
	 */
	public double getBasic() {
		return basic;
	}

	/**
	 * @param basic the basic to set
	 */
	public void setBasic(double basic) {
		this.basic = basic;
	}

	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		if(this.basic==o.basic)
			return 0;
		else if(this.basic>o.basic)
			return 1;
		else 
			return -1;
		
	}

}

public class CollectionEx {
	public static void main(String[] args) {
		List<Employee> l=new ArrayList<Employee>();
		Employee E=new Employee(0,"Java",LocalDate.parse("2000-10-29"), 100);
		l.add(E);
		E=new Employee(1,"Stack",LocalDate.parse("2001-10-30"), 120);
		l.add(E);
		l.add(new Employee(2,"Develop",LocalDate.parse("2002-11-12"), 50));
		l.add(new Employee(3,"Love_",LocalDate.parse("2000-02-14"), 200));
		
		for(Employee e:l)
		{
			//System.out.println(e);
			System.out.println(e.getEmpNo());
			System.out.println(e.getEmpName());
			System.out.println(e.getDoj());
			System.out.println(e.getBasic());
		}
		//Since we want to sort based on Employee object Implement Comparable interface to Employee class 
		System.out.println("After sorting based on Doj");
		Collections.sort(l,new dojComaparator());
		for(Employee e:l)
		{
			//System.out.println(e);
			System.out.println(e.getEmpNo());
			System.out.println(e.getEmpName());
			System.out.println(e.getDoj());
			System.out.println(e.getBasic());
		}
		
		
		System.out.println("After sorting based on basic");
		Collections.sort(l,new BasicComparator());
		for(Employee e:l)
		{
			//System.out.println(e);
			System.out.println(e.getEmpNo());
			System.out.println(e.getEmpName());
			System.out.println(e.getDoj());
			System.out.println(e.getBasic());
		}
	}
	
}
