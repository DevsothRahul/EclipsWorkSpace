package Day1;

public class FirstPrg {
	public static void main(String[] args) {
		int j=10;
		Object ob1;
		//Implicit
		ob1=j;
		System.out.println(ob1);
		
		//Explict Conversion(Unboxing)
		Object ob2="String";
		String s=(String) ob2;
		System.out.println(s);
 		
		Object ob3=3.0f;
		float l=(float)ob3;
		System.out.println(l);
		
		Object d=12.121;
		Double d1=(Double)d;
		System.out.println(d1);
		
		Object b1=true;
		boolean b=(boolean)b1;
		System.out.println(b);
	}

}
