package Day1;

import java.util.Scanner;

class Student{
	private int stNo;
	private String stName;
	private int m1,m2,m3;
	void Accept(int stNo,String stName,int m1,int m2,int m3)
	{
		this.stNo=stNo;
		this.stName=stName;
		this.m1=m1;
		this.m2=m2;
		this.m3=m3;
	}
	String Display()
	{
		return "Student No:"+stNo+ "\nStudent Name:"+stName+ "\nStudent m1:"+m1 +"\nStudent m2:"+m2+ "\nStudent m3:"+m3;
	}
	double Calculate()
	{
		return (m1+m2+m3)/3.0;
	}
	String Result()
	{
		double avg=Calculate();
		if(avg>=90)
			return "Thopu";
		else if(avg>=45)
			return "satisfy";
		else
			return "Bye Bye";
	}
	String Grade(double res)
	{
		if(res>=90)
			return "Thopu";
		else if(res>=45)
			return "satisfy";
		else
			return "Bye Bye";
	}
}
public class EmcapEx4 {
public static void main(String[] args) {
	Student S=new Student();
	int no;
	String name;
	int m1,m2,m3;
	Scanner sc=new Scanner(System.in);
	no=sc.nextInt();
	sc.nextLine();
	name=sc.nextLine();
	m1=sc.nextInt();
	m2=sc.nextInt();
	m3=sc.nextInt();
	S.Accept(no, name, m1, m2, m3);
	
	
	System.out.println(S.Display());
	
	System.out.println(S.Result());
	
	double avg=S.Calculate();
	System.out.println(S.Grade(avg));
	
	
}
}
