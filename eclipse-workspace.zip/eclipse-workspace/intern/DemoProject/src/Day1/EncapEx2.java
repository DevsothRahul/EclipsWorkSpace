package Day1;
import java.util.Scanner;
class Employee
{
	private int empNo;
	private String eName;
	private String gender;
	private double basic;
void Accept(int empNo,String en,String g,double basic)
	{
	 this.empNo=empNo;
	 eName=en;
	 gender=g;
	 this.basic=basic;
	}
String print()
{
	String str="Emp No:"+empNo;
	str=str+"\n Emp Name:"+eName;
	str=str+"\n Emp Gender:"+gender;
	str=str+"\n Emp Basic:"+basic;
	return str;
}
	
}

public class EncapEx2 {
	public static void main(String[] args) {
		Employee E=new Employee();
		Employee E1=new Employee();
		Scanner s=new Scanner(System.in);
		int eno;
		String ename,g;
		double b;
		eno=s.nextInt();
		s.nextLine();
		ename=s.nextLine();
		g=s.nextLine();
		b=s.nextDouble();
		E.Accept(eno, ename, g, b);
		
		eno=s.nextInt();
		s.nextLine();
		ename=s.nextLine();
		g=s.nextLine();
		b=s.nextDouble();
		E1.Accept(eno, ename, g, b);
		
		System.out.println(E.print());
		System.out.println(E1.print());
		
	}

}
