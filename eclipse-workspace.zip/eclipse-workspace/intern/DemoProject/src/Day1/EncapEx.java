package Day1;
class Sample
{
	int i;
	float j;
	void Total()
	{
	int T=i+(int)j;
	System.out.println("Sum:"+" "+T);
	}
	int sum(int a)
	{
		int k=i+(int)j+a;
		return k;
	}
	String add()
	{
		int k=i+(int)j;
		return "Total Is:"+k;
	}
	void print()
	{
		System.out.println(i);
		System.out.println(j);
	}
}

public class EncapEx {
public static void main(String[] args)
{
	Sample S=new Sample();
	Sample S1=new Sample();
	S.i=100;//With respect to that class Object will get the values
	S.j=200.2f;
	S1.i=100;
	S1.j=100.1f;
	S.print();
	S1.print();
	
	S.print();
	S.Total();
	int l=S.sum(1000);
	System.out.println("sum method addition:"+l);
	
	String str=S.add();
	System.out.println("Add Method Addition:"+str);
	
	
}
}
