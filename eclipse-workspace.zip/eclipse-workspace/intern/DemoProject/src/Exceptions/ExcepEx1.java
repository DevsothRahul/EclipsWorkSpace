	package Exceptions;
	import java.util.Date;
	import java.text.ParseException;
	import java.text.SimpleDateFormat;
	import java.util.Scanner;
	
	public class ExcepEx1 {
//	public static void main(String[] args) throws ParseException  {
//		Scanner sc = new Scanner(System.in);
//		String i=sc.nextLine();
//		SimpleDateFormat F=new SimpleDateFormat("dd-mm-yyyy");
//		Date D=(Date) F.parse(i);
//		System.out.println(D);
//	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		int j=sc.nextInt();
		int k=i/j;
		System.out.println(k);
	}

	
	
}
