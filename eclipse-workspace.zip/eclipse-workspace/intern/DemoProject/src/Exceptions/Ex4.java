//Throwing exception explicitly
package Exceptions;
import java.util.Scanner;

class AgeException extends Exception {
	public AgeException(String str) {
		super(str);
	}
}

public class Ex4 {
	public static void main(String[] args) {
		Scanner Sc=new Scanner(System.in);
		int k;
		int i=Sc.nextInt();
		int j=Sc.nextInt();
		try {
			if(j!=0)
				 k=i/j;
			else
				throw new ArithmeticException("Cant devide by zero");
		}
		catch(ArithmeticException E)
		{
			System.out.println(E.getMessage());
		}
		
		System.out.println("Enter Age:\n");
		int Age=Sc.nextInt();
		try {
			if(Age>=21 && Age <=50)
			{
				System.out.println("Your Age is"+ Age);
			}
			else
			{
				throw new AgeException("Age is should be between 18 to 50");
			}
		}
		catch(AgeException E) {
			System.out.println(E.getMessage());
		}
		System.out.println("Enter Basic:\n");
		double basic;
		basic=Sc.nextDouble();
		try {
			if(basic>10000)
			{
				System.out.println("Basic is:"+basic);
			}
			else
			{
				throw new AgeException("Basic should more than 10000");
			}
		}
		catch(AgeException E)
		{
			System.out.println(E.getMessage());
		}
		
;	}
}
