package Exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExcepEx3 {
public static void main(String[] args) {
	Scanner Sc=new Scanner(System.in);
		try{
			int i=Sc.nextInt();
			int j=Sc.nextInt();
			int k=i/j;
			System.out.println(k);
		}
		catch(InputMismatchException E)
		{
			System.out.println("Entered characters");
		}
		catch(ArithmeticException E)
		{
			System.out.println("Arithematic Exception");
		}
		catch(Exception E)
		{
			System.out.println("Error occured");
		}
		finally
		{
			System.out.println("Completed!");
		}

}
}
