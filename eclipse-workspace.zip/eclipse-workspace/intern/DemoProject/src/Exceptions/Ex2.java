package Exceptions;

import java.util.Scanner;

public class Ex2 {
//	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		try
//		{
//			int i=sc.nextInt();
//			int j=sc.nextInt();
//			int k=i/j;
//			System.out.println(k);
//		}
//		catch(Exception e)
//		{
//			System.out.println("Exception occured");
//		}
//		finally
//		{
//			System.out.println("Finally block");
//		}
//	}
//}

	public static void main(String args[])
	 {
	 int a;
	 a = 10;
	 
	 if(a == 10)
	 {
	 int b = 20;
	 System.out.print("a and b: "+ a + " " + b);
	 b = a*2;
	 }
	 
	 int b = 100;
	 System.out.print("a and b: " + a + " " + b);
	 }
}
