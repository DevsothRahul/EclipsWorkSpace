package InterfaceExStaffAdmin;

import java.time.LocalDate;

interface IStaff {
	double hra = 12.0;

	double Gross();

	double Tax();

	double NetSalary();
	String Display();

}

abstract class Staff implements IStaff {
	private int emNo;
	private String empName;
	private LocalDate doj;
	private String gender;

	public Staff(int emNo, String empName, LocalDate doj, String gender) {
		super();
		this.emNo = emNo;
		this.empName = empName;
		this.doj = doj;
		this.gender = gender;
	}
	public String Display()
	{
		String str="EmpNo :"+emNo;
		str=str+ "\n Emp Name: "+ empName;
		str=str+"\n Date of Joining :"+doj;
		str=str+"\n Gender :"+gender;
		return str;
	}

}

class Admin extends Staff {
	private String design;
	private double basic;

	public Admin(int emNo, String empName, LocalDate doj, String gender, String design, double basic) {
		super(emNo, empName, doj, gender);
		this.design = design;
		this.basic = basic;
	}

	@Override
	public double Gross() {
		// TODO Auto-generated method stub
		return basic + basic * hra / 100 + basic * 40 / 100;
	}

	@Override
	public double Tax() {
		// TODO Auto-generated method stub
		return Gross()*5/100;
	}

	@Override
	public double NetSalary() {
		// TODO Auto-generated method stub
		return Gross()-Tax();
	}

	@Override
	public String Display() {
		String Str=super.Display();
		Str=Str+"\n Designation :"+design;
		Str=Str+"\n Basic :"+basic;
		Str=Str+"\n Gross :"+Gross();
		Str=Str+"\n Tax deducation:"+Tax();
		Str=Str+"\n Net Salary:"+NetSalary();
		return Str;
		}

}

class faculty extends Staff {
	private int experience;
	private double grant;
	private String subject;
	public faculty(int emNo, String empName, LocalDate doj, String gender, int experience, double grant,
			String subject) {
		super(emNo, empName, doj, gender);
		this.experience = experience;
		this.grant = grant;
		this.subject = subject;
	}
	@Override
	public double Gross() {
		// TODO Auto-generated method stub
		return grant+grant*hra/100+grant*60/100+10000;
	}

	@Override
	public double Tax() {
		// TODO Auto-generated method stub
		return Gross()*5/100;
	}

	@Override
	public double NetSalary() {
		// TODO Auto-generated method stub
		return Gross()-Tax();
	}

	@Override
	public String Display() {
		// TODO Auto-generated method stub
		String Str=super.Display();
		Str=Str+"\n Experience:"+experience;
		Str=Str+"\n grant:"+grant;
		Str=Str+"\n Subject:"+subject;
		Str=Str+"\n Gross:"+Gross();
		Str=Str+"\n Tax::"+Tax();
		Str=Str+"\n NetSalary:"+NetSalary();
		return Str;
		
	}
}

class HOD extends faculty {
	private int dno;
	private String dName;
	public HOD(int emNo, String empName, LocalDate doj, String gender, int experience, double grant, String subject,
			int dno, String dName) {
		super(emNo, empName, doj, gender, experience, grant, subject);
		this.dno = dno;
		this.dName = dName;
	}
	public String Display()
	{
		String Str=super.Display();
		Str=Str+"\n Dept No:"+dno;
		Str=Str+"\n dept Name:"+dName;
		return Str;
	}

}

public class interfacex1 {
	public static void main(String[] args) {
		//IStaff I=new Admin(1,"Rahul", LocalDate.parse("2002-09-01"),"Male", "Manager", 5000);
//		IStaff I=new faculty(00, "Raghu", LocalDate.parse("2022-02-14"), "Male", 3, 20000,"Full-Stack");
		IStaff I=new HOD(01,"Raghav",LocalDate.parse("2022-02-14"),"Male", 5, 20000,"Data Structure ",121,"Computer_Science");
		System.out.println(I.Display());
	}
}
