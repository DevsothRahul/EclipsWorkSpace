package day5e;

import Day5.Shape;

class Circle implements Shape{

	@Override
	public double Area() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double perimeter() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
public class Shape1 {

}
