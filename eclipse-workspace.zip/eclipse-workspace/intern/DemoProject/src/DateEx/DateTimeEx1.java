package DateEx;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DateTimeEx1 {
public static void main(String[] args) {
	LocalDateTime L=LocalDateTime.now();
	DateTimeFormatter d=DateTimeFormatter.ofPattern("hh:mm:ss");
	System.out.println(L.format(d));
	LocalDateTime from=LocalDateTime.of(2022,04, 26,10,15,25);
	LocalDateTime to=LocalDateTime.of(2022,04,27, 18, 10, 20);
	Duration duration=Duration.between(from, to);
	System.out.println(duration.toDays());
	System.out.println(duration.toHours());
	System.out.println(duration.toMinutes());
	System.out.println(duration.toDays()+" Days "+ duration.toHours()+" Hours "+ duration.toMinutes() +"Minuts");
}
}
