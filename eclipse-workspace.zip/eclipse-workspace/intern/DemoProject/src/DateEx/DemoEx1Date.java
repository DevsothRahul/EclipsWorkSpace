package DateEx;
import java.time.LocalDate;
import java.time.Period;
class Emp
{
	private int empNo;
	private String empName;
	private double basic;
	private LocalDate doj;
	public Emp(int empNo, String empName, double basic, LocalDate doj) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.basic = basic;
		this.doj = doj;
	}
	public int getEmpNo() {
		return empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public double getBasic() {
		return basic;
	}
	public LocalDate getDoj() {
		return doj;
	}
	int Service()
	{
		LocalDate now=LocalDate.now();
		int Y=Period.between(doj, now).getYears();
		return Y;
	}
}
public class DemoEx1Date {
public static void main(String[] args) {
	Emp E[]= {

			new Emp(1,"Ram",60000,LocalDate.parse("2022-09-01")),
			new Emp(2,"Ravi",50000,LocalDate.parse("2022-05-01")),
			new Emp(3,"Rahul",40000,LocalDate.parse("1999-05-01")),
			new Emp(4,"Reshma",80000,LocalDate.parse("2000-01-01")),
			new Emp(5,"Ranjitha",90000,LocalDate.parse("2020-07-01")),
			new Emp(6,"Neha",30000,LocalDate.parse("2022-03-01"))
			};
	Emp temp;
	for(int i=0;i<E.length-1;i++)
	{
		for(int j=i+1;j<E.length;j++)
		{
			if(E[i].getDoj().compareTo(E[j].getDoj())>0)
			{
				temp=E[i];
				E[i]=E[j];
				E[j]=temp;
			}
			
		}
	}
	for( int i=0;i<E.length;i++)
	{
		System.out.println(E[i].getEmpNo()+" "+E[i].getEmpName()+" "+E[i].Service());
	}
}
}
