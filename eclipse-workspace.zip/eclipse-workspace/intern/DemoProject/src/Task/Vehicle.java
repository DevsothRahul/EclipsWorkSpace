package Task;

import java.util.Objects;
import java.util.Scanner;

public class Vehicle {
	private String registrationNo;
    private String name	;
    private String type	;
    private double weight;
   
public Vehicle(String registrationNo, String name, String type, double weight) {
		super();
		this.registrationNo = registrationNo;
		this.name = name;
		this.type = type;
		this.weight = weight;
	}

@Override
public String toString() {
	return "registrationNo=" + registrationNo + "\n name=" + name + "\n type=" + type + "\n weight=" + weight
			+ "\n";
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Vehicle other = (Vehicle) obj;
	return Objects.equals(name, other.name) && Objects.equals(registrationNo, other.registrationNo);
}


public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	Vehicle v1=new Vehicle("KL 75 F 9562","Pulsar","TwoWheeler",200);
	Vehicle v2=new Vehicle("KL 75 F 9562","Pulsar","TwoWheeler",200);
	System.out.println("Vehicle1\n");
	System.out.println(v1.toString());
	System.out.println("Vehicle2\n");
	System.out.println(v2.toString());
	if(v1.equals(v2))
	{
		System.out.println("Vehicle 1 is same as Vehicle 2");
	}
	else {
		System.out.println("Vehicle 1 is different as Vehicle 2");
	}
	
}
}
