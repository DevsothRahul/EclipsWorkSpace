package Task;

import java.util.Scanner;

public class MyTask {
	static boolean ValidateEmailid(String email) {
		char ch = email.charAt(0);
		int len = email.length();
		int flag = 0;
		if ((ch >= 'A' && ch <= 'Z') || ((ch >= 'a' && ch <= 'z'))) {
			int in = email.indexOf('@');
			if (in == -1) {
				return false;
			} else {
				char s1;
				for (int i = 0; i < in; i++) {
					s1 = email.charAt(i);
					if ((s1 >= 'A' && s1 <= 'Z') || (s1 >= 'a' && s1 <= 'z') || s1 == '.' || s1 == '_' || s1 >= 0) {
						continue;
					} else
						return false;
				}

				String temp = "";
				int l2 = 0;
				for (int i = in + 1; i < len; i++) {
					temp += email.charAt(i);
					l2++;
				}

				int dotindex = temp.indexOf('.');
				if (dotindex == -1)
					return false;
				else {
					for (int i = 0; i < dotindex; i++) {
						char c = temp.charAt(i);
						if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z'))
							continue;
						else
							return false;

					}

					if ((l2 - dotindex - 1) >= 2 || (l2 - dotindex - 1) <= 6) {

						for (int i = dotindex + 1; i < l2; i++) {
							char c = temp.charAt(i);
							if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
								flag = 1;
								continue;
							}

							else
								return false;
						}
					}
				}
			}
			if (flag == 1)
				return true;

		}

		return false;
	}

	static String IdentifyServiceProvider(String mobile) {
		int len = mobile.length();
		if (len == 10) {
			String temp = "";
			for (int i = 0; i < 4; i++) {
				temp += mobile.charAt(i);
			}
			if (temp.equals("9870"))
				return "Airtel";
			else if (temp.equals("7012"))
				return "Jio";
			else if (temp.equals("8180"))
				return "Vodafone";
			else
				return "Invalid";
		} else
			return "Invlaid Number";
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true)
		{
		System.out.println("Menu\n");
		System.out.println("1.Email Validation:\n 2.Service Provide Identifier:\n");
		int i = sc.nextInt();
		if (i == 1) 
		{
			String email;
			System.out.println("Enter Your Email:\n");
			sc.nextLine();
			email = sc.nextLine();
			//System.out.println(email);
			Boolean val = ValidateEmailid(email);
			if (val == true) {
				System.out.println("Valid Emailid");
			} else {
				System.out.println("Invalid Emailid");
			}
		} 
		else if(i==2)
		{
			String Mobile;
			Mobile=sc.nextLine();
			String str = IdentifyServiceProvider("Mobile");
			System.out.println("your mobile number belongs to " + str);
		}
		else
		{
			System.out.println("INvalid Select Option");
			break;
		}

		
	}
	}
}
