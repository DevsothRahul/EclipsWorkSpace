package Java8feutures;

interface Inte {
	void Method1();

	void Method2();
}
abstract class demo
{
	abstract public void Method3();
	abstract public void Method4();
}
public class Java8FEx1 {
	public static void main(String[] args) {
		//Annonomous Type annonomous inner Class
		Inte I=new Inte() {
			
			@Override
			public void Method2() {
				// TODO Auto-generated method stub
				System.out.println("Method 1");
				
			}
			
			@Override
			public void Method1() {
				// TODO Auto-generated method stub
				System.out.println("Method 2");
			}
		};
		I.Method1();
		I.Method2();
		demo d=new demo() {
			
			@Override
			public void Method4() {
				// TODO Auto-generated method stub
				System.out.println("Method 4");
				
			}
			
			@Override
			public void Method3() {
				// TODO Auto-generated method stub
				System.out.println("Method 3");
			}
		};
		d.Method3();
		d.Method4();
	}
}
