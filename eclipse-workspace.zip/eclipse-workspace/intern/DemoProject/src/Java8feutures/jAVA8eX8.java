package Java8feutures;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class jAVA8eX8 {
	public static void main(String[] args) {
		List<Integer> L = Arrays.asList(10, 20, 30, 40, 50, 70, 100, 40, 60);
		System.out.println(L.stream());
		Stream<Integer> s = L.stream();
		System.out.println(s.collect(Collectors.toList()));
		System.out.println(L.stream().collect(Collectors.toList()));
		s=L.stream();
		s.forEach(i->System.out.println(i));
//		for(Integer I:L)
//		{
//			if(I>60)
//			{
//				System.out.println(I);
//			}
//		}
	}
}
