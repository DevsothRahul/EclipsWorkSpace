package Java8feutures;

interface interf12 {
	void Method1();

	void Method2();

 //default
 void Method3();// {
//		System.out.println("Method3 in interf1");
//	}

}

class test implements interf12 {

	@Override
	public void Method1() {
		// TODO Auto-generated method stub
		System.out.println("Method1 in Test");

	}

	@Override
	public void Method2() {
		// TODO Auto-generated method stub
		System.out.println("Method2 in Test");

	}
	public void Method3() {
		// TODO Auto-generated method stub
		System.out.println("Method3 in Test");

	}

}

public class Java8Ex4 {
	public static void main(String[] args) {
		test T=new test();
		T.Method1();
		T.Method2();
		T.Method3();
	}
}
