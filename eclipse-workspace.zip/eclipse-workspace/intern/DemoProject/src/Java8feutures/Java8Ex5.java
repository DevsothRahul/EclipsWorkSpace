package Java8feutures;
@FunctionalInterface
interface int1
{
	void Method1();
	static void Method2()
	{
		System.out.println("Method2 is static in interface");
	}
	static void Method3()
	{
		System.out.println("Method3 is static in interface");
	}
	default void Method4()
	{
		System.out.println("Method2 is default in interface");
	}
}
class staticDemo implements int1
{
	public void Method1()
	{
		System.out.println("method1 in demo");
	}
}
public class Java8Ex5 {
public static void main(String[] args) {
	int1.Method3();
	int1 I=()->{
		System.out.println("Method of Main");
	};
	I.Method1();
	staticDemo d=new staticDemo();
	d.Method1();
	I.Method1();
}
}
