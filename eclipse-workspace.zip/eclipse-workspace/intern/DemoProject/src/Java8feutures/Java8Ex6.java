package Java8feutures;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class imt1 {

	int id;
	String Name;
	double basic;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return Name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		Name = name;
	}

	/**
	 * @return the basic
	 */
	public double getBasic() {
		return basic;
	}

	/**
	 * @param basic the basic to set
	 */
	public void setBasic(double basic) {
		this.basic = basic;
	}

	public imt1(int id, String name, double basic) {
		super();
		this.id = id;
		Name = name;
		this.basic = basic;
	}

}

public class Java8Ex6 {
	public static void main(String[] args) {
		List<imt1> L = Arrays.asList(new imt1(1, "ABD", 12946), new imt1(2, "AB", 1), new imt1(3, "A", 165),
				new imt1(4, "gh", 245), new imt1(5, "tgh", 1808));

//		Comparator<imt1> C = (o1, o2) -> {
//			return (int) (o1.getBasic() - o2.getBasic());
//		};
		Collections.sort(L, (o1, o2) -> {
		return (int) (o1.getBasic() - o2.getBasic());}
		);
		L.forEach(e -> System.out.println(e.getId() + " " + e.getName() + " " + e.getBasic()));
	}
}
