package Java8feutures;

@FunctionalInterface
interface Inter1 {
	int  Method1(int a,String b);
//	String toStrin();
//	int hashCode();
//	boolean Equals();
}

public class Java8Ex2 {
	public static void main(String[] args) {
//		Inter1 I=new Inter1() {
//			
//			@Override
//			public void Method1() {
//				// TODO Auto-generated method stub
//				
//			}
//		}
		
	
		Inter1 I=(a,b)->
		{
			//System.out.println("Method1");
			int sum=0;
			int i;
			for( i=0;i<a;i++)
			{
				System.out.println(b);
			}
			 
			return i;
		};
		System.out.println(I.Method1(5,"Hello"));
	}
}
