package Java8feutures;

import java.util.Arrays;
import java.util.List;
import java.util.function.BinaryOperator;

public class JavaEx11 {
	public static void main(String[] args) {
		List<Integer> L = Arrays.asList(10, 20,30,40,60,70,100,40,60);
//		BinaryOperator<Integer> B=new BinaryOperator<Integer>() {
//
//			@Override
//			public Integer apply(Integer t, Integer u) {
//				System.out.println(t+" "+u);
//				return t+u;
//				// TODO Auto-generated method stub
//				
//			}
//			
//		};
		
//		BinaryOperator<Integer> B=(t,u)->{
//			return t+u;
//		};
		System.out.println(L.stream().filter(i->{return i>=100;}).reduce(0,(t,u)->{return t+u;}));
		System.out.println(L.stream().map(t->{return t*2;}).filter(i->{return i>=100;}).reduce(0,(t,u)->{return t+u;}));
	}
}
