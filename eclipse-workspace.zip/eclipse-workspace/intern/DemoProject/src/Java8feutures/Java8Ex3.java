package Java8feutures;

interface interf1 {
	int Method1(String s, int a);
}

interface interf2 extends interf1 {
	String Method2();
}

public class Java8Ex3 {
	public static void main(String[] args) {
		interf1 I=(s,a)->
		{
			System.out.println(s+" "+a);
		return a++;
	};
	
}
}
