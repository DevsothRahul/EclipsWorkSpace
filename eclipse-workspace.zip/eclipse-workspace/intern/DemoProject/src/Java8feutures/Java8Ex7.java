package Java8feutures;

import java.util.Arrays;
import java.util.List;

public class Java8Ex7 {
public static void main(String[] args) {
	List<Integer> L=Arrays.asList(10,20,30,40,50);
	List<imt1> L1 = Arrays.asList(new imt1(1, "RAHUL", 12946), new imt1(2, "RAJU", 1), new imt1(3, "RAGHU", 165),
			new imt1(4, "RAJULU", 245), new imt1(5, "RAJA", 1808));
	L.forEach(Java8Ex7::Result);
	L1.forEach(Java8Ex7::Result);
}
public static void Result(imt1 e)
{
	System.out.println(e.getId()+" "+e.getName()+" "+e.getBasic());
}
public static void Result(int i)
{
	System.out.println(i*2);
}



}
