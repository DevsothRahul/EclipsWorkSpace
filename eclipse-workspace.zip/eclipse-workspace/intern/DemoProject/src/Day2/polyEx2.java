package Day2;
class Demo
{
	int i,j,k;
	public Demo()
	{
		i=1;
		j=2;
		k=3;
	}
	public Demo(int a)
	{
		i=a;
		j=a;
		k=a;
	}
	public Demo(int a,int b,int c)
	{
		i=a+b+c;
		j=a+b+c;
		k=a+b+c;
	}
	public Demo(Demo A,Demo B)
	{
		System.out.println("A "+A);
		System.out.println("B "+B);
		i=A.i+B.i;
		j=A.j+B.j;
		k=A.k+B.k;
	}
	public Demo(Demo A)
	{
		i=A.i++;
		j=++A.j;
		k=A.k*2;
	}
}
public class polyEx2 {
public static void main(String[] args) {
	Demo D=new Demo();
	Demo D1=new Demo(10);
	Demo D2=new Demo(100,200,300);
	Demo D3=new Demo(D2);
	
	Demo D4=new Demo(D,D2);
	System.out.println("D "+D);
	System.out.println("D2 "+D2);
	
	System.out.println(D.i+" "+D.j+" "+D.k+" ");
	System.out.println(D1.i+" "+D1.j+" "+D1.k+" ");
	System.out.println(D2.i+" "+D2.j+" "+D2.k+" ");
	System.out.println(D3.i+" "+D3.j+" "+D3.k+" ");
	System.out.println(D4.i+" "+D4.j+" "+D4.k+" ");
	
}
}
