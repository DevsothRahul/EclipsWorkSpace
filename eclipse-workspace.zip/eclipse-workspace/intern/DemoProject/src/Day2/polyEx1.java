package Day2;
class Sample
{
	void Sum(int a,int b,int c)
	{
		System.out.println("Addition of 3 integers:"+(a+b+c));
	}
	void Sum(float a,float b)
	{
		System.out.println("Addition of 2 integers:"+(a+b));
	}
	void Sum(double d1, double d2)
	{
		System.out.println((d1+d1));
	}
	
//	double Sum(double d3,double d4)
//	{
//		System.out.println("Any thing which is not gonna print because it's return type with same function name");
//	}
}
public class polyEx1 {
public static void main(String[] args) {
	Sample S=new Sample();
	S.Sum(10,20);
	S.Sum(10, 20,30);
	S.Sum(10.3f,10.5f);
	S.Sum(10.5,20.5);
	
}
}
