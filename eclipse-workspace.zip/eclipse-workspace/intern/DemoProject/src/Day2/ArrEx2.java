package Day2;
import java.util.Scanner;
class Emp
{
	private int eno;
	private String Ename;
	private String gender;
	 double basic;
	void Accept(int eno,String Name,String gender,double b)
	{
		this.eno=eno;
		Ename=Name;
		this.gender=gender;
		basic=b;
	}
	String print()
	{
		return "Emp No:"+eno+"\n Emp Name:"+Ename+"\n Emp Gende:"+gender+"\n Emp Basic:"+basic;
	}
	
}
public class ArrEx2{
	static Emp[] AcceptEmps()
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the No Of Employee:");
		int n=sc.nextInt();
		Emp Earr[]=new Emp[n];
		
		int eno;
		String name,g;
		double b;
		
		for(int i=0;i<Earr.length;i++)
		{
			System.out.println("Enter Details of Employee:"+(i+1));
			Earr[i]=new Emp();
			eno=sc.nextInt();
			sc.nextLine();
			name=sc.nextLine();
			g=sc.nextLine();
			b=sc.nextDouble();
			Earr[i].Accept(eno, name, g, b);
		}
		return Earr;
	}
	static void Sort(Emp A[])
	{
		Emp temp;
		for(int i=0;i<A.length-1;i++)
		{
			for(int j=i+1;j<A.length;j++)
			{
				if(A[i].basic>A[j].basic)
				{
					temp=A[i];
					A[i]=A[j];
					A[j]=temp;
				}
			}
		}
	}
public static void main(String[] args) {
	//datatype variable =new datatype[Size]
	Emp Earr[]=AcceptEmps();
	Sort(Earr);
	for(int i=0;i<Earr.length;i++)
	{
		System.out.println(Earr[i].print());
	}
	
	
	
}
}
