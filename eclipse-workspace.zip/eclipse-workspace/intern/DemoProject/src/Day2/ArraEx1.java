package Day2;
import java.util.Scanner;
class Employee
{
	private int eno;
	private String Ename;
	private String gender;
	private double basic;
	void Accept(int eno,String Name,String gender,double b)
	{
		this.eno=eno;
		Ename=Name;
		this.gender=gender;
		basic=b;
	}
	String print()
	{
		return "Emp No:"+eno+"\n Emp Name:"+Ename+"\n Emp Gende:"+gender+"\n Emp Basic:"+basic;
	}
	
}
public class ArraEx1 {
public static void main(String[] args) {
	//datatype variable =new datatype[Size]
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter the No Of Employee:");
	int n=sc.nextInt();
	Employee Earr[]=new Employee[n];
	
	int eno;
	String name,g;
	double b;
	
	for(int i=0;i<Earr.length;i++)
	{
		System.out.println("Enter Details of Employee:"+(i+1));
		Earr[i]=new Employee();
		eno=sc.nextInt();
		sc.nextLine();
		name=sc.nextLine();
		g=sc.nextLine();
		b=sc.nextDouble();
		Earr[i].Accept(eno, name, g, b);
	}
	for(int i=0;i<Earr.length;i++)
	{
		System.out.println(Earr[i].print());
	}
	
}
}
