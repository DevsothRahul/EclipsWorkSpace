package Assignment01;

import java.util.Scanner;

class Book1 {

	private int bookNo;
	private String bookTitle;
	private float bookPrice;
	Scanner s = new Scanner(System.in);

	private float totalPrice(int n) {

		return n * bookPrice;
	}

	public void input() {
		System.out.println("enter book number ");
		bookNo = s.nextInt();
		System.out.println("enter book title ");
		s.nextLine();
		bookTitle = s.nextLine();
		System.out.println("enetr book price ");
		bookPrice = s.nextFloat();
	}

	public void purchase() {
		int n;
		System.out.println("enter no of books ");
		n = s.nextInt();
		System.out.println("total cost to be paid " + totalPrice(n));

	}
}
public class Book {
	public static void main(String[] args) {

		Book1 b = new Book1();
		b.input();
		b.purchase();

	}
}
//}

//}