package Assignment01;
import java.util.Scanner;
public class charOc {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		for (int i = 0; i < str.length(); i++) {
			int count = 0;
			for (int j = i + 1; j < str.length(); j++) {
				if (str.charAt(i) == str.charAt(j)) {
					count = 1;
					break;
				}
			}
			if (count == 0) {
				char s2 = str.charAt(i);
				System.out.print(s2 + " = ");
				for (int k = 0; k < str.length(); k++) {
					if (str.charAt(k) == s2) {
						System.out.println(k + " ");
					}
				}
			}
		}
	}
}
