/*1. Create an Interface
 * ITransaction Methods
 * Deposit()
 * Withdrawal()
 * Create a class BankAccount inherits ITransaction
 * AccountID
 * AccountHoldername
 * Balance
 * MinBal---3000
Create ParametrisedConstructor
Create a method to display() the details
CreateamethoddoTransaction()whichwillasktheuserfortypeofTransactiondepositor Withdrawal
If deposit option is selected ask for another input amount and add it to balance.
If Withdrawal is selected ask for an input amount and check if sufficient balance is present or not excluding the minBal. 
Then deduct that amount from balance. Else display NOTSUFFICIENTBALANCE.
*/
package Assignment3;
public interface IT {
	double Deposit();
	double Withdraw();

}
