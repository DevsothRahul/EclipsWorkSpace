/* 2.Create a class for 
 * ElectricityBill Properties
 * NoofUnits 
 * Methods
 * BillCalculation()
 * If no of units accepted from user are per unit cost Units between 
 * t        Amount
 * 0-100     $2
 * 101-300   $4
 * 301-600   $5
 * >=601     $7
 * Ex:-ifNoofUnits=512(100+200+212)
 * =100*2+200*4+212*5
 * NoofUnit must be accepted from Main function and display total Bill. */

package Assignment3;
import java.util.Properties;
import java.util.Scanner;
class properties {
	double billCal(double bill) {
		double b;
		if (bill >= 601) {
			return b = (100 * 2 + 200 * 4 + 300 * 5 + (bill - 600) * 7);
		} else if (bill >= 301) {
			return b = (100 * 2 + 200 * 4 + (bill - 300) * 5);
		} else if (bill >= 101) {
			return b = (100 * 2 + (bill - 100) * 4);
		} else {
			return b = bill * 2;
		}

	}
}

public class EleBill {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No of Units:");
		double no = sc.nextDouble();
		properties p = new properties();
		System.out.println(p.billCal(no));
	}
}
