/*4. Create InterfaceIBanking With following methods
 * 1.stringDisplay();
 * 2.d oubleCalculate();
 * create class Bank inheriting Interface IBanking
 *  private Variable
 *  1.stringbankId;
 *  2. stringbankName;
Create parameterized constructor 
Create Display method
Do not create Calculate method (abstract)
create class Branch inheriting Bank
1.stringbranchId;
2.string branchName;
 Create parameterized constructor
  Create Display method
  create class Customer inheriting Branch
  1.int customerId;
  2.stringcustomerName;
  3.double balance;
  Create parameterized constructor
  Create Display method
  Create Calculate method(overide)15% of Balance
  
  create class Employee inheriting Branch
  1.intemployeeId;
  2.stringeName;
  3.double Basic;
  Create parameterized constructor
  Create Display method
  Create Calculate method(overide) 
  IfBasic>30000
  15%ofBasic 
  if Basic>20000
  10% of Basic
   Else
   8% of Basic
   InMainclassimplementRuntimepolymorphism
    IBankingB=newCustomer(......)
    IBankingB=newEmployee(......)
*/
package Assignment3;
public interface Ibanking {
	String Display();
	double calculator();
}
