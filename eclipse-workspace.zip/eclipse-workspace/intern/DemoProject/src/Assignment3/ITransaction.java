//Question 01
package Assignment3;
import java.util.Scanner;
class tra implements IT
{
	Scanner s=new Scanner(System.in);
	private int accountId;
	private String accountHolderName;
	private double balance;  
	private double minBalance=3000;
	public tra(int accountId, String accountHolderName, double balance) {
		super();
		this.accountId = accountId;
		this.accountHolderName = accountHolderName;
		this.balance = balance;
		
	}
	@Override
	public String toString() {
		return "Bank Details:\n accountId:" + accountId + "\n accountHolderName:" + accountHolderName + "\n balance:" + balance
				+ "\n minBalance:" + minBalance;
	}
	public void  doTransaction()
	{
		System.out.println("Select Transaction Mode:");
		
		char s1=s.next().charAt(0);
		if(s1=='d')
		{
			double d=Deposit();
			System.out.println(d);
		}
		else if(s1=='w')
		{
			double w=Withdraw();
			if(w < 3000.0)
			{
				System.out.println("Balance insufficent to withdraw");
			}
			else
			{
				System.out.println(w);
			}
			
		}
		else
		{
			System.out.println("Selection of Transaction is Invalid");
		}
	}

	public double Deposit() 
	{
		// TODO Auto-generated method stub
		System.out.println("How much do u want to Deposit:");
		double dep=s.nextDouble();
		balance=balance+dep;
		return balance;
	}
	@Override
	public double Withdraw() 
	{
		// TODO Auto-generated method stub
		System.out.println("How much do u want to Withdraw:");
		double wt=s.nextDouble();
		balance=balance-wt;
		return balance;
	}
	
}
public class ITransaction {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	//bank s1=null;
	System.out.println("Enter Bank Details:");
	String name;
	int id,bal;
	int minBal=3000;
	id=sc.nextInt();
	sc.nextLine();
	name=sc.nextLine();
	bal=sc.nextInt();
	if(minBal < bal)
	{
		tra s1=new tra(id,name,bal);
		 System.out.println(s1.toString());
		s1.doTransaction();
	}
	else
	{
	System.out.println("operation can't Done Min balance should present");	
	}
	
}
}
