//Question 04
package Assignment3;
abstract class Bank1 implements Ibanking {
	private String bankId;
	private String bankName;
	public Bank1(String bankId, String bankName) {
		super();
		this.bankId = bankId;
		this.bankName = bankName;
	}
	@Override
	public String Display() {
		// TODO Auto-generated method stub
		// return null;
		return "bankId:" + bankId + "\nbankName:" + bankName + "\n";
	}
}
class Branch extends Bank1 {
	private String branchId;
	private String branchName;

	public Branch(String bankId, String bankName, String branchId, String branchName) {
		super(bankId, bankName);
		this.branchId = branchId;
		this.branchName = branchName;
	}
	public String Display() {
		return super.Display() + "branchid:" + branchId + "\nbranchname:" + branchName + "\n";
	}
	@Override
	public double calculator() {
		// TODO Auto-generated method stub
		return 0;
	}
}
class customer extends Branch {
	private int customerId;
	private String customerName;
	private double balance;
	public customer(String bankId, String bankName, String branchId, String branchName, int customerId,
			String customerName, double balance) {
		super(bankId, bankName, branchId, branchName);
		this.customerId = customerId;
		this.customerName = customerName;
		this.balance = balance;
	}
	public String Display() {
		return super.Display() + "custId:" + customerId + "\ncustomername:" + customerName + "\nbalance:" + balance + "\n";
	}
	public double calculator() {
		// TODO Auto-generated method stub
		return 0.15 * balance;
	}
}
class Emp extends Branch {
	private int employeeId;
	private String eName;
	private double Basic;

	public Emp(String bankId, String bankName, String branchId, String branchName, int employeeId, String eName,
			double basic) {
		super(bankId, bankName, branchId, branchName);
		this.employeeId = employeeId;
		this.eName = eName;
		Basic = basic;
	}

	public String Display() {
		return super.Display() + "empId:" + employeeId + "\nEmpname:" + eName + "\nEmpBasic: " + Basic + "\n";
	}

	public double calculator() {

		if (Basic > 30000)
			return 0.15 * Basic;
		else if (Basic > 20000)
			return 0.1 * Basic;
		else
			return 0.08 * Basic;
	}
}
public class Bank {
	public static void main(String[] args) {
		Bank1 emp = new Emp("1001", "SBI", "Bank12", "Hyd", 1789, "Anjeli", 1000);
		Bank1 cust = new customer("1002", "HDFC", "Bank123", "Hyd", 878789, "Shivaa", 9000);
		System.out.println(emp.Display());
		System.out.println(cust.Display());
		System.out.println(emp.calculator());
		System.out.println(cust.calculator());

	}
}
