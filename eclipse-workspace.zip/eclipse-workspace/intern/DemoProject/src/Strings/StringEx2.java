package Strings;
public class StringEx2 {
	public static void main(String[] args) {
		String S="RGUKT_IIIT_BaSARA";
		System.out.println(S.toUpperCase());
		System.out.println(S.toLowerCase());
		System.out.println(S.substring(4));
		System.out.println(S.substring(3, 12));
		String SEmail="abcd@yahoo.com;cdef@w12.net;wxyx@123.net;woaahh@rr4.net";
		String sr[]=SEmail.split(";");
		System.out.println(sr.length);
		System.out.println(sr[2]);
	}
}
