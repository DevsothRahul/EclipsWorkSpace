package Strings;

public class StringEx1 {
	public static void main(String[] args) {
//		String S = new String("ABSD");	
//		String S1 = new String("ABSD");
//		// Compare the Addresses of S and S1
//		if (S == S1)
//			System.out.println("Equal");
//		else
//			System.out.println("not Equal");
//
//		// Compare the Content of S and S1
//		if (S.equals(S1))
//			System.out.println("Equal");
//		else
//			System.out.println("Not Equal");
//
//		String S2 = S;
//		// referencing to same Addresses
//		if (S == S2)
//			System.out.println("Equal");
//		else
//			System.out.println("not Equal");
//
//		if (S.equals(S2))
//			System.out.println("Equal");
//		else
//			System.out.println("Not Equal");
//
//		S=S+"D";
//		//In this case  previous address of s is different from after assigning D value
//		if (S == S2)
//			System.out.println("Equal");
//		else
//			System.out.println("not Equal");
//
//		if (S.equals(S2))
//			System.out.println("Equal");
//		else
//			System.out.println("Not Equal");

		StringBuffer SB = new StringBuffer("ABC");
		// SB = SB.append("XYZ");
		StringBuffer SB1 = new StringBuffer("ABC");
		if (SB== SB1)
			System.out.println("Equal");
		else
			System.out.println("not Equal");

		if (SB.toString().equals(SB1.toString()))
			System.out.println("Equal");
		else
			System.out.println("Not Equal");
		StringBuffer SB11=SB;
		if (SB==SB11)//Compares the addresses
			System.out.println("Equal");
		else
			System.out.println("not Equal");
		
		SB=SB.append("ABC");
		if (SB==SB11)//SB and SB11 have same address and modify data and get result as same
			System.out.println("Equal");
		else
			System.out.println("not Equal");
		
//		System.out.println(SB);
	}
}
