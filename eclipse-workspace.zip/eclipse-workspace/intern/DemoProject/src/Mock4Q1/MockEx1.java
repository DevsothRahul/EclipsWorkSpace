package Mock4Q1;

import java.time.LocalDateTime;
import java.util.List;

class Vehicle {
	private String _registrationNo;
	private String _name;
	private String _type;
	private double _weight;
	private Ticket _ticket;

	/**
	 * @return the _registrationNo
	 */
	public String get_registrationNo() {
		return _registrationNo;
	}

	/**
	 * @param _registrationNo the _registrationNo to set
	 */
	public void set_registrationNo(String _registrationNo) {
		this._registrationNo = _registrationNo;
	}

	/**
	 * @return the _name
	 */
	public String get_name() {
		return _name;
	}

	/**
	 * @param _name the _name to set
	 */
	public void set_name(String _name) {
		this._name = _name;
	}

	/**
	 * @return the _type
	 */
	public String get_type() {
		return _type;
	}

	/**
	 * @param _type the _type to set
	 */
	public void set_type(String _type) {
		this._type = _type;
	}

	/**
	 * @return the _weight
	 */
	public double get_weight() {
		return _weight;
	}

	/**
	 * @param _weight the _weight to set
	 */
	public void set_weight(double _weight) {
		this._weight = _weight;
	}

	/**
	 * @return the _ticket
	 */
	public Ticket get_ticket() {
		return _ticket;
	}

	/**
	 * @param _ticket the _ticket to set
	 */
	public void set_ticket(Ticket _ticket) {
		this._ticket = _ticket;
	}

	public Vehicle(String _registrationNo, String _name, String _type, double _weight, Ticket _ticket) {
		super();
		this._registrationNo = _registrationNo;
		this._name = _name;
		this._type = _type;
		this._weight = _weight;
		this._ticket = _ticket;
	}

	public static Vehicle CreateVehicle(String detail) {
		return null;

	}
}

class Ticket {
	private String _ticketNo;
	private LocalDateTime _parkedTime;
	private Double _cost;

	public Ticket() {
		super();
	}

	public Ticket(String _ticketNo, LocalDateTime _parkedTime, Double _cost) {
		super();
		this._ticketNo = _ticketNo;
		this._parkedTime = _parkedTime;
		this._cost = _cost;
	}

}

class VehicleBO
{
	public List<Vehicle> FindVehicle(List<Vehicle> vehicleList, String type)
	{
		return vehicleList;
		
	}
	public List<Vehicle>FindVehicle(List<Vehicle> vehicleList, LocalDateTime parkedTime)
	{
		return vehicleList;
		
	}
}

public class MockEx1 {
	public static void main(String[] args) {
		
	}

}
