package Mock2;

import java.util.Scanner;
import java.util.regex.Pattern;

public class mock2 {
//	static boolean ValidateRegistrationNo(String registrationNo)
//	{
//				return Pattern.matches("[A-Z]{2}\s[0-9]{1,2}\s[A-Z]{1,2}\s [0-9]{4}",registrationNo);
//	}
//	
	static boolean ValidateRegistrationNo(String registrationNo)
	{
		String st[]=registrationNo.split(" ");
		int no=Integer.parseInt(st[1]);
		int flag=0;
		if(st[0].length()==2&&(st[0].charAt(0)>=65 && st[0].charAt(0)<=90)&&(st[0].charAt(1)>=65 &&st[0].charAt(1)<=90))
		{
			flag=1;
		}
		if(st[1].length()>=1 && st[1].length()<=2)
		{
			if(no> 0 && no<=99)
			flag=1;
		}
		if(st[2].length()>=1 && st[2].length()<=2)
		{
			for(int i=0;i<st[2].length();i++)
			{
				if(!(st[2].charAt(i)>='A' && st[2].charAt(i)<='Z'))
				{
					flag=0;
				}
				else
				{
					flag=1;
				}
			}
		}
		if(Integer.parseInt(st[3])>1000 && Integer.parseInt(st[3])<=9999)
		{
			flag=0;
		}
		if(flag==0)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the registration no. to be validated:");
		String RegNo=sc.nextLine();
		boolean b=ValidateRegistrationNo(RegNo);
		if(b)
		{
			System.out.println(" Registration No. is valid");
		}
		else
		{
			System.out.println(" Registration No. is invalid");
		}
		
	}
}
