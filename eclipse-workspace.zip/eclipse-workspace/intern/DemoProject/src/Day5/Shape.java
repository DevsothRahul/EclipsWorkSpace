package Day5;

public interface Shape {
		public abstract double Area();
		public abstract double perimeter();
		
}
