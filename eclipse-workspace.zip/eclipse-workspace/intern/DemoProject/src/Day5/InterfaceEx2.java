package Day5;
interface Issample
{
	int i=10;//in interface variables are static
}

class test implements Issample{
	
}
public class InterfaceEx2  {
public static void main(String[] args) {
	
}
}
