package Day5;
abstract class parent
{
	public abstract void Method1();
	public void Method2()
	{
		
	}
}
class Child extends parent
{
	public void Method1()
	{
		System.out.println("Ok");
	}
}
public class AbstEx1 {
	
public static void main(String[] args) {
	
}
}
