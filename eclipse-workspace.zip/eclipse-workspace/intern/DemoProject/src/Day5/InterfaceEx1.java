package Day5;



class Rectangle implements Shape {
	private double len, brea;

	public Rectangle(double len, double brea) {
		super();
		this.len = len;
		this.brea = brea;
	}

	public double Area() {
		return len * brea;
	}

	public double perimeter() {
		return 2 * (len + brea);
	}

}

class Square implements Shape {
	private double side;

	public Square(double side) {
		super();

		this.side = side;
	}

	public double Area() {
		return side * side;
	}

	public double perimeter() {
		return 4 * side;
	}

}

public class InterfaceEx1 {
	public static void main(String[] args) {
		Rectangle R = new Rectangle(10, 20);
		System.out.println(R.Area());
		System.out.println(R.perimeter());

	}
}
