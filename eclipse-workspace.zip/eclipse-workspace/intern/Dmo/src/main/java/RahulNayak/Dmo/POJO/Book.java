package RahulNayak.Dmo.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	private int bookId;
	private String bName;
	public Book()
	{
		
	}
	public Book(int bookId, String bName) {
		super();
		this.bookId = bookId;
		this.bName = bName;
	}
	/**
	 * @return the bookId
	 */
	public int getBookId() {
		return bookId;
	}
	/**
	 * @return the bName
	 */
	public String getbName() {
		return bName;
	}
	
}
