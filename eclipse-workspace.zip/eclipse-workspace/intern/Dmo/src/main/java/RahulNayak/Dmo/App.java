package RahulNayak.Dmo;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import RahulNayak.Dmo.POJO.Book;
public class App 
{
    public static void main( String[] args )
    {
    	 Configuration cfg=new Configuration();
         cfg.configure("RahulNayak/Dmo/hibernate.cfg.xml");
         // Step 2 create SessionFactory
         SessionFactory factory=cfg.buildSessionFactory();
         //Step 3 Create Session
         Session session=factory.openSession();
         Book B=new Book(1,"Stranger_");
         Book B1=new Book(2,"Factory");
      // System.out.println(factory);
         Transaction T=session.beginTransaction();
         session.save(B);
         session.save(B1);
         T.commit();
         
         
         
         session.close();
         factory.close();
         
    }
}
