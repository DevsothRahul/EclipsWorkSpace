package RahulNayak.onetooneAnno.pojo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Sal implements Serializable{
	@Id
	@OneToOne
	@JoinColumn(name="empno")
	private Emp employee;
	private double basic;
	
	public Emp getEmployee() {
		return employee;
	}
	public void setEmployee(Emp employee) {
		this.employee = employee;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	

}
