package techwave.com.in.pojo;

public class Triangle {
	int i, j;

	public Triangle(int i, int j) {
		super();
		this.i = i;
		this.j = j;
	}
	public Triangle()
	{
		System.out.println("Default");
	}
	public Triangle(int a)
	{
		i=a;
		j=a;
	}
	public int getI() {
		return i;
	}


	public int getJ() {
		return j;
	}


	public void DrawShape() {
		System.out.println("Traingle Drawn");
	}
}
