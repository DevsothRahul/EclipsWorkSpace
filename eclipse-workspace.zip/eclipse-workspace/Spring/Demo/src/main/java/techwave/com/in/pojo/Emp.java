package techwave.com.in.pojo;

public class Emp {
	private String eName;
	private int eNo;
	private Address addrss;//this is a referring to address class details
	public Emp(String eName, int eNo, Address addrss) {
		super();
		this.eName = eName;
		this.eNo = eNo;
		this.addrss = addrss;
	}
	public Emp()
	{
		
	}
	public Address getAddrss() {
		return addrss;
	}
	public void setAddrss(Address addrss) {
		this.addrss = addrss;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public int geteNo() {
		return eNo;
	}
	public void seteNo(int eNo) {
		this.eNo = eNo;
	}
}
