package techwave.com.in;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

import techwave.com.in.pojo.Rectangle;
import techwave.com.in.pojo.Triangle;

public class App 
{
    public static void main( String[] args )
    {
    	//1. BeanFactory_Using 	BeanFactory B=new XmlBeanFactory(new ClassPathResource("techwave/com/in/spring.xml"));
    	//2.ApplicationContext_Using
    	ApplicationContext context=new  ClassPathXmlApplicationContext("techwave/com/in/spring.xml");
    	Triangle TB=(Triangle)context.getBean("T");
    	TB.DrawShape();
    	Rectangle B1=(Rectangle)context.getBean("R");
    	B1.DrawShape();
    	Triangle tb=(Triangle)context.getBean("T1");
    	System.out.println(tb.getI()+" "+tb.getJ());
    	Triangle tb1=(Triangle)context.getBean("T2");
    	System.out.println(tb1.getI()+" "+tb1.getJ());
    }
}
