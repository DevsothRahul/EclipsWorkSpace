package techwave.com.in.pojo;

public class Rectangle {
	public void DrawShape()
	{
		System.out.println("Rectanle Drawn");
	}
}
