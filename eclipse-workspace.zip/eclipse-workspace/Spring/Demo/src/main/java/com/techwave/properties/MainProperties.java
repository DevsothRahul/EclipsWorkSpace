package com.techwave.properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import techwave.com.in.pojo.Emp;

public class MainProperties {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/techwave/properties/springproperties.xml");
		Emp E=(Emp)context.getBean("emp");
		System.out.println(E.geteNo()+" "+E.geteName());
		
		Emp E1=(Emp)context.getBean("emp1");
		System.out.println(E1.geteNo()+" "+E1.geteName());
		
		Emp EE=(Emp)context.getBean("EA");
		System.out.println(EE.geteNo()+" "+EE.geteName()+" "+EE.getAddrss().getAddressId()+" "+EE.getAddrss().getStreet()+" "+EE.getAddrss().getCity());
	}
}
