package SpringDemo.Demo100.POJO;

public class Trai {

}
