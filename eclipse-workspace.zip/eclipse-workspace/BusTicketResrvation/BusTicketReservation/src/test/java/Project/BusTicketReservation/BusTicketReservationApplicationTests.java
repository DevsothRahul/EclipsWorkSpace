package Project.BusTicketReservation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusTicketReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
