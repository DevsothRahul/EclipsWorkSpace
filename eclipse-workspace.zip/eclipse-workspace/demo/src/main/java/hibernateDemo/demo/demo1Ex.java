package hibernateDemo.demo;

public class demo1Ex {
public static void main(String[] args) {
	
}
}
