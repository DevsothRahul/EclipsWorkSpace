package techwave.mappin.POJO.Mapping2;


public class salary  {
	private int empno;
	private double basic;
	private Emp eno;
	public salary(int empno, double basic, Emp eno) {
		super();
		this.empno = empno;
		this.basic = basic;
		this.eno = eno;
	}
	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}
	public Emp getEno() {
		return eno;
	}
	public void setEno(Emp eno) {
		this.eno = eno;
	}
	public salary()
	{
		
	}
	@Override
	public String toString() {
		return "salary [empno=" + empno + ", basic=" + basic + ", eno=" + eno + "]";
	}
}
