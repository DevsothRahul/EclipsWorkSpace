package techwave.mappin.POJO.Mapping2;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findByename",  
	        query = "from Emp e where e.ename = :name"  
	        )  
	    }  
	)
public class Emp {
	private int empno;
	private String eName;
	private String gender;
	private Dept dept;
	
	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Dept getDept() {
		return dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public Emp(int empno, String eName, String gender, Dept dept) {
		super();
		this.empno = empno;
		this.eName = eName;
		this.gender = gender;
		this.dept = dept;
	}
	public Emp() {
		
	}

	@Override
	public String toString() {
		return " \n empno=" + empno + ", eName=" + eName + ", gender=" + gender + ", dept=" + dept .getDeptno();
	}
	
}
