package techwave.mappin.POJO.Mapping2;

import java.io.Serializable;

public class Sal implements Serializable {
	private Emp epno;
	private Double Sal;
	private int id;
	public Emp getEpno() {
		return epno;
	}
	public void setEpno(Emp epno) {
		this.epno = epno;
	}
	public Double getSal() {
		return Sal;
	}
	public void setSal(Double sal) {
		Sal = sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Sal(Emp epno, Double sal, int id) {
		super();
		this.epno = epno;
		Sal = sal;
		this.id = id;
	}
	

}
