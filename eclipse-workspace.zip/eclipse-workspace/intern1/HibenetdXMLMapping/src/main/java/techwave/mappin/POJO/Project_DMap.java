package techwave.mappin.POJO;

public class Project_DMap {
	private int projectId;
	private String projDesc;
	private int duration;
	
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjDesc() {
		return projDesc;
	}
	public void setProjDesc(String projDesc) {
		this.projDesc = projDesc;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public Project_DMap(int projectId, String projDesc, int duration) {
		super();
		this.projectId = projectId;
		this.projDesc = projDesc;
		this.duration = duration;
	}

}
