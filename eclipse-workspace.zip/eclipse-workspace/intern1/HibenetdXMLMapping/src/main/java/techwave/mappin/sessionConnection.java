package techwave.mappin;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class sessionConnection {
	public static SessionFactory getSessionFactory() {
		Configuration cfg = new Configuration();
	//	cfg.configure("techwave/mappin/POJO/Mapping2/hibernate.cfg.xml");
		cfg.configure("techwave.mappin.POJO.Mapping2/hib.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		return factory;

	}
}
