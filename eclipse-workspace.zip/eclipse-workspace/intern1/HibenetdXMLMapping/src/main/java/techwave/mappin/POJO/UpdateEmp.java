package techwave.mappin.POJO;

//import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
//import org.hibernate.internal.build.AllowSysOut;
//import org.hibernate.query.Query;

import techwave.mappin.sessionConnection;
//import techwave.mappin.POJO.Mapping2.Dept;
//import techwave.mappin.POJO.Mapping2.Emp;
//import techwave.mappin.POJO.Mapping2.salary;

public class UpdateEmp {
	public static void main(String[] args) {
		SessionFactory fact = sessionConnection.getSessionFactory();
		Session session = fact.openSession();
		Transaction T = session.beginTransaction();
//		int empno = 107;
//		String ename = "RR laxmi";
//		String gender = "male";
//		int deptno = 8;
//		int b=9000;
//		// Insertion of Data
//		Dept D2 = new Dept(deptno, "Management1");
//		session.save(D2);
//		Dept D = session.get(Dept.class, deptno);
//		Emp E = new Emp(empno, ename, gender, D);
//		session.save(E);
//		Emp E1 = session.get(Emp.class, empno);
//		salary S = new salary(empno, b, E1);
//		session.save(S);
		T.commit();
		session.close();
		fact.close();
								// Updating
//						Dept D = session.get(Dept.class, deptno);
//						Emp E = new Emp(empno, ename, gender, D);
//						session.update(E);
//						T.commit();
//						session.close();
//						fact.close();
		
//		System.out.println(E.getEmpno()+" "+E.geteName());

		//		String gen = "Male";
		//
		//		Query query = session.createQuery(" from Emp where gender=:gen ").setParameter("gen", gen);
		//		java.util.List list = query.list();
		//		System.out.println(list);
		//		T.commit();
		//		session.close();
		//		fact.close();
			                  	//update
//				Transaction tx=session.beginTransaction();  
//				Query q=session.createQuery("update Emp set ename=:n where empno=:i");  
//				q.setParameter("n","RahulNayak");  
//				q.setParameter("i",102);   
//				int status=q.executeUpdate();  
//				System.out.println(status);  
//				tx.commit();  
									//Deleting
			//	Transaction tx=session.beginTransaction();  
		//	Query query=session.createQuery("delete from salary where empno=100");  
			//Query query1=session.createQuery("delete from Emp where empno=100");  
			//query.executeUpdate();  
			//query1.executeUpdate();  
			//tx.commit();
		
												//sum of salary
								//Transaction tx=session.beginTransaction();  
							//	Query q=session.createQuery("select sum(basic) from salary");  
								//List<Integer> list=q.list();  
								//System.out.println(list.get(0)); 
								//tx.commit();
		
								//InnerQuery
						//Query query=session.createQuery(" from Emp where empno in(select empno from salary where basic>5000)");
					     //List L=query.list();
						//System.out.println(L);
						//List<Emp>l=	query.getResultList();
						//l.stream().forEach(i->System.out.println(i.geteName()+" "+i.getGender()+" "+i.getEmpno()));
						//T.commit();
						//session.close();
						//fact.close();

	}

}
