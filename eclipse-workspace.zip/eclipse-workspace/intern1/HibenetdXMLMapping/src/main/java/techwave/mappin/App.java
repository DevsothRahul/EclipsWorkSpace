package techwave.mappin;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//import Hibenetdemo.Demo11.POJO.projectdetails;
import techwave.mappin.POJO.Project_DMap;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("xmlfiles/hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Project_DMap P = new Project_DMap(12, "Java", 101);

		Transaction T = session.beginTransaction();

		session.save(P);
		T.commit();
		session.close();
		factory.close();
	}
}
