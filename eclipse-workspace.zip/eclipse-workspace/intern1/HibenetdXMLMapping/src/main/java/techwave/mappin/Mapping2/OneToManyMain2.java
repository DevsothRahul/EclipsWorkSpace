package techwave.mappin.Mapping2;

import java.util.Iterator;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import techwave.mappin.POJO.Mapping2.Emp;



public class OneToManyMain2 {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("techwave/mappin/POJO/Mapping2/hib.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		// Hibernate Named Query
//				TypedQuery query = session.getNamedQuery("findByename");
//				query.setParameter("name", "Rahul");
//
//				List<Emp> employees = query.getResultList();
//
//				Iterator<Emp> itr = employees.iterator();
//				while (itr.hasNext()) {
//					Emp e = itr.next();
//					System.out.println(e.getEmpno()+" "+e.geteName());
//				}
		
		session.close();
		factory.close();
	}
}
