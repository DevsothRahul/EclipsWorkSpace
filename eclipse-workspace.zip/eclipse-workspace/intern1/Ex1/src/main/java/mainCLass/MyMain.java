package mainCLass;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import pack.pojo.DEPTTEST;
import pack.pojo.EMPtest;

public class MyMain {
	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		DateTimeFormatter t=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		cfg.configure("pack/pojo/hib.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction T = session.beginTransaction();
		//int deptno=10;
	//	String job="Manage";
//		String d1="17-Dec-1980";
//		LocalDate date=LocalDate.parse(d1,t);
//		DEPTTEST D2 = new DEPTTEST(deptno, "ACCOUNTING", "NEW YORK");
//		session.save(D2);
//		DEPTTEST D = session.get(DEPTTEST.class, deptno);
//		EMPtest E = new EMPtest(7369, "SMITH",  "CLERK", 7369,date, 800,0,D);
//		session.save(E);
				Query q=session.createQuery("update EMPtest set job=:n , deptno=:i where empNo=7369");  
				q.setParameter("n","Rahul1");  
				q.setParameter("i",30);   
				int status=q.executeUpdate();  
				System.out.println(status);  


		T.commit();
		factory.close();
		session.close();
	}
}
