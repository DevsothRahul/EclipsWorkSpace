package Hibenetdemo.Demo11.Mapping2.POJO;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import javax.persistence.Table;

@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findEmpByEname",  
	        query = "from Emp e where e.ename=:name"  
	        )  ,
	        @NamedQuery(  
	    	        name = "findBydept",  
	    	        query = "from Emp e where e.deptno = :dno"  
	    	        ) 
	    }  
	)

@Entity
@Table(name = "Emp_E2")
public class Emp {
	@Id
	private int empno;
	private String ename;
	private LocalDate dob;
	@ManyToOne//Many emp work for one dept
	@JoinColumn(name = "Deptno",referencedColumnName = "did")
	private Dept deptno;
	public int getEmpno() {
		return empno;
	}
public Emp() {}
	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Dept getDeptno() {
		return deptno;
	}

	public void setDeptno(Dept deptno) {
		this.deptno = deptno;
	}

	public Emp(int empno, String ename, LocalDate dob, Dept deptno) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob;
		this.deptno = deptno;
	}

}
