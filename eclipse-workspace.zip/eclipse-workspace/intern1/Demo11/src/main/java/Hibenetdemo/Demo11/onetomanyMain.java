package Hibenetdemo.Demo11;

import java.util.Iterator;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Hibenetdemo.Demo11.Mapping2.POJO.Dept;
import Hibenetdemo.Demo11.Mapping2.POJO.Emp;


public class   onetomanyMain{
	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("Hibenetdemo/Demo11/Mapping2/POJO/Hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction T = session.beginTransaction();
		// Hibernate Named Query
		TypedQuery<Emp> query = session.getNamedQuery("findEmpByEname");
		query.setParameter("name", "Rahul");
		List<Emp> employees = query.getResultList();
		System.out.println(employees.get(0).getEmpno()+" "+employees.get(0).getEname()+" "+employees.get(0).getDob()+" "+employees.get(0).getDeptno().getDid());
		
		TypedQuery q1=session.getNamedQuery("findBydept");
		Dept D=session.get(Dept.class, 1);
		q1.setParameter("dno", D);
		List<Emp> e1=q1.getResultList();
		System.out.println(e1.get(0).getDeptno().getDid()+" "+e1.get(0).getDeptno().getDname());
		// session.save();
		T.commit();
		session.close();
		factory.close();
	}
}
