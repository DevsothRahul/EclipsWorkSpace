package Hibenetdemo.Demo11;

import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Hibenetdemo.Demo11.Mapping2.POJO.EMPtest2;
import Hibenetdemo.Demo11.Mapping2.POJO.Emp;

public class Mapp2Main {
	public static SessionFactory getSessionFactory() {
		Configuration cfg = new Configuration();
		//cfg.configure("Hibenetdemo/Demo11/Mapping2/POJO/Hibernate.cfg.xml");
		cfg.configure("Hibenetdemo/Demo11/Mapping2/POJO/hib.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();

		Transaction T = session.beginTransaction();
		
		TypedQuery<EMPtest2> query = session.getNamedQuery("findEmpByEname");
		//query.setParameter("name", "Rahul");
		List<EMPtest2> employees = query.getResultList();
		System.out.println(employees.get(0).getEmpNo()+" "+employees.get(0).geteName()+" "+employees.get(0).getJob()+" "+employees.get(0).getDeptno().getDname());
		// session.save();
		T.commit();
		session.close();
		factory.close();
		return factory;
	}

}
