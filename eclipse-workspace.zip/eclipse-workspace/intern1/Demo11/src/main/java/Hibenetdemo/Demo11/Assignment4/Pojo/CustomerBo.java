package Hibenetdemo.Demo11.Assignment4.Pojo;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerBo {

	private static List<Customer> Clist = new ArrayList<Customer>();

	private static Boolean Validate(Customer customer) {
		LocalDate d = LocalDate.now();
		if (customer.getDateOfCreation().compareTo(d) < 0) {
			if (customer.getCustomerType().equals("Premium") || customer.getCustomerType().equals("Guest")) {
				if (customer.getAddressId().getZipcode().length() == 5) {
					return true;
				}
			}
		}

		return false;

	}

	public static boolean AddCustomer(Customer customer) {
		if (Validate(customer)) {
			Configuration cfg = new Configuration().configure("Hibenetdemo/Demo11/Assignment4/test4.cfg.xml");
			SessionFactory factory = cfg.buildSessionFactory();
			Session session = factory.openSession();
			Transaction T = session.beginTransaction();
			session.save(customer.getAddressId());
			session.save(customer);
			T.commit();

			session.close();
			factory.close();
			return true;
		}
		return false;
	}

	public static List<Customer> getCustomers() {
		Configuration cfg = new Configuration().configure("Hibenetdemo/Demo11/Assignment4/test4.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction T = session.beginTransaction();
		Clist = session.createQuery("from Customer ").list();
		List<Customer> list = Clist.stream().sorted((i, j) -> i.getDateOfCreation().compareTo(j.getDateOfCreation())).collect(Collectors.toList());
		T.commit();
		session.close();
		factory.close();
		return list;

	}
}
