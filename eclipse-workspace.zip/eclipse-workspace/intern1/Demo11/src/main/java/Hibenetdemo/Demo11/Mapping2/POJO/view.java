package Hibenetdemo.Demo11.Mapping2.POJO;

public class view {
private int empno;
private String ename;
private String job;
private DEPTTEST2 dno;
public view(int empno, String ename, String job, DEPTTEST2 dno) {
	super();
	this.empno = empno;
	this.ename = ename;
	this.job = job;
	this.dno = dno;
}
public int getEmpno() {
	return empno;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getJob() {
	return job;
}
public void setJob(String job) {
	this.job = job;
}
public DEPTTEST2 getDno() {
	return dno;
}
public void setDno(DEPTTEST2 dno) {
	this.dno = dno;
}

}
