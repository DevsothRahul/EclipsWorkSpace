package Hibenetdemo.Demo11;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Hibenetdemo.Demo11.POJO.projectdetails;

public class Demo1 {
public static void main(String[] args) {
	
	//SessionFactory factory=new Configuration().configure("Hibenetdemo/Demo11/hibernate.cfg.xml").buildSessionFactory();
	
	Configuration cfg=new Configuration();
	cfg.configure("Hibenetdemo/Demo11/hibernate.cfg.xml");
	SessionFactory factory=cfg.buildSessionFactory();
	Session session=factory.openSession();
	
	projectdetails P=new projectdetails(10,"Java",101);
	
	Transaction T=session.beginTransaction();
	
	session.save(P);
	T.commit();
	session.close();
	factory.close();
	

}
}
