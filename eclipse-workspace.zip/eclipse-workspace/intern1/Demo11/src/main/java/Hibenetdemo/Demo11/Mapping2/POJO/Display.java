package Hibenetdemo.Demo11.Mapping2.POJO;

import java.util.List;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Display {
	public static void main(String[] args) {
		SessionFactory fact= (SessionFactory) Hibenetdemo.Demo11.sessionConnection.getSessionFactory();
		Session session = fact.openSession();
		Transaction T = session.beginTransaction();
		TypedQuery<Emp> query = session.getNamedQuery("findEmpByEname");
		//query.setParameter("name", "Rahul");
		List<Emp> employees = query.getResultList();
		System.out.println(employees.get(0).getEmpno()+" "+employees.get(0).getEname()+" "+employees.get(0).getDob()+" "+employees.get(0).getDeptno().getDid());
		T.commit();
		session.close();
		fact.close();
	}
}
