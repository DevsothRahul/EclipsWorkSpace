package Hibenetdemo.Demo11.Assignment4.Pojo;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class Customer {

        @Id
        private int customerId;
        private String customerName;
        private String customerType;
        private String mobile;
        private LocalDate dateOfCreation;
        @OneToOne
        private Address addressId;

        public Customer() {
            super();
        }

        public Customer(int customerId, String customerName, String customerType, String mobile,
                LocalDate dateOfCreation, Address addressId) {
            super();
            this.customerId = customerId;
            this.customerName = customerName;
            this.customerType = customerType;
            this.mobile = mobile;
            this.dateOfCreation = dateOfCreation;
            this.addressId = addressId;
        }

        public int getCustomerId() {
            return customerId;
        }

        public void setCustomerId(int customerId) {
            this.customerId = customerId;
        }

        public String getCustomerName() {
            return customerName;
        }

        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        public String getCustomerType() {
            return customerType;
        }

        public void setCustomerType(String customerType) {
            this.customerType = customerType;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public LocalDate getDateOfCreation() {
            return dateOfCreation;
        }

        public void setDateOfCreation(LocalDate dateOfCreation) {
            this.dateOfCreation = dateOfCreation;
        }

        public Address getAddressId() {
            return addressId;
        }

        public void setAddressId(Address addressId) {
            this.addressId = addressId;
        }

		@Override
		public String toString() {
			return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerType="
					+ customerType + ", mobile=" + mobile + ", dateOfCreation=" + dateOfCreation + ", addressId="
					+ addressId + "]";
		}






}