package Hibenetdemo.Demo11.POJO;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbpd")
public class projectdetails {
	@Id
	private int projectId;
	private String projDesc;
	private int duration;
	public projectdetails(int projectId, String projDesc, int duration) {
		super();
		this.projectId = projectId;
		this.projDesc = projDesc;
		this.duration = duration;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjDesc() {
		return projDesc;
	}
	public void setProjDesc(String projDesc) {
		this.projDesc = projDesc;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

}
