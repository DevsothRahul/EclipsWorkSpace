package Hibenetdemo.Demo11.Mapping2.POJO;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Dept_D2")
public class Dept {
	@Id
	private int did;
	private String dname;
	public Dept() {}
	public Dept(int did, String dname, List<Emp> elist) {
		super();
		this.did = did;
		this.dname = dname;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}


}
