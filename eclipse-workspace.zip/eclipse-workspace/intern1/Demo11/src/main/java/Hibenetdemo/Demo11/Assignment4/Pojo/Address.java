package Hibenetdemo.Demo11.Assignment4.Pojo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Address {
     @Id
     private int addressid;
     private String hNo;
     private String street;
     private String city;
     private String zipcode;
     private String country;
    public int getAddressid() {
        return addressid;
    }
    public void setAddressid(int addressid) {
        this.addressid = addressid;
    }
    public String gethNo() {
        return hNo;
    }
    public void sethNo(String hNo) {
        this.hNo = hNo;
    }
    public String getStreet() {
        return street;
    }
    public void setStreet(String street) {
        this.street = street;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getZipcode() {
        return zipcode;
    }
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
    public Address(int addressid, String hNo, String street, String city, String zipcode, String country) {
        super();
        this.addressid = addressid;
        this.hNo = hNo;
        this.street = street;
        this.city = city;
        this.zipcode = zipcode;
        this.country = country;
    }
    public Address() {
        super();
    }
	@Override
	public String toString() {
		return "Address [addressid=" + addressid + ", hNo=" + hNo + ", street=" + street + ", city=" + city
				+ ", zipcode=" + zipcode + ", country=" + country + "]";
	}




}