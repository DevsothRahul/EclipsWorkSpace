package Hibenetdemo.Demo11.Mapping2.POJO;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@NamedQueries(  
	    {  
	        @NamedQuery(  
	        name = "findEmpByEname",  
	        query = "select new Hibenetdemo.Demo11.Mapping2.POJO.view(e.ename ,e.dname,e.job,d.dname) from DEPTTEST d,EMPtest e"+"e.deptno=d.deptno"  
	        ) 
	    }  
	)
@Entity
@Table(name = "Emp_test")
public class EMPtest2 {
	@Id

	private int empNo;
	private String eName;
	private String job;
	private int mgr;
	private LocalDate hiredate;
	private double sal;
	private int comm;
	@ManyToOne//Many emp work for one dept
	@JoinColumn(name = "Deptno",referencedColumnName = "deptno")
	private DEPTTEST2 Deptno;
	public EMPtest2(int empNo, String eName, String job, int mgr, LocalDate hiredate, double sal, int comm,
			DEPTTEST2 deptno) {
		super();
		this.empNo = empNo;
		this.eName = eName;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
		Deptno = deptno;
	}
	public EMPtest2() {}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public int getComm() {
		return comm;
	}
	public void setComm(int comm) {
		this.comm = comm;
	}
	public DEPTTEST2 getDeptno() {
		return Deptno;
	}
	public void setDeptno(DEPTTEST2 deptno) {
		Deptno = deptno;
	}
	

}
