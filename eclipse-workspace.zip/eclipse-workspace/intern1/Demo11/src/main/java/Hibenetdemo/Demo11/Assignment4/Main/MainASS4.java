package Hibenetdemo.Demo11.Assignment4.Main;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import Hibenetdemo.Demo11.Assignment4.Pojo.Address;
import Hibenetdemo.Demo11.Assignment4.Pojo.Customer;
import Hibenetdemo.Demo11.Assignment4.Pojo.CustomerBo;

public class MainASS4 {
	public static void main(String[] args) {
		DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		Scanner Sc = new Scanner(System.in);
		while (true) {
			System.out.println("Enter Y to EnterDetails // N To Diaply");
			String s = Sc.nextLine();
			if (s.equals("y")) {
				System.out.println("Address Id:");
				int adId = Sc.nextInt();
				Sc.nextLine();
				// System.out.println("Hno:");
				String hno = Sc.nextLine();
				// System.out.println("Street:");
				String strt = Sc.nextLine();
				// System.out.println("City:");
				String city = Sc.nextLine();
				// System.out.println("ZipCode:");
				String zpc = Sc.nextLine();
				// System.out.println("Country:");
				String ctry = Sc.nextLine();
				Address a = new Address(adId, hno, strt, city, zpc, ctry);
				// System.out.println("Cust Id:");
				int cid = Sc.nextInt();
				Sc.nextLine();
				// System.out.println("CustName:");
				String sname = Sc.nextLine();
				// System.out.println("CustType:");
				String cT = Sc.nextLine();
				// System.out.println("mobile:");
				String mb = Sc.nextLine();
				// System.out.println("DateOf Creation:");
				LocalDate d = LocalDate.parse(Sc.nextLine(), D);
				Customer c = new Customer();
				Customer customer1 = new Customer(cid, sname, cT, mb, d, a);
				if (CustomerBo.AddCustomer(customer1)) 
					System.out.println("susscefully Added");
			
			}
			else if (s.toUpperCase().equals("N")) {
					System.out.println("output:");
					List<Customer> list = CustomerBo.getCustomers();
					list.stream().forEach(i ->System.out.println(i));
				} else {
					System.out.println("Enter Valid String:");
					break;
				}
			}
		}

	}

