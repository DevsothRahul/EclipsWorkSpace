package Jdbc;

import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ex3PreaparedStarement {
	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pstmt=null;
		Scanner Sc=new Scanner(System.in);
		System.out.println("1.Insert 2.Update 3.Disply 4.Delete \n");
		int no=Sc.nextInt();
		switch(no)
		{
		case 1:	System.out.println("Emp no:");
				int eno = Sc.nextInt();
				Sc.nextLine();
				System.out.println("Emp name:");
				String eName = Sc.nextLine();
				System.out.println("Emp gender:");
				String gender = Sc.nextLine();
				DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
				System.out.println("Emp date:");
				LocalDate db = LocalDate.parse(Sc.nextLine(), D);
				System.out.println("Emp pancard");
				String pan = Sc.nextLine();
				System.out.println("Emp dept no:");
				int dno = Sc.nextInt();
				// spep1
							try {
								Class.forName("oracle.jdbc.driver.OracleDriver");
							} catch (ClassNotFoundException e) {
								System.out.println("Driver Error");
							}
		
							// step2
							try {
								con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
							} catch (SQLException e) {
								System.out.println("Error connection");
		
							}
				//step3
				//"insert into emp2022wc values(?,?,?,?,?,?);"
				//"update emp2022wc set pancard=?,deptno=? where empno=?"
				//pstmt.setString(1,pan);
				//pstmt.setInt(2,dno);
				//pstmt.setInt(3,eno);
				//int R=pstmt.excuteUpdate();
				//System.out.peintln(R+"Row inserted");
				
				try {
					pstmt=con.prepareStatement("insert into emp2022wc values(?,?,?,?,?,?)");
					pstmt.setInt(1, eno);
					pstmt.setString(2, eName);
					pstmt.setString(3, gender);
					pstmt.setString(4, db.format(D));
					pstmt.setString(5,pan);
					pstmt.setInt(6,dno);
					int R=pstmt.executeUpdate();
					System.out.println(R +" Row inserted ");
				} catch (SQLException e) {
					System.out.println(e.getMessage());
				}
		
				break;
		case 2:System.out.println("Emp no:");
			int eno1 = Sc.nextInt();
			Sc.nextLine();
			System.out.println("Emp pancard");
			String pan1 = Sc.nextLine();
			System.out.println("Emp dept no:");
			int dno1 = Sc.nextInt();
			// spep1
						try {
							Class.forName("oracle.jdbc.driver.OracleDriver");
						} catch (ClassNotFoundException e) {
							System.out.println("Driver Error");
						}
	
						// step2
						try {
							con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
						} catch (SQLException e) {
							System.out.println("Error connection");
	
						}
			//step3
			//"insert into emp2022wc values(?,?,?,?,?,?);"
			//"update emp2022wc set pancard=?,deptno=? where empno=?"
			//pstmt.setString(1,pan);
			//pstmt.setInt(2,dno);
			//pstmt.setInt(3,eno);
			//int R=pstmt.excuteUpdate();
			//System.out.peintln(R+"Row inserted");
			
			try {
				pstmt=con.prepareStatement("update emp2022wc set pancard=?,deptno=? where empno=?");
				pstmt.setString(1,pan1);
				pstmt.setInt(2,dno1);
				pstmt.setInt(3, eno1);
				int R=pstmt.executeUpdate();
				System.out.println(R +" updated ");
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
					break;
				
		case 3:
			
			// spep1
						try {
							Class.forName("oracle.jdbc.driver.OracleDriver");
						} catch (ClassNotFoundException e) {
							System.out.println("Driver Error");
						}
	
						// step2
						try {
							con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
						} catch (SQLException e) {
							System.out.println("Error connection");
	
						}
			//step3
			//"insert into emp2022wc values(?,?,?,?,?,?);"
			//"update emp2022wc set pancard=?,deptno=? where empno=?"
			//pstmt.setString(1,pan);
			//pstmt.setInt(2,dno);
			//pstmt.setInt(3,eno);
			//int R=pstmt.excuteUpdate();
			//System.out.peintln(R+"Row inserted");
			
			try {
				pstmt=con.prepareStatement("select *from emp2022wc");
				ResultSet R=pstmt.executeQuery();
				while(R.next())
				{
					System.out.println(R.getInt(1)+" "+R.getString(2)+" "+R.getString(3)+" "+R.getString(4)+" "+R.getString(5)+R.getInt(6));
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}
				
				break;
		case 4:
			System.out.println("Emp no:");
			int eno2 = Sc.nextInt();
				// spep1
					try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
					} catch (ClassNotFoundException e) {
						System.out.println("Driver Error");
					}

					// step2
					try {
						con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
					} catch (SQLException e) {
						System.out.println("Error connection");

					}
		//step3
		//"insert into emp2022wc values(?,?,?,?,?,?);"
		//"update emp2022wc set pancard=?,deptno=? where empno=?"
		//"delete from emp2022wc where empno=?"
		//pstmt.setString(1,pan);
		//pstmt.setInt(2,dno);
		//pstmt.setInt(3,eno);
		//int R=pstmt.excuteUpdate();
		//System.out.peintln(R+"Row inserted");
		
		try {
			pstmt=con.prepareStatement("delete from emp2022wc where empno=?");
			pstmt.setInt(1, eno2);
			int R=pstmt.executeUpdate();
			System.out.println(R +" Deleted ");
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
				break;
		default:
				System.out.println("invalid option");
				break;
				
		}
		
		
		
	}
}
