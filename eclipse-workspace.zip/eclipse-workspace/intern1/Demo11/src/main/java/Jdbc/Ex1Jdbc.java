package Jdbc;
import java.sql.*;
public class Ex1Jdbc {
public static void main(String[] args) {
	Connection con=null;
	Statement stmt=null;
	//step1
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
	} catch (ClassNotFoundException e) {
		System.out.println("Driver Error");
	}
	//step2
	try {
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	} catch (SQLException e) {
		System.out.println("URL error");
	}
	
	//step3
	try {
		stmt=con.createStatement();
	} catch (SQLException e) {
		System.out.println("statement Error");
	}
	
	//step4
	try {
		stmt.executeUpdate("insert into emp2022wc values(18,'Ram','Male','01-Oct-2020','ASCDF123E4',100)");
		System.out.println("Inseted");
	} catch (SQLException e) {
		System.out.println("Query Error:" + e.getMessage());
	}
	
	//step5
	
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
