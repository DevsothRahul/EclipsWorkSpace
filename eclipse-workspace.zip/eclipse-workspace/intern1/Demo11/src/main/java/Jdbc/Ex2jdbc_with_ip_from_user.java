package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ex2jdbc_with_ip_from_user {
	public static void main(String[] args) {
		LocalDate db;
		Scanner Sc = new Scanner(System.in);
		Connection con = null;
		Statement stmt = null;
		System.out.println("1.insert 2.update 3.delete 4.Display");
		int n = Sc.nextInt();
		switch (n) {
		case 1:
			System.out.println("Emp no:");
			int eno = Sc.nextInt();
			Sc.nextLine();
			System.out.println("Emp name:");
			String eName = Sc.nextLine();
			System.out.println("Emp gender:");
			String gender = Sc.nextLine();
			DateTimeFormatter D = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			System.out.println("Emp date:");
			db = LocalDate.parse(Sc.nextLine(), D);
			System.out.println("Emp pancard");
			String pan = Sc.nextLine();
			System.out.println("Emp dept no:");
			int dno = Sc.nextInt();

			// spep1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println("Driver Error");
			}

			// step2
			try {
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
			} catch (SQLException e) {
				System.out.println("Error connection");

			}
			// step3

			try {
				stmt = con.createStatement();
			} catch (SQLException e) {
				System.out.println("stmt Error");
			}
			// step4

			// "update emp2022wc set pancard='ASASA122A' ,deptno=100 where empno=123";
			// "update emp2022wc set pancard='"+pan+"' ,deptno="+dno+" where empno="+eno+"";

			// "insert into emp2022wc
			// values(18,'Ram','Male','01-Oct-2020','ASCDF123E4',100)"
			// "insert into emp2022wc
			// values("+eno+",'"+eName+"','"+gender+"','"+db.format(D)+"','"+pan+"',"+dno+")"
			try {
				stmt.executeUpdate("insert into emp2022wc values(" + eno + ",'" + eName + "','" + gender + "','"
						+ db.format(D) + "','" + pan + "'," + dno + ")");
				System.out.println("1 row inserted");
			} catch (SQLException e) {

				if (e.getMessage().contains("PK_EMPNO22"))
					System.out.println("Emp no can not duplicate");
				else
					System.out.println(e.getMessage());

			}

			// step5
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case 2:
			System.out.println("Emp no:");
			int eno1 = Sc.nextInt();
			Sc.nextLine();
			System.out.println("Emp pancard to Update:");
			String pan1 = Sc.nextLine();
			System.out.println("Emp Dept no:");
			int dno1 = Sc.nextInt();

			// spep1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println("Driver Error");
			}

			// step2
			try {
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
			} catch (SQLException e) {
				System.out.println("Error connection");

			}
			// step3

			try {
				stmt = con.createStatement();
			} catch (SQLException e) {
				System.out.println("stmt Error");
			}
			// step4

			try {
				stmt.executeUpdate(
						"update emp2022wc set pancard='" + pan1 + "' ,deptno=" + dno1 + " where empno=" + eno1 + "");
				System.out.println("Updated");
			} catch (SQLException e) {

				if (e.getMessage().contains("PK_EMP2022"))
					System.out.println("Emp no can not duplicate");
				else
					System.out.println(e.getMessage());

			}

			// step5
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 3:
			System.out.println("Emp no:");
			int eno2 = Sc.nextInt();
			// spep1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println("Driver Error");
			}

			// step2
			try {
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");

			} catch (SQLException e) {
				System.out.println("Error connection");

			}
			// step3

			try {
				stmt = con.createStatement();
			} catch (SQLException e) {
				System.out.println("stmt Error");
			}
			// step4

			// "update emp2022wc set pancard='ASASA122A' ,deptno=100 where empno=123";
			// "update emp2022wc set pancard='"+pan+"' ,deptno="+dno+" where empno="+eno+"";
			// "delete from emp2022 where empno=eno";

			// "insert into emp2022wc
			// values(18,'Ram','Male','01-Oct-2020','ASCDF123E4',100)"
			// "insert into emp2022wc
			// values("+eno+",'"+eName+"','"+gender+"','"+db.format(D)+"','"+pan+"',"+dno+")"
			try {
				stmt.executeUpdate("delete from emp2022wc where empno=" + eno2 + "");
				System.out.println("Deleted");
			} catch (SQLException e) {

				if (e.getMessage().contains("PK_EMP2022"))
					System.out.println("Emp no can not duplicate");
				else
					System.out.println(e.getMessage());

			}

			// step5
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case 4:
			// spep1
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} catch (ClassNotFoundException e) {
				System.out.println("Driver Error");
			}

			// step2
			try {
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");

			} catch (SQLException e) {
				System.out.println("Error connection");

			}
			// step3

			try {
				stmt = con.createStatement();
			} catch (SQLException e) {
				System.out.println("stmt Error");
			}
			// step4

			// "update emp2022wc set pancard='ASASA122A' ,deptno=100 where empno=123";
			// "update emp2022wc set pancard='"+pan+"' ,deptno="+dno+" where empno="+eno+"";
			// "delete from emp2022 where empno=eno";

			// "insert into emp2022wc
			// values(18,'Ram','Male','01-Oct-2020','ASCDF123E4',100)"
			// "insert into emp2022wc
			// values("+eno+",'"+eName+"','"+gender+"','"+db.format(D)+"','"+pan+"',"+dno+")"
			try {
				ResultSet R=stmt.executeQuery("select *from emp2022wc");
				
				while(R.next())
				{
					System.out.println(R.getInt(1)+" "+R.getString(2)+" "+R.getString(3)+" "+R.getString(4)+" "+R.getString(5)+" "+R.getInt(6));
				}
			} catch (SQLException e) {

				if (e.getMessage().contains("PK_EMP2022"))
					System.out.println("Emp no can not duplicate");
				else
					System.out.println(e.getMessage());

			}

			// step5
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		default:
			System.out.println("select correct option");
			break;
		}

	}
}
