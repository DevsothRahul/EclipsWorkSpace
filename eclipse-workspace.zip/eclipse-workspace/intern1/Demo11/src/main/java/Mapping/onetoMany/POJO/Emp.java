package Mapping.onetoMany.POJO;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Emp_E")
public class Emp {
	@Id
	private int empno;
	private String ename;
	private LocalDate dob;
@OneToOne
@JoinColumn(name="Deptno")
	private Dept deptno;
public int getEmpno() {
	return empno;
}
public void setEmpno(int empno) {
	this.empno = empno;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public Dept getDeptno() {
	return deptno;
}
public void setDeptno(Dept deptno) {
	this.deptno = deptno;
}
public Emp(int empno, String ename, LocalDate dob, Dept deptno) {
	super();
	this.empno = empno;
	this.ename = ename;
	this.dob = dob;
	this.deptno = deptno;
}
	
	
}
