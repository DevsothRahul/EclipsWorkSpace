package Mapping.onetoMany.POJO;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Dept_D")
public class Dept {
	@Id
	private int did;
	private String dname;
	@OneToMany(mappedBy = "deptno")
	//one dept can have many employees
	private List<Emp> elist;
	public Dept(int did, String dname, List<Emp> elist) {
		super();
		this.did = did;
		this.dname = dname;
		this.elist = elist;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}


}
