package Mapping.onetoMany.POJO;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Sal implements Serializable{
	@Id
	@OneToOne
	@JoinColumn(name="Eno" ,referencedColumnName = "empno")
	private Emp empno;
	private double basic;
	public Sal(Emp empno, double basic) {
		super();
		this.empno = empno;
		this.basic = basic;
	}
	public Emp getEmpno() {
		return empno;
	}
	public void setEmpno(Emp empno) {
		this.empno = empno;
	}
	public double getBasic() {
		return basic;
	}
	public void setBasic(double basic) {
		this.basic = basic;
	}

}
