package Jdbc_Exam;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Scanner;

public class Q1 {
public static void main(String[] args) {
	 Scanner in=new Scanner(System.in);
	    Connection Con=null;
	    CallableStatement Cstmt=null;

	    try {
	        Class.forName("oracle.jdbc.driver.OracleDriver");
	    } catch (ClassNotFoundException e) {
	        // TODO Auto-generated catch block
	        System.out.println("not registered");
	    }

	    try {
	        Con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","system","Admin#123");
	    } catch (SQLException e) {
	        // TODO Auto-generated catch block
	        System.out.println("connection not established");
	    }


	    try {

	        System.out.println(" enter staffno:");
	        int eno=in.nextInt();
	    
	        System.out.println("enter Ward  no:");
	        int dpt=in.nextInt();
	        in.nextLine();
	        System.out.println("Enter the Shift  Type");
	        String en=in.nextLine();

	        Cstmt=Con.prepareCall("{call Tb_Insert(?,?,?,?)");
	        Cstmt.setInt(1,eno);
	        Cstmt.setInt(2,dpt);
	        Cstmt.setString(3, en);
	        Cstmt.registerOutParameter(4, Types.VARCHAR, 25);
	        Cstmt.executeUpdate();
	        System.out.println(Cstmt.getString(4));
	    } 
	    catch (SQLException e) {
	         //TODO Auto-generated catch block
	        if (e.getMessage().contains("SYSTEM.PK_ST"))
	        {
	            System.out.println("staff no can not duplicate");

	        }
	        else if(e.getMessage().contains("SYSTEM.CHK_S"))
	        {
	        	System.out.println(" check Constraint voilated");
	        }
	        else
	        {
	            System.out.println("Enter Correct details:");
	        }
	  
	    }
}
}
