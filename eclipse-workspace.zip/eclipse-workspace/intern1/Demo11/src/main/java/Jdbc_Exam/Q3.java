package Jdbc_Exam;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.OracleType;
import oracle.jdbc.internal.OracleTypes;

public class Q3 {
	public static void main(String[] args) {
		Connection con = null;
		CallableStatement pstmt = null;
		List<staff> list=new ArrayList<staff>();  
		List<String>L=new ArrayList<String>();
		// spep1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Error");
		}

		// step2
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			System.out.println("Error connection");

		}
//step3
		try {
			pstmt = con.prepareCall("{call all_Shift(?)}");
			pstmt.registerOutParameter(1, OracleTypes.CURSOR);
			pstmt.execute();
					pstmt.executeQuery();
					ResultSet R = (ResultSet) pstmt.getObject(1);
			while (R.next()) {
				//System.out.println(R.getInt(1)+" "+R.getInt(2)+" "+R.getString(3));
			//	list.add(new staff(R.getInt(1), R.getInt(2),R.getString(3)));
				L.add(R.getInt("STAFFNO")+R.getInt("WARDNO")+R.getString("SHIFT"));
			}
		//	list.stream().filter(i->i.getName().trim().equals("Morning")).forEach(i->System.out.println(i.getId()+" "+i.getHno()+" "+i.getName()));
			L.stream().filter(i->i.contains("Morning")).forEach(i->System.out.println(i));
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
}
