package Jdbc_Exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class q2 {
	public static void main(String[] args) {
		Connection con = null;
		PreparedStatement pstmt = null;
		Scanner Sc = new Scanner(System.in);
		System.out.println("Enter the the staff number to change the shift");
		int eno1 = Sc.nextInt();
		Sc.nextLine();
		System.out.println("Enter the Shift:");
		String pan1 = Sc.nextLine();
		// spep1
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Error");
		}

		// step2
		try {
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "Admin#123");
		} catch (SQLException e) {
			System.out.println("Error connection");

		}
		try {
			pstmt = con.prepareStatement("update shift set shift=? where staffno=?");
			pstmt.setString(1, pan1);
			pstmt.setInt(2, eno1);
			int R = pstmt.executeUpdate();
			System.out.println(R + " updated ");
		} catch (SQLException e) {
			 if(e.getMessage().contains("SYSTEM.CHK_S"))
	        {
	        	System.out.println(" check Constraint voilated");
	        }
	        else
	        {
	            System.out.println("Enter Correct details:");
	        }
		}
	}
}
