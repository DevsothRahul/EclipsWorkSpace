package Jdbc_Exam;

public class staff {
private int id;
private int hno;
private String name;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public int getHno() {
	return hno;
}
public void setHno(int hno) {
	this.hno = hno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public staff(int id, int hno, String name) {
	super();
	this.id = id;
	this.hno = hno;
	this.name = name;
}

}
