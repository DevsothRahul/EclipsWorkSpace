package jdbc;

public class demoJdbc {
	public static void main(String[] args) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		//Connection  con=DriverManager.getConnection(std1,system,Admin#123);
	}
}
