package Main;

import java.lang.module.Configuration;

import org.hibernate.SessionFactory;

public class mainfile {
	public static void main(String[] args) {
		//SessionFactory factory=new Configuration().configure("Hibenetdemo/Demo11/hibernate.cfg.xml").buildSessionFactory();
	}
}
