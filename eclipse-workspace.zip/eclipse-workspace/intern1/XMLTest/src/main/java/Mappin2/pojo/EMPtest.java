package Mappin2.pojo;

import java.time.LocalDate;

public class EMPtest {
	private int empNo;
	private String eName;
	private String job;
	private int mgr;
	private LocalDate hiredate;
	private double sal;
	private int comm;
	private DEPTTEST Deptno;
	public EMPtest(int empNo, String eName, String job, int mgr, LocalDate hiredate, double sal, int comm,
			DEPTTEST deptno) {
		super();
		this.empNo = empNo;
		this.eName = eName;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
		Deptno = deptno;
	}
	public EMPtest() {}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}
	public LocalDate getHiredate() {
		return hiredate;
	}
	public void setHiredate(LocalDate hiredate) {
		this.hiredate = hiredate;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public int getComm() {
		return comm;
	}
	public void setComm(int comm) {
		this.comm = comm;
	}
	public DEPTTEST getDeptno() {
		return Deptno;
	}
	public void setDeptno(DEPTTEST deptno) {
		Deptno = deptno;
	}
	

}
